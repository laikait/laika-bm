# Modules

Drop-in extensions for Laika Bill Manager. This directory lives in the
application root, **not** inside `vendor/`, so modules survive `composer
update` and are never wiped when the package is reinstalled.

| Directory     | Purpose                                              |
|---------------|------------------------------------------------------|
| `fraud/`      | Fraud screening                                      |
| `addons/`     | Feature add-ons and general extensions               |
| `gateways/`   | Payment gateways   -> `payment_gateways` table       |
| `servers/`    | Provisioning       -> `servers` / `server_groups`    |
| `registrars/` | Domain registrars  -> `domain_registrars` table      |

These five are the whole list, and it is declared once, in
`LBM\Module\ModuleManager::TYPES`. `LBM\Action\Module` aliases that constant
rather than repeating it.

There used to be a `plugins/` directory; `addons/` covers what it was for.
`widgets/` is gone too — it was only ever an empty directory the loader did not
know about.

## Layout

A module is a directory two levels down holding a `module.php` manifest:

```
modules/gateways/Stripe/module.php
```

The directory it sits in decides its kind — the manifest is not asked, so a
module cannot claim to be something it is not by editing a string.

## The manifest

`module.php` returns an array. Everything except `name` is optional.

```php
return [
    'name'        => 'Stripe',
    'version'     => '1.0.0',
    'author'      => 'Someone',
    'description' => 'Takes card payments through Stripe.',

    // The class implementing the contract for this kind of module -
    // LBM\Module\Contracts\{Gateway,Server,Registrar}Interface.
    'class'       => \Modules\Gateways\Stripe\Stripe::class,

    // PSR-4. The short form: one prefix, mapped to a subdirectory of the
    // module (omit `src` to map it to the module directory itself).
    'namespace'   => 'Modules\Gateways\Stripe',
    'src'         => 'src',

    // The long form, for a module shipping more than one prefix.
    // 'autoload' => ['Modules\Gateways\Stripe\' => 'src'],

    // Anything the module ships. Paths are relative to the module directory
    // and cannot escape it.
    'resources'   => [
        'models'      => ['path' => 'src/Model',      'namespace' => 'Modules\Gateways\Stripe\Model'],
        'schemas'     => ['path' => 'src/Schema',     'namespace' => 'Modules\Gateways\Stripe\Schema'],
        'controllers' => ['path' => 'src/Controller', 'namespace' => 'Modules\Gateways\Stripe\Controller'],
        'jobs'        => ['path' => 'src/Job',        'namespace' => 'Modules\Gateways\Stripe\Job'],
        'commands'    => ['path' => 'src/Command',    'namespace' => 'Modules\Gateways\Stripe\Command'],
        'routes'      => ['path' => 'routes'],
        'hooks'       => ['path' => 'hooks'],
        'functions'   => ['path' => 'functions'],
    ],
];
```

Recognised resource kinds are `models`, `schemas`, `controllers`, `pipelines`,
`filters`, `jobs`, `commands`, `functions`, `hooks` and `routes`. Anything else
in `resources` is ignored rather than half-registered.

**The manifest must be a declaration and nothing else.** It is read more than
once in a request — the loader reads it during autoload, and the Modules screen
reads it again to list what is installed — so a manifest that registers a hook,
opens a connection or writes a file does all of that twice. Put that work in the
module's own `hooks/` or `functions/` files, which are loaded once.

Every PHP file in a module should open with the same guard the rest of the
application uses, the manifest included:

```php
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');
```

Each kind is held to the same contract as the application's own: a `schemas`
directory whose classes do not extend `Laika\Model\Contract\SchemaAbstract` is
refused at registration, rather than failing in the middle of a migration.

## Enabling

A module does nothing until it is switched on in **Admin → Modules**. Enabled
state is an option (`module_enabled_<uid>`), and the uid comes from where the
module sits — `gateways/Stripe` is `gateways-stripe` on every install.

Switching one on takes effect on the **next** request. Discovery runs during
composer's autoload, because the dispatcher requires every route file before it
matches a route — so by the time a page can toggle a switch, discovery is long
past. The Modules screen says `Pending` until then.

A disabled module costs a `glob()`: its manifest is never read, its classes are
not autoloadable, and `php laika app:migrate` cannot see its schemas.

## Migrations

A module that declares `schemas` is picked up by `php laika app:migrate` with no
extra wiring — but only while it is enabled. Disabling a module does **not**
drop its tables; that is deliberate, because a module switched off for an
afternoon should not take a client's data with it.

## Assets

This directory is **not** web-servable, so a module shipping CSS, JS or images
must publish them into `assets/modules/<name>/` on activation.

What makes it unservable changed, and the difference matters. It used to be the
framework: `Dispatcher` held an allowlist of servable roots and `modules` was
not on it. As of laika-route v2.0.2 that allowlist is gone - the dispatcher now
denies only `lf-*`, `vendor` and `docs` and serves everything else, gated by the
extension list in `lf-config/assets.php`. So the framework would hand out a
module's files today.

What stops it is the web server:

- **Apache** - `modules/.htaccess`, `Require all denied`. That file used to be
  defence in depth. It is now the only thing standing between third-party module
  code and the web, so do not remove it.
- **nginx** - the shipped `nginx.conf` denies `modules/` for the same reason. If
  you wrote your own server block, add it:

  ```
  location ~ ^/modules(/|$) { deny all; }
  ```

This is why the publish-on-activation convention stays: a module is code an
operator dropped in, and it routinely carries gateway API keys and registrar
credentials in a file beside the manifest. `php` and `json` are refused
everywhere by extension, but `txt` and `csv` are not - a module shipping
`credentials.txt` would be readable without the deny above.

Templates work the other way round - `template/` *is* servable, so a template
keeps its assets inside itself at `template/<area>/<name>/assets/` and links
them from its own `partials/header.twig`. The two conventions differ because a
template is installed by copying one directory and is expected to be swapped at
runtime, while a module is third-party code that happens to ship a few files.
