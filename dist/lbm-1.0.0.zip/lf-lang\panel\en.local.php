<?php
/**
 * Laika Bill Manager - English, client panel.
 *
 * Loaded by LBM\Pipeline\GlobalPipeline::language() for every /panel request.
 *
 * The class name is fixed and un-namespaced because that is what laika-core's
 * local() reads: it resolves LANG::$$key and nothing else. That is also why every
 * area gets its own file - require_once'ing a second one in the same request is a
 * fatal, so strings shared with the admin and installer catalogues are copied
 * rather than shared. There is no mechanism to share them.
 *
 * Values are sprintf() formats. Placeholders are %s / %d, and a literal percent
 * has to be written %%.
 *
 * Keys are deduplicated by meaning, not by screen. A key that is not here throws
 * rather than rendering empty, so a missing string surfaces the moment the screen
 * is opened instead of shipping blank.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');

class LANG
{
    ############################################################################
    /*============================ SHARED CHROME =============================*/
    ############################################################################

    public static string $dashboard = 'Dashboard';
    public static string $services = 'Services';
    public static string $domains = 'Domains';
    public static string $invoices = 'Invoices';
    public static string $support = 'Support';
    public static string $my_details = 'My details';
    public static string $my_account = 'My account';
    public static string $help = 'Help';
    public static string $account = 'Account';
    public static string $sign_out = 'Sign out';
    public static string $toggle_navigation = 'Toggle navigation';
    public static string $sign_in_to_continue = 'Sign in to continue';
    /** %s is the account holder name, already wrapped in a <strong> element. */
    public static string $signed_in_on = 'Signed in on %s';

    public static string $dismiss = 'Dismiss';
    public static string $there_is_a_problem = 'There is a problem';
    public static string $there_are_problems = 'There are problems';
    public static string $search_placeholder = 'Search…';
    public static string $apply = 'Apply';
    public static string $any_status = 'Any status';
    public static string $pagination = 'Pagination';
    public static string $records = 'records';
    /** %s is a row count, %s the noun for what is listed. */
    public static string $showing_n = 'Showing %s %s';
    /** Appended to $showing_n when more rows follow. */
    public static string $of_more = ' of more';
    public static string $first = 'First';
    public static string $next = 'Next';

    ############################################################################
    /*=============================== SIGN IN ================================*/
    ############################################################################

    public static string $sign_in_to_your_account = 'Sign in to your account';
    public static string $username_or_email = 'Username or email';
    public static string $username = 'Username';
    public static string $password = 'Password';
    public static string $sign_in = 'Sign in';
    public static string $require_sign_in = 'Sign in required';
    public static string $forgotten_password = 'Forgotten your password?';
    public static string $no_account_yet = 'No account yet?';
    public static string $create_one = 'Create one';

    public static string $create_your_account = 'Create your account';
    public static string $first_name = 'First name';
    public static string $last_name = 'Last name';
    public static string $company = 'Company';
    public static string $company_hint = 'Only if the account is for a business.';
    public static string $email_address = 'Email address';
    public static string $username_hint = 'Optional — you can sign in with your email address instead.';
    public static string $country = 'Country';
    public static string $choose_a_country = 'Choose a country';
    public static string $password_again = 'Password again';
    public static string $create_my_account = 'Create my account';
    public static string $already_have_account = 'Already have an account?';

    public static string $we_will_email_a_link = 'We will email you a link';
    public static string $account_email_hint = 'The address on your account.';
    public static string $send_the_link = 'Send the link';
    public static string $remembered_it = 'Remembered it?';

    public static string $choose_a_new_password = 'Choose a new password';
    public static string $new_password = 'New password';
    public static string $new_password_again = 'New password again';
    public static string $change_my_password = 'Change my password';

    ############################################################################
    /*============================== DASHBOARD ===============================*/
    ############################################################################

    /** %s is the person signed in. */
    public static string $welcome_back = 'Welcome back, %s';
    public static string $account_standing = 'Here is where your account stands today.';
    public static string $outstanding = 'Outstanding';
    public static string $outstanding_label = 'Outstanding:';
    /** %s is a count. */
    public static string $active_service = 'Active service';
    public static string $active_services = 'Active services';
    public static string $open_ticket = 'Open ticket';
    public static string $open_tickets = 'Open tickets';
    public static string $account_credit = 'Account credit';
    public static string $awaiting_payment = 'Awaiting payment';
    public static string $all_invoices = 'All invoices';
    public static string $all_paid_up = 'Nothing outstanding. You are all paid up.';
    public static string $renewing_soon = 'Renewing soon';
    public static string $all_services = 'All services';
    /** %s is a number of days. */
    public static string $nothing_renews_in = 'Nothing renews in the next %s days.';
    public static string $domains_expiring = 'Domains expiring';
    public static string $all_domains = 'All domains';
    public static string $days_left = 'Days left';
    public static string $recent_support = 'Recent support';
    public static string $open_a_ticket = 'Open a ticket';
    public static string $nothing_with_support = 'You have not raised anything with support.';
    /** %s is a numeric service id. */
    public static string $service_number = 'Service #%s';

    ############################################################################
    /*============================ COMMON COLUMNS ============================*/
    ############################################################################

    public static string $invoice = 'Invoice';
    public static string $service = 'Service';
    public static string $product = 'Product';
    public static string $domain = 'Domain';
    public static string $subject = 'Subject';
    public static string $due = 'Due';
    public static string $raised = 'Raised';
    public static string $renews = 'Renews';
    public static string $expires = 'Expires';
    public static string $balance = 'Balance';
    public static string $amount = 'Amount';
    public static string $total = 'Total';
    public static string $status = 'Status';
    public static string $last_reply = 'Last reply';
    public static string $overdue = 'Overdue';
    public static string $view = 'View';

    /** Passed to the toolbar count() and pagination show() macros. Lower case. */
    public static string $count_service = 'service';
    public static string $count_services = 'services';
    public static string $count_invoice = 'invoice';
    public static string $count_invoices = 'invoices';
    public static string $count_domain = 'domain';
    public static string $count_domains = 'domains';
    public static string $count_ticket = 'ticket';
    public static string $count_tickets = 'tickets';

    public static string $no_services_in_state = 'Nothing of yours is in that state.';
    public static string $no_services_yet = 'You do not have any services yet.';
    public static string $no_invoices_in_state = 'No invoice of yours is in that state.';
    public static string $no_invoices_yet = 'You have no invoices yet.';

    ############################################################################
    /*============================= LIST SCREENS =============================*/
    ############################################################################

    public static string $no_domains = 'You do not have any domains with us.';
    public static string $registered = 'Registered';
    public static string $auto_renew = 'Auto-renew';
    public static string $on = 'On';
    public static string $off = 'Off';

    public static string $ticket = 'Ticket';
    public static string $opened = 'Opened';
    public static string $open_first_ticket = 'Open your first ticket';

    public static string $name = 'Name';
    public static string $email = 'Email';
    public static string $sign_in_column = 'Sign-in';
    public static string $can_reach = 'Can reach';
    public static string $primary = 'Primary';
    public static string $no_access = 'No access';
    public static string $nothing = 'Nothing';
    public static string $add_a_sub_login = 'Add a sub-login';
    public static string $no_sub_logins = 'Nobody else can sign in to this account.';
    public static string $add_first_sub_login = 'Add the first sub-login';
    /** %s is the contact name. */
    public static string $confirm_remove_contact = 'Remove %s? They will no longer be able to sign in.';

    ############################################################################
    /*============================ DETAIL SCREENS ============================*/
    ############################################################################

    public static string $service_suspended = 'This service is suspended.';
    public static string $next_renewal = 'Next renewal';
    public static string $billing = 'Billing';
    public static string $server = 'Server';
    public static string $ended = 'Ended';
    public static string $add_ons = 'Add-ons';
    public static string $add_on = 'Add-on';
    public static string $login_details = 'Login details';
    public static string $show_password = 'Show password';
    public static string $cancel_this_service = 'Cancel this service';
    public static string $confirm_cancel_service = 'Raise a cancellation request for this service?';
    public static string $cancel = 'Cancel';
    public static string $at_end_of_term = 'At the end of the current term';
    public static string $immediately = 'Immediately';
    public static string $why_cancelling = 'Why are you cancelling?';
    public static string $why_cancelling_placeholder = 'This helps us put it right if something went wrong.';
    public static string $request_cancellation = 'Request cancellation';

    public static string $registrar_lock = 'Registrar lock';
    public static string $locked = 'Locked';
    public static string $unlocked = 'Unlocked';
    public static string $id_protection = 'ID protection';
    public static string $to_renew_transfer = 'To renew, transfer or unlock this domain,';
    public static string $raise_a_ticket = 'raise a ticket';
    public static string $please_contact_support = 'please contact support.';
    public static string $nameservers = 'Nameservers';
    public static string $confirm_change_nameservers = 'Change the nameservers for this domain?';
    public static string $save_nameservers = 'Save nameservers';
    /** %s is a minimum count. */
    public static string $nameservers_hint = 'At least %s are needed. A change is recorded here and passed to support to apply at the registrar — it does not take effect on its own.';
    public static string $no_nameservers = 'No nameservers are recorded for this domain.';

    public static string $print = 'Print';
    public static string $description = 'Description';
    public static string $qty = 'Qty';
    public static string $unit_price = 'Unit price';
    public static string $subtotal = 'Subtotal';
    public static string $discount = 'Discount';
    /** %s is a tax percentage. The %% is a literal percent sign. */
    public static string $tax_percent_of = 'Tax (%s%%)';
    public static string $paid = 'Paid';
    public static string $credit_applied = 'Credit applied';
    public static string $balance_due = 'Balance due';
    public static string $payments = 'Payments';
    public static string $date = 'Date';
    public static string $type = 'Type';
    public static string $reference = 'Reference';
    public static string $payment = 'Payment';
    public static string $invoice_settled = 'This invoice is settled in full.';
    public static string $your_account_credit = 'Your account credit';
    public static string $confirm_use_credit = 'Put your account credit towards this invoice?';
    public static string $use_my_account_credit = 'Use my account credit';

    ############################################################################
    /*====================== TICKET, PROFILE, CONTACT ========================*/
    ############################################################################

    public static string $confirm_close_ticket = 'Close this ticket? Replying to it will open it again.';
    public static string $close_ticket = 'Close ticket';
    public static string $you = 'You';
    public static string $system = 'System';
    public static string $reply = 'Reply';
    public static string $reply_placeholder = 'Add to this ticket…';
    public static string $replying_reopens = 'Replying will reopen this ticket.';
    public static string $send_reply = 'Send reply';
    public static string $details = 'Details';
    public static string $department = 'Department';
    public static string $replies = 'Replies';
    public static string $all_tickets = 'All tickets';

    public static string $choose_a_department = 'Choose a department';
    public static string $department_hint = 'Pick the team closest to what you need.';
    public static string $subject_placeholder = 'A short summary';
    public static string $related_service = 'Related service';
    public static string $not_about_a_service = 'Not about a specific service';
    public static string $priority = 'Priority';
    public static string $how_can_we_help = 'How can we help?';
    public static string $message_placeholder = 'Tell us what is happening, and what you have already tried.';

    public static string $who_they_are = 'Who they are';
    public static string $code = 'Code';
    public static string $phone = 'Phone';
    public static string $sign_in_heading = 'Sign-in';
    public static string $contact_username_hint = 'They can sign in with this or with their email address.';
    public static string $contact_password_keep = 'Leave blank to keep the password they already have.';
    public static string $contact_password_new = 'They will need this to sign in.';
    public static string $what_they_can_reach = 'What they can reach';
    public static string $area = 'Area';
    public static string $save_sub_login = 'Save sub-login';
    public static string $add_sub_login = 'Add sub-login';

    public static string $street = 'Street';
    public static string $city = 'City';
    public static string $state_or_county = 'State or county';
    public static string $postcode = 'Postcode';
    public static string $save_my_details = 'Save my details';
    public static string $password_note_contact = 'This changes your sign-in password, not the password of the account holder.';
    public static string $current_password = 'Current password';
    public static string $change_password = 'Change password';
    public static string $billing_currency = 'Billing currency';
    public static string $confirm_change_currency = 'Change the currency you are billed in?';
    public static string $bill_me_in = 'Bill me in';
    public static string $currency_note = 'Invoices already raised keep the currency they were issued in.';
    public static string $change_currency = 'Change currency';
    public static string $sub_logins = 'Sub-logins';
    public static string $manage = 'Manage';

    public static string $back = 'Back';
    public static string $billed_to = 'Billed to';
    public static string $unit = 'Unit';
    /** %s is a formatted date. */
    public static string $issued_on = 'Issued %s';
    /** %s is a formatted date. */
    public static string $due_on = 'Due %s';

    public static string $contact_blank_note = 'Leave both blank for a contact who only needs to be on record — somebody listed for correspondence who does not sign in.';
    public static string $grant_everything = 'Grant everything';
    public static string $sub_login_limit_note = 'A sub-login can never manage other sub-logins, whatever is ticked here — that stays with you.';
    public static string $no_invoice_lines = 'This invoice has no line items.';
    public static string $credit_smaller_note = 'Whichever is smaller — your credit or the balance — is applied.';
    public static string $email_locked_note = 'This is what you sign in with. To change it, please contact support.';
    public static string $no_sub_logins_note = 'Nobody else can sign in to this account. Add a sub-login to give a colleague their own password.';
    public static string $cancellation_note = 'This raises a cancellation request with support rather than stopping the service straight away, so nothing is switched off before somebody has read it.';

    public static string $settle_invoice_note = 'To settle this invoice, please follow the payment instructions on it or contact support.';

    ############################################################################
    /*========================= CONTROLLER MESSAGES ==========================*/
    ############################################################################

    public static string $enter_username_or_email = 'Enter your username or email address.';
    public static string $enter_password = 'Enter your password.';
    public static string $signed_in = 'Signed in.';
    public static string $signed_out = 'Signed out.';
    public static string $enter_account_email = 'Enter the email address on your account.';
    public static string $not_an_email_address = 'That does not look like an email address.';
    public static string $reset_your_password = 'Reset your password';
    public static string $reset_link_expired = 'That reset link has expired or has already been used.';
    public static string $password_changed_sign_in = 'Your password has been changed. Sign in with it.';
    public static string $registration_not_open = 'Registration is not open.';
    public static string $account_ready = 'Your account is ready. Sign in to continue.';
    public static string $create_an_account = 'Create an account';
    public static string $not_signed_in = 'You are not signed in.';
    /** %s is the kind of record that was not found. */
    public static string $record_not_found = 'That %s does not exist.';
    public static string $no_access_to_that = 'Your account does not have access to that.';

    public static string $my_services = 'My services';
    public static string $my_domains = 'My domains';
    public static string $my_invoices = 'My invoices';
    public static string $renewing_soon_title = 'Renewing Soon';
    /** %s is a minimum count. */
    public static string $domain_needs_at_least = 'A domain needs at least %s nameservers.';
    /** %s is a maximum count. */
    public static string $domain_takes_at_most = 'A domain takes at most %s nameservers.';
    public static string $nameservers_recorded = 'Your nameservers have been recorded and passed to support.';
    public static string $invoice_already_settled = 'That invoice is already settled.';
    public static string $no_credit_available = 'There is no credit on your account to put towards this invoice.';
    public static string $credit_applied_to_invoice = 'Your account credit has been put towards this invoice.';
    public static string $cancellation_raised = 'Your cancellation request has been raised with support.';

    public static string $give_ticket_subject = 'Give your ticket a subject.';
    public static string $describe_your_problem = 'Describe what you need help with.';
    public static string $ticket_raised = 'Your ticket has been raised.';
    public static string $reply_added = 'Your reply has been added.';
    public static string $ticket_closed = 'Ticket closed. Replying to it will open it again.';

    public static string $your_first_name_required = 'Your first name is required.';
    public static string $your_last_name_required = 'Your last name is required.';
    public static string $check_the_form = 'Please check the form and try again.';
    public static string $details_saved = 'Your details have been saved.';
    public static string $password_changed = 'Your password has been changed.';
    public static string $currency_not_billed_in = 'That is not a currency this site bills in.';
    public static string $currency_changed = 'Your billing currency has been changed. Invoices already raised keep the currency they were issued in.';
    public static string $first_name_required = 'A first name is required.';
    public static string $last_name_required = 'A last name is required.';
    public static string $email_required = 'An email address is required.';
    public static string $contact_email_taken = 'A contact already uses that email address.';
    public static string $other_contact_email_taken = 'Another contact already uses that email address.';
    public static string $sub_login_added = 'The sub-login has been added.';
    public static string $sub_login_saved = 'The sub-login has been saved.';
    public static string $sub_login_removed = 'The sub-login has been removed.';
    public static string $edit_sub_login = 'Edit sub-login';
    public static string $only_holder_manages_sub_logins = 'Only the account holder can manage sub-logins.';

    /** %s is an invoice number. */
    public static string $invoice_titled = 'Invoice %s';
    /** %s is a ticket number. */
    public static string $ticket_titled = 'Ticket %s';

    /** %s is a permission name such as invoice.read. */
    public static string $no_permission_to = 'You do not have permission to %s.';
}
