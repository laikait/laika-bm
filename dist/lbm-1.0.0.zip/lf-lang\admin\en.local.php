<?php
/**
 * Laika Bill Manager - English, admin area.
 *
 * Loaded by LBM\Pipeline\GlobalPipeline::language() for every /admin request.
 *
 * The class name is fixed and un-namespaced because that is what laika-core's
 * local() reads: it resolves LANG::$$key and nothing else. That is also why every
 * area gets its own file - require_once'ing a second one in the same request is a
 * fatal, so strings shared with the panel and installer catalogues are copied
 * rather than shared. There is no mechanism to share them.
 *
 * Values are sprintf() formats. Placeholders are %s / %d, and a literal percent
 * has to be written %%. Arguments come from the call site:
 *
 *     {{ 'showing_n'|local(rows, label) }}
 *     local('deleted_invoice', $number)
 *
 * Keys are deduplicated by meaning, not by screen: one key per distinct string,
 * reused wherever that string appears.
 *
 * A key that is not here throws rather than rendering empty, so a missing string
 * surfaces the moment the screen is opened instead of shipping blank.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');

class LANG
{
    ############################################################################
    /*============================= NAVIGATION ===============================*/
    ############################################################################

    public static string $dashboard = 'Dashboard';
    public static string $clients = 'Clients';
    public static string $products = 'Products';
    public static string $orders = 'Orders';
    public static string $invoices = 'Invoices';
    public static string $transactions = 'Transactions';
    public static string $support = 'Support';
    public static string $domains = 'Domains';
    public static string $servers = 'Servers';
    public static string $reports = 'Reports';
    public static string $staff = 'Staff';
    public static string $roles = 'Roles';
    public static string $currencies = 'Currencies';
    public static string $modules = 'Modules';
    public static string $activity = 'Activity';
    public static string $settings = 'Settings';

    /** Sidebar section headings. */
    public static string $billing = 'Billing';
    public static string $operations = 'Operations';
    public static string $administration = 'Administration';

    public static string $toggle_navigation = 'Toggle navigation';
    public static string $account = 'Account';
    public static string $my_account = 'My account';
    public static string $sign_out = 'Sign out';
    public static string $sign_in_to_continue = 'Sign in to continue';

    ############################################################################
    /*=========================== SETTINGS TABS ==============================*/
    ############################################################################

    public static string $general = 'General';
    public static string $localisation = 'Localisation';
    public static string $security = 'Security';
    public static string $mail = 'Mail';
    public static string $templates = 'Templates';
    public static string $statuses = 'Statuses';

    ############################################################################
    /*=========================== SHARED CHROME ==============================*/
    ############################################################################

    public static string $dismiss = 'Dismiss';
    public static string $there_is_a_problem = 'There is a problem';
    public static string $there_are_problems = 'There are problems';

    public static string $search_placeholder = 'Search…';
    public static string $apply = 'Apply';
    public static string $any_status = 'Any status';

    public static string $pagination = 'Pagination';
    public static string $records = 'records';
    /** %s is a row count, %s the noun for what is listed. */
    public static string $showing_n = 'Showing %s %s';
    /** Appended to $showing_n when more rows follow. */
    public static string $of_more = ' of more';
    public static string $first = 'First';
    public static string $next = 'Next';

    ############################################################################
    /*=========================== COUNTED NOUNS ==============================*/
    ############################################################################

    /** Passed to the toolbar count() and pagination show() macros. Lower case. */
    public static string $count_client = 'client';
    public static string $count_clients = 'clients';
    public static string $count_product = 'product';
    public static string $count_products = 'products';
    public static string $count_order = 'order';
    public static string $count_orders = 'orders';
    public static string $count_invoice = 'invoice';
    public static string $count_invoices = 'invoices';
    public static string $count_transaction = 'transaction';
    public static string $count_transactions = 'transactions';
    public static string $count_ticket = 'ticket';
    public static string $count_tickets = 'tickets';
    public static string $count_domain = 'domain';
    public static string $count_domains = 'domains';
    public static string $count_server = 'server';
    public static string $count_servers = 'servers';
    public static string $count_staff = 'staff member';
    public static string $count_staffs = 'staff';
    public static string $count_role = 'role';
    public static string $count_roles = 'roles';
    public static string $count_currency = 'currency';
    public static string $count_currencies = 'currencies';
    public static string $count_activity = 'entry';
    public static string $count_activities = 'entries';

    ############################################################################
    /*=========================== COMMON COLUMNS =============================*/
    ############################################################################

    public static string $client = 'Client';
    public static string $product = 'Product';
    public static string $order = 'Order';
    public static string $invoice = 'Invoice';
    public static string $group = 'Group';
    public static string $email = 'Email';
    public static string $country = 'Country';
    public static string $credit = 'Credit';
    public static string $status = 'Status';
    public static string $added = 'Added';
    public static string $placed = 'Placed';
    public static string $total = 'Total';
    public static string $setup_fee = 'Setup fee';
    public static string $any_country = 'Any country';
    public static string $any_group = 'Any group';

    ############################################################################
    /*============================ LIST SCREENS ==============================*/
    ############################################################################

    public static string $add_client = 'Add client';
    public static string $search_clients = 'Name, company or email…';
    public static string $no_client_matches = 'No client matches that search.';
    public static string $no_clients_yet = 'No clients yet.';
    public static string $add_first_client = 'Add the first client';

    public static string $groups = 'Groups';
    public static string $add_product = 'Add product';
    public static string $search_products = 'Product name or slug…';
    public static string $no_product_matches = 'No product matches that search.';
    public static string $nothing_for_sale = 'Nothing is for sale yet.';
    public static string $add_first_product = 'Add the first product';

    public static string $new_order = 'New order';
    public static string $search_orders = 'Order number or client…';
    public static string $no_order_matches = 'No order matches that search.';
    public static string $no_orders_yet = 'No orders yet.';
    public static string $place_first_order = 'Place the first order';
    public static string $invoiced = 'Invoiced';

    public static string $search_invoices = 'Invoice number or client…';
    public static string $no_invoice_matches = 'No invoice matches that search.';
    public static string $no_invoices_yet = 'No invoices yet.';
    public static string $raise_first_invoice = 'Raise the first invoice';
    public static string $due = 'Due';
    public static string $balance = 'Balance';

    public static string $received_this_month = 'Received this month, net of refunds';
    public static string $search_transactions = 'Reference, description or client…';
    public static string $any_type = 'Any type';
    public static string $nothing_matches = 'Nothing matches that search.';
    public static string $no_money_moved = 'No money has moved yet.';
    public static string $record_first_payment = 'Record the first payment';
    public static string $when = 'When';
    public static string $type = 'Type';
    public static string $reference = 'Reference';
    public static string $amount = 'Amount';

    public static string $departments = 'Departments';
    public static string $search_tickets = 'Ticket number, subject or client…';
    public static string $any_priority = 'Any priority';
    public static string $any_department = 'Any department';
    public static string $no_ticket_matches = 'No ticket matches that search.';
    public static string $nobody_asked_for_help = 'Nobody has asked for help yet.';
    public static string $open_a_ticket = 'Open a ticket';
    public static string $ticket = 'Ticket';
    public static string $subject = 'Subject';
    public static string $priority = 'Priority';
    public static string $last_reply = 'Last reply';

    public static string $search_domains = 'Domain or client…';
    public static string $any_registrar = 'Any registrar';
    public static string $no_domain_matches = 'No domain matches that search.';
    public static string $no_domains_registered = 'No domains are registered.';
    public static string $domain = 'Domain';
    public static string $expires = 'Expires';
    public static string $renewal = 'Renewal';
    public static string $auto = 'Auto';

    public static string $search_servers = 'Name, hostname or IP…';
    public static string $no_server_matches = 'No server matches that search.';
    public static string $no_servers_configured = 'No servers are configured.';
    public static string $add_first_server = 'Add the first server';
    public static string $server = 'Server';
    public static string $module = 'Module';
    public static string $accounts = 'Accounts';
    public static string $actions = 'Actions';

    public static string $search_staff = 'Name, email or username…';
    public static string $any_role = 'Any role';
    public static string $nobody_matches = 'Nobody matches that search.';
    public static string $name = 'Name';
    public static string $role = 'Role';
    public static string $last_sign_in = 'Last sign-in';
    public static string $never = 'Never';

    public static string $no_roles_yet = 'No roles yet.';
    public static string $held_by = 'Held by';
    public static string $granted = 'Granted';
    /** %s is the role name. */
    public static string $confirm_delete_role = 'Delete the %s role?';

    public static string $no_currencies = 'No currencies. Add one on the right.';
    public static string $code = 'Code';
    public static string $symbols = 'Symbols';
    public static string $rate = 'Rate';
    public static string $active = 'Active';
    public static string $default_label = 'Default';
    public static string $iso_code = 'ISO code';
    public static string $iso_code_hint = 'Three letters, ISO 4217.';
    public static string $prefix = 'Prefix';
    public static string $suffix = 'Suffix';
    public static string $rate_hint = 'How much of this currency one unit of the default buys.';
    /** %s is a currency code. */
    public static string $confirm_make_default = 'Make %s the default? Existing amounts are not converted.';
    /** %s is a currency code. */
    public static string $confirm_delete_currency = 'Delete %s?';

    public static string $no_modules_installed = 'No modules are installed.';
    public static string $kind = 'Kind';
    public static string $version = 'Version';
    public static string $state = 'State';
    public static string $provides = 'Provides';
    public static string $disabled = 'Disabled';
    public static string $loaded = 'Loaded';
    public static string $failed = 'Failed';
    public static string $pending = 'Pending';
    public static string $loads_next_request = 'Loads on the next request';
    public static string $disable = 'Disable';
    public static string $enable = 'Enable';

    public static string $install_module = 'Install a module';
    public static string $module_archive = 'Module archive';
    public static string $module_kind = 'What kind of module is this?';
    public static string $choose_kind = 'Choose a kind…';
    public static string $upload = 'Upload';
    /** %s is the maximum upload size, already formatted. Example: 20MB. */
    public static string $module_archive_hint = 'A .zip holding one directory with a module.php inside it. Up to %s.';
    public static string $module_kind_hint = 'This decides where it is installed, and a module cannot change it afterwards by editing its manifest.';
    public static string $module_arrives_disabled = 'Uploaded modules arrive switched off. Nothing in one runs until you enable it.';

    public static string $search_log = 'Search the log…';
    public static string $any_event = 'Any event';
    public static string $anyone = 'Anyone';
    public static string $nothing_recorded = 'Nothing has been recorded yet.';
    public static string $event = 'Event';
    public static string $who = 'Who';
    public static string $what_happened = 'What happened';
    public static string $from = 'From';

    public static string $save = 'Save';
    public static string $make_default = 'Make default';
    public static string $delete = 'Delete';
    public static string $add_a_currency = 'Add a currency';
    public static string $installed = 'Installed';
    /** %s is the modules directory, already wrapped in a <code> element. */
    public static string $drop_module_into = 'Drop one into %s under';
    /** %s is the manifest filename, already wrapped in a <code> element. */
    public static string $with_manifest = 'with a %s manifest inside it.';

    ############################################################################
    /*============================ SIGN IN ===================================*/
    ############################################################################

    public static string $sign_in_to_admin = 'Sign in to the admin panel';
    public static string $username_or_email = 'Username or email';
    public static string $username = 'Username';
    public static string $password = 'Password';
    public static string $sign_in = 'Sign in';
    public static string $require_sign_in = 'Sign in required';
    public static string $looking_for_client_area = 'Looking for the client area?';
    public static string $sign_in_there_instead = 'Sign in there instead';

    ############################################################################
    /*============================== REPORTS =================================*/
    ############################################################################

    public static string $income = 'Income';
    public static string $report_income_text = 'What came in, month by month, and what is still owed.';
    public static string $report_orders_text = 'How orders are split across their statuses.';
    public static string $report_tickets_text = 'Ticket load by status, priority and department.';

    ############################################################################
    /*============================= DASHBOARD ================================*/
    ############################################################################

    public static string $money = 'Money';
    public static string $received_this_month_short = 'Received this month';
    public static string $no_last_month_figure = 'No figure for last month to compare against';
    public static string $last_month = 'Last month';
    public static string $still_outstanding = 'Still outstanding';
    public static string $view_all = 'View all';
    public static string $nothing_happened_yet = 'Nothing has happened yet.';
    public static string $recent_activity = 'Recent activity';
    public static string $awaiting_payment = 'Awaiting payment';
    public static string $nothing_outstanding = 'Nothing outstanding. Everything is settled.';
    public static string $latest_tickets = 'Latest tickets';
    public static string $no_tickets_opened = 'No tickets have been opened.';

    ############################################################################
    /*============================== SETTINGS ================================*/
    ############################################################################

    public static string $save_settings = 'Save settings';
    public static string $company = 'Company';
    public static string $appearance = 'Appearance';
    public static string $company_name = 'Company name';
    public static string $company_name_hint = 'Shown in the panel, on invoices and in outgoing email.';
    public static string $application_url = 'Application URL';
    public static string $application_url_hint = 'The address clients reach this system on, including https://';
    public static string $billing_email_address = 'Billing email address';
    public static string $billing_email_hint = 'Where client replies and billing notices go.';
    public static string $logo_url = 'Logo URL';
    public static string $logo_url_hint = 'Shown in the sidebar and on invoices.';
    public static string $favicon_url = 'Favicon URL';
    public static string $front_theme = 'Public site theme';
    public static string $front_theme_hint = 'Installed in template/front/.';
    public static string $admin_theme = 'Admin theme';
    public static string $admin_theme_hint = 'Installed in template/admin/.';
    public static string $client_theme = 'Client theme';
    public static string $client_theme_hint = 'Installed in template/panel/.';

    public static string $time_and_language = 'Time and language';
    public static string $numbers_and_money = 'Numbers and money';
    public static string $timezone = 'Timezone';
    public static string $language = 'Language';
    public static string $date_format = 'Date format';
    public static string $date_and_time = 'Date and time';
    public static string $time_format = 'Time format';
    public static string $default_currency = 'Default currency';
    public static string $decimal_symbol = 'Decimal symbol';
    public static string $thousand_separator = 'Thousand separator';
    public static string $rows_per_page = 'Rows per page';

    public static string $sessions = 'Sessions';
    public static string $session_lifetime = 'Session lifetime (seconds)';
    public static string $session_lifetime_hint = 'Idle timeout — activity keeps a session alive, inactivity ends it.';
    public static string $tie_sessions_to_ip = 'Tie sessions to their IP address';
    public static string $tie_sessions_hint = 'More secure, but signs out anybody whose address changes — mobile networks do';
    public static string $min_password_length = 'Minimum password length';
    public static string $min_password_hint = 'Never below 6, whatever is entered here.';
    public static string $allow_registration = 'Let clients register themselves';
    public static string $allow_registration_hint = 'With this off, only staff can create client accounts';

    public static string $numbering = 'Numbering';
    public static string $terms = 'Terms';
    public static string $invoice_prefix = 'Invoice prefix';
    public static string $invoice_prefix_hint = 'Numbers run from the record id, so they can never collide.';
    public static string $order_prefix = 'Order prefix';
    public static string $payment_terms_days = 'Payment terms (days)';
    public static string $payment_terms_hint = 'How long a new invoice gets before it is due.';
    /** The %% is a literal percent sign - sprintf eats a single one. */
    public static string $late_fee_percent = 'Late fee (%%)';

    public static string $delivery = 'Delivery';
    public static string $from_heading = 'From';
    public static string $connection = 'Connection';
    public static string $driver = 'Driver';
    public static string $encryption = 'Encryption';
    public static string $host = 'Host';
    public static string $port = 'Port';
    public static string $from_address = 'From address';
    public static string $from_name = 'From name';
    public static string $timeout_seconds = 'Timeout (s)';
    public static string $charset = 'Charset';
    public static string $debug_level = 'Debug level';
    public static string $debug_level_hint = '0 is silent.';
    public static string $upgrade_to_tls = 'Upgrade to TLS when offered';
    public static string $verify_certificate = 'Verify the server certificate';
    public static string $verify_certificate_hint = 'Leave on unless your mail server uses a self-signed certificate';
    public static string $keep_connection_open = 'Keep the connection open between messages';
    public static string $send_a_test = 'Send a test';
    /** %s is the worker command, already wrapped in a <code> element. */
    public static string $test_mail_intro = 'The test goes onto the queue, exactly like a real notification. Run %s to send it — nothing is ever sent during a web request.';
    /** %s is a message count. */
    public static string $messages_queued_one = '%s message waiting in the queue.';
    public static string $messages_queued_many = '%s messages waiting in the queue.';
    public static string $send_to = 'Send to';
    public static string $send_to_hint = 'Blank sends to the billing address.';
    public static string $queue_test_message = 'Queue a test message';

    ############################################################################
    /*============================ CLIENT SCREEN =============================*/
    ############################################################################

    public static string $restricted = 'Restricted';
    public static string $edit = 'Edit';
    public static string $contacts = 'Contacts';
    public static string $notes = 'Notes';
    public static string $all_notes = 'All notes';
    public static string $confirm_delete_client = 'Delete this client? Their contacts and notes go too. Invoices and payments are kept.';
    public static string $outstanding = 'Outstanding';
    public static string $credit_balance = 'Credit balance';
    public static string $client_since = 'Client since';
    public static string $tickets = 'Tickets';
    public static string $payments = 'Payments';
    public static string $nothing_paid_yet = 'Nothing has been paid yet.';
    public static string $latest_notes = 'Latest notes';
    public static string $no_notes_yet = 'Nobody has left a note yet.';
    /** %s is a lower-cased panel name: invoices, orders, tickets, domains. */
    public static string $none_for_this_client = 'No %s for this client.';

    ############################################################################
    /*============================= CLIENT FORM ==============================*/
    ############################################################################

    public static string $person = 'Person';
    public static string $address = 'Address';
    public static string $sign_in_heading = 'Sign-in';
    public static string $middle_name = 'Middle name';
    public static string $dialling_code = 'Dialling code';
    public static string $phone = 'Phone';
    public static string $street = 'Street';
    public static string $city = 'City';
    public static string $state_or_region = 'State or region';
    public static string $postcode = 'Postcode';
    public static string $not_set = 'Not set';
    public static string $username_hint = 'Optional. With none, they sign in with their email address.';
    public static string $password_keep_hint = 'Leave blank to keep the current password.';
    public static string $password_later_hint = 'Leave blank to set one later.';
    public static string $confirm_password = 'Confirm password';
    public static string $currency = 'Currency';
    public static string $currency_hint = 'What this client is invoiced in.';
    public static string $tax_id = 'Tax ID';
    public static string $tax_id_hint = 'VAT, GST, EIN — whatever applies.';
    public static string $tax_exempt = 'Tax exempt';
    public static string $tax_exempt_hint = 'Do not add tax to invoices for this client';
    public static string $restricted_hint = 'Block this account from signing in';
    public static string $save_changes = 'Save changes';
    public static string $first_name = 'First name';
    public static string $last_name = 'Last name';
    public static string $email_address = 'Email address';

    ############################################################################
    /*=============================== INVOICE ================================*/
    ############################################################################

    public static string $overdue = 'Overdue';
    public static string $email_action = 'Email';
    public static string $cancel = 'Cancel';
    public static string $confirm_cancel_invoice = 'Cancel this invoice?';
    /** %s is the invoice number. */
    public static string $confirm_delete_invoice = 'Delete %s and its lines? Payments already recorded are kept.';
    public static string $lines = 'Lines';
    public static string $description = 'Description';
    public static string $qty = 'Qty';
    public static string $unit = 'Unit';
    public static string $unit_price = 'Unit price';
    public static string $discount = 'Discount';
    public static string $no_invoice_lines = 'No lines on this invoice.';
    public static string $nothing_paid_this_invoice = 'Nothing has been paid against this invoice.';
    public static string $totals = 'Totals';
    public static string $subtotal = 'Subtotal';
    public static string $paid = 'Paid';
    public static string $credit_applied = 'Credit applied';
    public static string $record_a_payment = 'Record a payment';
    public static string $amount_hint = 'Defaults to the balance still owed.';
    public static string $reference_placeholder = 'Bank reference, cheque number…';
    public static string $record_payment = 'Record payment';

    public static string $choose_a_client = 'Choose a client';
    public static string $due_date = 'Due date';
    public static string $discount_hint = 'An amount, taken off before tax.';
    /** The %% is a literal percent sign. */
    public static string $tax_percent = 'Tax (%%)';
    public static string $save_invoice = 'Save invoice';
    public static string $raise_invoice = 'Raise invoice';

    ############################################################################
    /*================================ ORDER =================================*/
    ############################################################################

    public static string $confirm_accept_order = 'Accept this order and raise an invoice for it?';
    public static string $confirm_cancel_order = 'Cancel this order?';
    public static string $confirm_delete_order = 'Delete this order?';
    public static string $accept_and_invoice = 'Accept &amp; invoice';
    public static string $order_has_no_lines = 'This order has no lines.';
    public static string $item = 'Item';
    public static string $cycle = 'Cycle';
    public static string $each = 'Each';
    public static string $line_total = 'Line total';
    public static string $billing_cycle = 'Billing cycle';
    public static string $save_order = 'Save order';
    public static string $place_order = 'Place order';

    ############################################################################
    /*=============================== PRODUCT ================================*/
    ############################################################################

    public static string $featured = 'Featured';
    public static string $no_group = 'No group';
    /** %s is the product name. */
    public static string $confirm_delete_product = 'Delete %s?';
    public static string $pricing = 'Pricing';
    public static string $pricing_blank_hint = 'Blank means not sold on that cycle';
    public static string $add_currency_before_pricing = 'Add a currency before pricing anything.';
    public static string $save_pricing = 'Save pricing';
    public static string $slug = 'Slug';
    public static string $slug_hint = 'Used in URLs. Left blank, one is made from the name; a duplicate is suffixed rather than refused.';
    public static string $choose_a_group = 'Choose a group';
    public static string $choose_a_type = 'Choose a type';
    public static string $provisioning = 'Provisioning';
    public static string $module_hint = 'The provisioning module that sets this product up. Blank for something delivered by hand.';
    public static string $limited_stock = 'Limited stock';
    public static string $limited_stock_hint = 'Stop selling once the quantity runs out';
    public static string $quantity_available = 'Quantity available';
    public static string $charging = 'Charging';
    public static string $pricing_model = 'Pricing model';
    public static string $default_setup_fee = 'Default setup fee';
    public static string $setup_fee_hint = 'A per-currency setup fee on the price grid overrides this.';
    /** The %% is a literal percent sign. */
    public static string $tax_rate_percent = 'Tax rate (%%)';
    public static string $featured_hint = 'Show this product ahead of the others';
    public static string $no_groups_yet = 'No groups yet. Add one on the right.';
    public static string $on_sale = 'On sale';
    public static string $on_sale_hint = 'Offer this group to clients';
    public static string $add_a_group = 'Add a group';
    public static string $add_group = 'Add group';
    /** %s is the group name. */
    public static string $confirm_delete_group = 'Delete %s?';

    ############################################################################
    /*================================ TICKET ================================*/
    ############################################################################

    public static string $confirm_delete_ticket = 'Delete this ticket and every reply on it?';
    /** %s is a formatted date. */
    public static string $opened_on = 'opened %s';
    public static string $internal_note_badge = 'Internal note — the client cannot see this';
    public static string $reply = 'Reply';
    public static string $message = 'Message';
    public static string $internal_note = 'Internal note';
    public static string $internal_note_hint = 'Visible to staff only — the client will never see this';
    public static string $send_reply = 'Send reply';
    public static string $handling = 'Handling';
    public static string $assigned_to = 'Assigned to';
    public static string $nobody = 'Nobody';
    public static string $update = 'Update';
    public static string $new_ticket = 'New ticket';
    public static string $department = 'Department';
    public static string $choose_a_department = 'Choose a department';
    public static string $open_ticket = 'Open ticket';
    public static string $no_departments_yet = 'No departments yet. Add one on the right.';
    public static string $inbound_email = 'Inbound email';
    public static string $visible = 'Visible';
    public static string $add_a_department = 'Add a department';
    public static string $add_department = 'Add department';
    public static string $inbound_email_hint = 'Where replies to this department arrive, if you route any.';
    public static string $auto_close_after_days = 'Auto-close after (days)';
    public static string $hidden_from_clients = 'Hidden from clients';
    public static string $hidden_from_clients_hint = 'Staff can file here, clients cannot choose it';

    ############################################################################
    /*============================= STAFF & ROLES ============================*/
    ############################################################################

    public static string $no_role = 'No role';
    /** %s is the staff member name. */
    public static string $confirm_delete_staff = 'Delete %s?';
    public static string $recent_sign_ins = 'Recent sign-ins';
    public static string $never_signed_in = 'This account has never signed in.';
    public static string $what_they_have_done = 'What they have done';
    public static string $nothing_recorded_account = 'Nothing recorded against this account.';
    /** %1$s is a browser, %2$s an operating system. */
    public static string $browser_on_os = '%1$s on %2$s';
    public static string $access = 'Access';
    public static string $choose_a_role = 'Choose a role';
    public static string $role_hint = 'What they may do is decided entirely by their role.';
    public static string $add_staff_member = 'Add staff member';
    public static string $role_name = 'Role name';
    public static string $role_name_placeholder = 'Support agent';
    public static string $permissions = 'Permissions';
    public static string $grant_everything = 'Grant everything';
    public static string $area = 'Area';
    public static string $save_role = 'Save role';
    public static string $add_role = 'Add role';
    public static string $password_keep_hint_blank = 'Leave blank to keep the current password.';

    ############################################################################
    /*=========================== ACCOUNT & NOTES ============================*/
    ############################################################################

    public static string $my_details = 'My details';
    public static string $save_details = 'Save details';
    public static string $change_password = 'Change password';
    public static string $current_password = 'Current password';
    public static string $new_password = 'New password';
    public static string $confirm_new_password = 'Confirm new password';
    public static string $no_sign_ins_yet = 'No sign-ins recorded yet.';
    public static string $confirm_sign_out_everywhere = 'Sign out of every device, including this one?';
    public static string $sign_out_everywhere = 'Sign out everywhere';
    public static string $what_i_have_done = 'What I have done';
    public static string $nothing_recorded_yet = 'Nothing recorded yet.';

    /** %s is the client name. */
    public static string $back_to_client = 'Back to %s';
    public static string $add_contact = 'Add contact';
    public static string $no_contacts = 'This client has no contacts.';
    public static string $add_first_contact = 'Add the first contact';
    public static string $panel_access = 'Panel access';
    public static string $primary = 'Primary';
    public static string $email_only = 'Email only';
    public static string $remove = 'Remove';
    /** %s is the contact name. */
    public static string $confirm_remove_contact = 'Remove %s?';

    public static string $add_a_note = 'Add a note';
    public static string $note = 'Note';
    public static string $note_placeholder = 'What happened, and anything the next person needs to know.';
    public static string $save_note = 'Save note';
    public static string $no_notes_on_client = 'Nobody has left a note on this client.';
    public static string $confirm_delete_note = 'Delete this note?';

    ############################################################################
    /*============================ CONTACT & DOMAIN ==========================*/
    ############################################################################

    public static string $contact = 'Contact';
    public static string $contact_username_hint = 'Leave blank for a contact who only receives email and never signs in.';
    public static string $primary_contact = 'Primary contact';
    public static string $primary_contact_hint = 'The main person to contact about this account';
    public static string $what_they_may_do = 'What they may do';
    public static string $save_contact = 'Save contact';

    public static string $expired = 'Expired';
    /** %s is a billing cycle. */
    public static string $renews_cycle = 'renews %s';
    public static string $registration = 'Registration';
    public static string $registered = 'Registered';
    public static string $next_due = 'Next due';
    public static string $renewal_amount = 'Renewal amount';
    public static string $auto_renew = 'Auto renew';
    public static string $yes = 'Yes';
    public static string $no = 'No';
    public static string $registrar_lock = 'Registrar lock';
    public static string $locked = 'Locked';
    public static string $unlocked = 'Unlocked';
    public static string $id_protection = 'ID protection';
    public static string $on = 'On';
    public static string $off = 'Off';
    public static string $nameservers = 'Nameservers';
    public static string $no_nameservers = 'No nameservers recorded.';
    public static string $tld = 'TLD';
    public static string $registrar = 'Registrar';
    public static string $nameservers_hint = 'One per line. Order is kept as written.';
    public static string $renewal_heading = 'Renewal';
    public static string $save_domain = 'Save domain';

    ############################################################################
    /*======================== TRANSACTION & SERVER ==========================*/
    ############################################################################

    public static string $recorded = 'Recorded';
    public static string $gateway_fee = 'Gateway fee';
    public static string $refunded_so_far = 'Refunded so far';
    public static string $refund = 'Refund';
    public static string $refund_amount_hint = 'Leave blank to refund everything still refundable on this payment.';
    public static string $reason = 'Reason';
    public static string $reason_placeholder = 'Why is this being refunded?';
    public static string $record_refund = 'Record refund';
    public static string $confirm_delete_transaction = 'Delete this ledger entry? Use a refund instead unless this was typed twice.';
    public static string $delete_entry = 'Delete entry';
    public static string $payment = 'Payment';
    public static string $against_invoice = 'Against invoice';
    public static string $not_against_an_invoice = 'Not against an invoice';
    public static string $against_invoice_hint = 'Only invoices with something still owed are listed.';

    public static string $hostname = 'Hostname';
    public static string $ip_address = 'IP address';
    public static string $control_panel = 'Control panel';
    public static string $use_ssl = 'Use SSL';
    public static string $nameserver_1 = 'Nameserver 1';
    public static string $nameserver_2 = 'Nameserver 2';
    public static string $credentials = 'Credentials';
    public static string $credentials_intro = 'Stored encrypted and never shown again.';
    public static string $credentials_keep = 'Leave blank to keep what is already saved.';
    public static string $api_key = 'API key';
    public static string $allocation = 'Allocation';
    public static string $not_in_a_group = 'Not in a group';
    public static string $maximum_accounts = 'Maximum accounts';
    public static string $maximum_accounts_hint = 'Blank for no limit.';
    public static string $save_server = 'Save server';
    public static string $add_server = 'Add server';

    ############################################################################
    /*======================== PRINT & REPORT SCREENS ========================*/
    ############################################################################

    public static string $print = 'Print';
    public static string $back = 'Back';
    /** %s is a formatted date. */
    public static string $issued_on = 'Issued %s';
    /** %s is a formatted date. */
    public static string $due_on = 'Due %s';
    public static string $billed_to = 'Billed to';
    public static string $balance_due = 'Balance due';

    public static string $to = 'To';
    public static string $received_in_range = 'Received in this range';
    public static string $payments_recorded = 'Payments recorded';
    public static string $refunds = 'Refunds';
    public static string $last_twelve_months = 'The last twelve months';
    public static string $orders_in_total = 'Orders in total';
    public static string $by_status = 'By status';
    public static string $no_orders_to_report = 'No orders to report on.';
    public static string $tickets_in_total = 'Tickets in total';
    public static string $still_open = 'Still open';
    public static string $by_priority = 'By priority';
    public static string $by_department = 'By department';
    public static string $nothing_to_report = 'Nothing to report.';
    public static string $no_departments_configured = 'No departments configured.';

    public static string $save_statuses = 'Save statuses';
    public static string $email_templates = 'Email templates';
    public static string $no_templates_installed = 'No templates are installed.';
    public static string $template = 'Template';
    public static string $save_template = 'Save template';
    public static string $email_template_active_hint = 'With this off, nothing using this template is sent';
    public static string $placeholders = 'Placeholders';
    public static string $no_placeholders = 'This template declares no placeholders.';
    public static string $placeholders_intro = 'Write these in the subject or the message and they are replaced when it is sent.';

    ############################################################################
    /*========================= CONTROLLER MESSAGES ==========================*/
    ############################################################################

    public static string $enter_username_or_email = 'Enter your username or email address.';
    public static string $enter_password = 'Enter your password.';
    public static string $signed_in = 'Signed in.';
    public static string $signed_out = 'Signed out.';
    /** %s is the kind of record that was not found. */
    public static string $record_not_found = 'That %s does not exist.';
    public static string $not_an_email_address = 'That does not look like an email address.';
    /** %s is the name of whatever was deleted. */
    public static string $deleted_named = 'Deleted %s.';
    /** %s is the name of whatever is being edited. */
    public static string $edit_named = 'Edit %s';

    public static string $first_name_required = 'A first name is required.';
    public static string $last_name_required = 'A last name is required.';
    public static string $email_required = 'An email address is required.';
    public static string $username_taken = 'That username is taken.';

    public static string $client_added = 'Client added.';
    public static string $client_updated = 'Client updated.';
    public static string $client_email_taken = 'Another client already uses that email address.';
    public static string $contact_added = 'Contact added.';
    public static string $contact_updated = 'Contact updated.';
    public static string $contact_removed = 'Contact removed.';
    public static string $edit_contact = 'Edit contact';
    public static string $note_cannot_be_empty = 'A note cannot be empty.';
    public static string $note_added = 'Note added.';
    public static string $note_deleted = 'Note deleted.';

    public static string $currency_needs_iso = 'A currency needs an ISO code.';
    public static string $active_clients = 'Active clients';
    public static string $orders_awaiting_review = 'Orders awaiting review';
    public static string $open_tickets_stat = 'Open tickets';
    public static string $overdue_invoices = 'Overdue invoices';
    public static string $domain_updated = 'Domain updated.';

    public static string $choose_a_client_msg = 'Choose a client.';
    public static string $invoice_needs_line = 'An invoice needs at least one line.';
    public static string $invoice_raised_msg = 'Invoice raised.';
    public static string $new_invoice = 'New invoice';
    public static string $invoice_updated = 'Invoice updated.';
    /** %s is an invoice number. */
    public static string $invoice_titled = 'Invoice %s';
    /** %s is an invoice number. */
    public static string $edit_invoice_titled = 'Edit invoice %s';
    public static string $no_client_email = 'That client has no email address to send to.';
    public static string $invoice_queued = 'Invoice queued for sending.';
    public static string $payment_greater_than_zero = 'A payment must be greater than zero.';
    public static string $payment_recorded = 'Payment recorded.';
    public static string $invoice_cancelled = 'Invoice cancelled.';
    /** %s is an invoice number. */
    public static string $deleted_invoice = 'Deleted invoice %s.';

    public static string $order_needs_line = 'An order needs at least one line.';
    public static string $order_placed = 'Order placed.';
    public static string $order_updated = 'Order updated.';
    /** %s is an order number. */
    public static string $order_titled = 'Order %s';
    /** %s is an order number. */
    public static string $edit_order_titled = 'Edit order %s';
    public static string $order_accepted = 'Order accepted and invoiced.';
    public static string $order_cancelled = 'Order cancelled.';
    /** %s is an order number. */
    public static string $deleted_order = 'Deleted order %s.';

    public static string $product_added = 'Product added.';
    public static string $pricing_updated = 'Pricing updated.';
    public static string $product_updated = 'Product updated.';
    public static string $product_groups = 'Product groups';
    public static string $group_needs_name = 'A group needs a name.';
    public static string $group_updated = 'Group updated.';
    public static string $group_added = 'Group added.';
    public static string $product_name_required = 'A product name is required.';
    public static string $choose_group_for_product = 'Choose a group for this product.';
    public static string $choose_product_type = 'Choose a product type.';
    public static string $usage_based = 'Usage based';

    public static string $staff_email_taken = 'Another staff member already uses that email address.';
    public static string $your_details_saved = 'Your details were saved.';
    public static string $your_password_changed = 'Your password was changed.';
    public static string $signed_out_everywhere_msg = 'Signed out of every device. Sign in again to continue.';

    public static string $server_added = 'Server added.';
    public static string $server_updated = 'Server updated.';
    public static string $name_required = 'A name is required.';
    public static string $hostname_required = 'A hostname is required.';
    public static string $ip_required = 'An IP address is required.';
    public static string $which_control_panel = 'Which control panel does this server run?';

    public static string $php_mail = 'PHP mail()';
    public static string $enter_test_address = 'Enter an address to send the test to.';
    /** %s is an email address. */
    public static string $test_queued_for = 'Test message queued for %s. Run the worker to send it.';
    public static string $subject_required = 'A subject is required.';
    public static string $message_cannot_be_empty = 'The message cannot be empty.';
    public static string $template_saved = 'Template saved.';
    public static string $settings_saved = 'Settings saved.';
    public static string $nothing_to_save = 'Nothing to save.';
    public static string $statuses_saved = 'Statuses saved.';
    public static string $ticket_priorities = 'Ticket priorities';
    public static string $email_queue = 'Email queue';

    public static string $password_required = 'A password is required.';
    public static string $staff_member_added = 'Staff member added.';
    public static string $staff_member_updated = 'Staff member updated.';
    public static string $cannot_delete_own_account = 'You cannot delete your own account.';
    public static string $role_needs_name = 'A role needs a name.';
    public static string $role_added = 'Role added.';
    public static string $role_updated = 'Role updated.';
    public static string $choose_a_role_msg = 'Choose a role.';

    public static string $choose_a_department_msg = 'Choose a department.';
    public static string $ticket_needs_message = 'A ticket needs a message.';
    public static string $ticket_opened = 'Ticket opened.';
    /** %s is a ticket number. */
    public static string $ticket_titled = 'Ticket %s';
    public static string $internal_note_added = 'Internal note added.';
    public static string $reply_sent = 'Reply sent.';

    public static string $currency_updated = 'Updated %s.';
    public static string $currency_added = 'Added %s.';
    /** %s is a registrar id, used only when the registrar has no name. */
    public static string $registrar_numbered = 'Registrar %s';
    public static string $ticket_updated = 'Ticket updated.';
    /** %s is a ticket number. */
    public static string $deleted_ticket = 'Deleted ticket %s.';
    public static string $support_departments = 'Support departments';
    public static string $department_needs_name = 'A department needs a name.';
    public static string $department_updated = 'Department updated.';
    public static string $department_added = 'Department added.';
    public static string $how_much_was_paid = 'How much was paid?';
    /** %s is a transaction id. */
    public static string $transaction_numbered = 'Transaction #%s';
    public static string $refund_recorded = 'Refund recorded.';
    public static string $transaction_deleted = 'Transaction deleted.';

    /** %s is a permission name such as invoice.read. */
    public static string $no_permission_to = 'You do not have permission to %s.';

    ############################################################################
    /*============================= SITE CONTENT =============================*/
    ############################################################################
    //
    // Announcements and the knowledgebase - written here, read on the public
    // front area. Both sit under the one `content` permission group.
    //
    // The three state labels below are worth reading together, because "active"
    // on its own does not say whether the public can see something:
    //   live      - active, and its publish date has passed
    //   scheduled - active, but dated in the future
    //   retracted - switched off entirely (draft, for an article)

    public static string $site_content = 'Site content';
    public static string $announcements = 'Announcements';
    public static string $announcements_lower = 'announcements';
    public static string $knowledgebase = 'Knowledgebase';
    public static string $articles = 'articles';
    public static string $categories = 'Categories';
    public static string $category = 'Category';
    public static string $uncategorised = 'Uncategorised';
    public static string $any_category = 'Any category';

    public static string $title = 'Title';
    public static string $body = 'Body';
    public static string $url_slug = 'URL slug';
    public static string $views = 'Views';
    public static string $published = 'Published';
    public static string $filing = 'Filing';
    public static string $visibility = 'Visibility';
    public static string $publish_from = 'Publish from';
    public static string $view = 'View';

    public static string $live = 'Live';
    public static string $scheduled = 'Scheduled';
    public static string $retracted = 'Retracted';
    public static string $draft = 'Draft';
    public static string $hidden = 'Hidden';

    public static string $add_announcement = 'Add announcement';
    public static string $add_first_announcement = 'Write the first announcement';
    public static string $search_announcements = 'Search announcements';
    public static string $count_announcement = 'announcement';
    public static string $count_announcements = 'announcements';
    public static string $no_announcements_yet = 'Nothing has been announced yet.';
    public static string $no_announcement_matches = 'No announcement matches that search.';

    public static string $add_article = 'Add article';
    public static string $add_first_article = 'Write the first article';
    public static string $search_articles = 'Search articles';
    public static string $count_article = 'article';
    public static string $count_articles = 'articles';
    public static string $no_articles_yet = 'No articles have been written yet.';
    public static string $no_article_matches = 'No article matches that search.';

    public static string $add_category = 'Add category';
    public static string $add_first_category = 'Add the first category';
    public static string $no_categories_yet = 'No categories have been created yet.';

    public static string $html_allowed = 'HTML is allowed. This is rendered as written on the public site.';
    public static string $article_slug_hint = 'Leave empty to build one from the title. A duplicate is refused, not renamed.';
    public static string $publish_from_hint = 'A future date keeps it hidden until then.';
    public static string $article_featured_hint = 'Show this near the top of the support and knowledgebase pages.';
    public static string $announcement_active_hint = 'Off retracts it from the public site.';
    public static string $article_active_hint = 'Off keeps it as a draft.';
    public static string $category_active_hint = 'Off hides the category and its articles.';

    public static string $confirm_delete = 'Delete this permanently?';
    public static string $confirm_delete_category = 'Delete this category? Its articles are kept and become uncategorised.';

    /** %s is a slug that is already taken. */
    public static string $slug_taken = 'The slug "%s" is already in use.';
    public static string $title_required = 'A title is required.';
    public static string $body_required = 'Some body text is required.';

    public static string $announcement_added = 'Announcement added.';
    public static string $announcement_updated = 'Announcement updated.';
    public static string $announcement_deleted = 'Announcement deleted.';
    public static string $article_added = 'Article added.';
    public static string $article_updated = 'Article updated.';
    public static string $article_deleted = 'Article deleted.';
    public static string $category_added = 'Category added.';
    public static string $category_updated = 'Category updated.';
    public static string $category_deleted = 'Category deleted.';

    ############################################################################
    /*=========================== SCHEDULED TASKS ============================*/
    ############################################################################

    public static string $cron_never_run = 'Scheduled tasks have never run on this installation.';
    /** %s is when cron last ran, already formatted. */
    public static string $cron_stale = 'Scheduled tasks last ran %s, which is longer ago than expected.';
    /** %s is when cron last ran, already formatted. */
    public static string $cron_ok = 'Scheduled tasks last ran %s.';
    public static string $cron_setup_hint = 'Until this runs every few minutes, renewal invoices will not be raised, reminders will not be sent, and queued email will not be delivered. Schedule this command on your server:';

    ############################################################################
    /*============================ EMAIL TEMPLATES ===========================*/
    ############################################################################

    public static string $all_templates = 'All templates';
    public static string $add_template = 'New template';
    public static string $template_slug_hint = 'The name the application looks this template up by, such as invoice-created. Lower case and hyphens; it is tidied up for you.';
    public static string $template_name_hint = 'A label for this list. Only staff ever see it.';
    public static string $template_placeholder_syntax = 'Write placeholders as {{name}} — double braces. Single braces are treated as ordinary text and reach the customer unchanged. Every template can use these:';

    public static string $slug_required = 'A slug is required.';
    /** %s is a template name that is already taken. */
    public static string $template_name_taken = 'A template called "%s" already exists.';

    public static string $template_added = 'Template added.';
    public static string $template_deleted = 'Template deleted.';
    /** %s is the template name. */
    public static string $confirm_delete_template = 'Delete the "%s" template? If the application still sends it, the next migration puts the default back.';
}
