<?php
/**
 * Laika Bill Manager - English, public website.
 *
 * Loaded by LBM\Pipeline\GlobalPipeline::language() for every request that is
 * not /admin and not /panel - the bare root included. The front area owns no URL
 * prefix, so it is defined by exclusion; see area() in helpers/functions/app.php.
 *
 * The class name is fixed and un-namespaced because that is what laika-core's
 * local() reads: it resolves LANG::$$key and nothing else. That is also why every
 * area gets its own file - require_once'ing a second one in the same request is a
 * fatal, so strings shared with the admin, panel and installer catalogues are
 * copied rather than shared. There is no mechanism to share them.
 *
 * Values are sprintf() formats. Placeholders are %s / %d, and a literal percent
 * has to be written %%.
 *
 * Keys are deduplicated by meaning, not by screen. A key that is not here throws
 * rather than rendering empty, so a missing string surfaces the moment the screen
 * is opened instead of shipping blank.
 *
 * This is the one catalogue whose strings are read by strangers rather than by
 * people who already bought something, so the register is different: no jargon,
 * no abbreviations, and nothing that assumes the reader knows what the product
 * is yet.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');

class LANG
{
    ############################################################################
    /*============================ SHARED CHROME =============================*/
    ############################################################################

    public static string $menu = 'Menu';
    public static string $sign_in = 'Sign in';
    public static string $get_started = 'Get started';
    public static string $my_account = 'My account';
    public static string $admin_area = 'Admin area';
    public static string $client_area = 'Client area';
    public static string $home = 'Home';
    public static string $company = 'Company';
    public static string $legal = 'Legal';
    public static string $search = 'Search';
    public static string $learn_more = 'Learn more';
    public static string $view_all = 'View all';
    public static string $from = 'From';
    public static string $subject = 'Subject';

    /** %1$s is the current year, %2$s the company name. */
    public static string $copyright = '&copy; %1$s %2$s. All rights reserved.';
    public static string $footer_tagline = 'Hosting, domains and support, billed simply.';

    ############################################################################
    /*=============================== HOME PAGE ==============================*/
    ############################################################################

    /** %s is the company name. */
    public static string $home_meta = '%s - hosting, domains and support.';
    /** %s is the company name. */
    public static string $hero_title = 'Everything you need, in one account.';
    public static string $hero_lead = 'Order a service, pay an invoice and get help without hunting for the right page. Your billing, domains and support all live in one place.';
    public static string $browse_services = 'Browse services';
    public static string $our_services = 'Our services';
    public static string $our_services_lead = 'Pick the plan that fits. Change it whenever it stops fitting.';
    public static string $latest_news = 'Latest news';
    public static string $latest_news_lead = 'Maintenance windows, new features and anything else worth knowing.';
    public static string $no_services_yet = 'Nothing is listed for sale yet.';
    public static string $need_a_hand = 'Need a hand?';
    public static string $need_a_hand_lead = 'Search the knowledgebase, or write to us and a person will answer.';

    ############################################################################
    /*============================ STATIC PAGES ==============================*/
    ############################################################################

    public static string $about_us = 'About us';
    public static string $about_lead = 'Who we are and what we run.';
    public static string $about_body_1 = 'We host and support the services our customers depend on, and we bill for them without surprises. Every plan is listed with its full price, every invoice says what it covers, and every question reaches somebody who can answer it.';
    public static string $about_body_2 = 'This page is part of the template. Edit it to say something true about your own company - it ships with placeholder copy so the site is complete on the day it is installed, not so you leave it as it is.';

    public static string $terms_of_service = 'Terms of service';
    public static string $terms_lead = 'The agreement between us.';
    public static string $terms_placeholder = 'This page ships as a placeholder. Replace it with your own terms before taking a customer - the text here is not legal advice and is not a substitute for it.';

    public static string $privacy_policy = 'Privacy policy';
    public static string $privacy_lead = 'What we collect, and why.';
    public static string $privacy_placeholder = 'This page ships as a placeholder. Replace it with your own policy before taking a customer - what you must say depends on where you and they are.';

    public static string $placeholder_notice = 'Placeholder text';
    public static string $edit_this_page = 'Edit this page in %s';

    ############################################################################
    /*=============================== SERVICES ===============================*/
    ############################################################################

    public static string $services = 'Services';
    /** %s is the company name. */
    public static string $services_meta = 'Plans and pricing from %s.';
    public static string $services_lead = 'Everything we offer, grouped so you can find the right one.';
    /** %s is the group name. */
    public static string $service_group_meta = 'Plans and pricing in %s.';
    public static string $nothing_for_sale = 'Nothing is listed for sale yet.';
    public static string $no_products_in_group = 'Nothing is listed in this group yet.';
    public static string $setup_fee = 'Setup fee';
    public static string $one_time = 'One time';
    public static string $price_on_request = 'Price on request';
    public static string $order_now = 'Order now';
    public static string $view_plans = 'View plans';
    public static string $whats_included = 'What is included';
    public static string $pricing = 'Pricing';
    public static string $billing_cycle = 'Billing cycle';
    public static string $price = 'Price';
    public static string $no_pricing_yet = 'Pricing for this service has not been published yet. Ask us and we will quote you.';
    public static string $ask_about_this = 'Ask about this service';
    public static string $order_note = 'Ordering creates an account first, so you have somewhere to manage the service afterwards.';

    ############################################################################
    /*============================ KNOWLEDGEBASE =============================*/
    ############################################################################

    public static string $knowledgebase = 'Knowledgebase';
    /** %s is the company name. */
    public static string $knowledgebase_meta = 'Guides and answers from %s.';
    public static string $knowledgebase_lead = 'Guides, answers and how-tos. Search, or browse by category.';
    public static string $search_the_kb = 'Search the knowledgebase';
    public static string $search_results = 'Search results';
    /** %1$d is the number of results, %2$s the search term. */
    public static string $found_n_for = '%1$d result(s) for "%2$s"';
    /** %s is the search term. */
    public static string $nothing_found_for = 'Nothing matched "%s". Try a shorter phrase, or write to us.';
    public static string $browse_categories = 'Browse by category';
    public static string $popular_articles = 'Popular articles';
    public static string $no_articles_yet = 'No articles have been published yet.';
    public static string $no_categories_yet = 'No categories have been created yet.';
    /** %s is the category name. */
    public static string $kb_category_meta = 'Articles in %s.';
    /** %d is a count of articles. */
    public static string $n_articles = '%d article(s)';
    /** %d is a view count. */
    public static string $n_views = '%d view(s)';
    public static string $was_this_helpful = 'Was this helpful?';
    public static string $yes = 'Yes';
    public static string $no = 'No';
    public static string $vote_thanks = 'Thank you - that helps us write better answers.';
    public static string $still_stuck = 'Still stuck? Write to us and a person will answer.';
    public static string $all_articles = 'All articles';

    ############################################################################
    /*============================ ANNOUNCEMENTS =============================*/
    ############################################################################

    public static string $announcements = 'Announcements';
    /** %s is the company name. */
    public static string $announcements_meta = 'News and service notices from %s.';
    public static string $announcements_lead = 'Maintenance windows, new features and anything else worth knowing.';
    public static string $no_announcements = 'Nothing has been announced yet.';
    public static string $published_on = 'Published %s';
    public static string $back_to_announcements = 'Back to announcements';

    ############################################################################
    /*=============================== SUPPORT ================================*/
    ############################################################################

    public static string $support = 'Support';
    public static string $support_centre = 'Support centre';
    /** %s is the company name. */
    public static string $support_meta = 'Get help from %s.';
    public static string $support_lead = 'Start with the knowledgebase. If the answer is not there, write to us.';
    public static string $help_yourself = 'Help yourself';
    public static string $help_yourself_lead = 'Most questions are answered here, immediately.';
    public static string $talk_to_us = 'Talk to us';
    public static string $talk_to_us_lead = 'Already a customer? Open a ticket from your account and we can see your services. Otherwise use the contact form.';
    public static string $open_a_ticket = 'Open a ticket';
    public static string $contact_form = 'Contact form';

    ############################################################################
    /*============================= CONTACT FORM =============================*/
    ############################################################################

    public static string $contact = 'Contact';
    public static string $contact_us = 'Contact us';
    /** %s is the company name. */
    public static string $contact_meta = 'Get in touch with %s.';
    public static string $contact_lead = 'Tell us what you need and we will reply by email.';
    public static string $your_name = 'Your name';
    public static string $your_email = 'Your email address';
    public static string $department = 'Department';
    public static string $choose_department = 'Choose a department';
    public static string $message = 'Message';
    public static string $send_message = 'Send message';
    public static string $contact_note = 'We reply to the address you give us. Please check it before sending.';
    public static string $ticket = 'Ticket';

    public static string $name_required = 'Please tell us your name.';
    public static string $email_required = 'We need an email address to reply to.';
    public static string $subject_required = 'Please give your message a subject.';
    public static string $message_required = 'Please write your message.';
    public static string $department_required = 'Please choose the department to write to.';
    public static string $not_an_email_address = 'That does not look like an email address.';

    /** The first line of the ticket a contact form submission opens. */
    public static string $sent_from_contact_form = 'Sent from the website contact form.';

    /** %s is the subject the sender typed. */
    public static string $contact_subject = 'Website enquiry: %s';
    /** %1$s is the ticket number, %2$s the subject the sender typed. */
    public static string $contact_subject_ticket = '[%1$s] Website enquiry: %2$s';
    public static string $contact_sent = 'Thank you - your message is on its way and we will reply by email.';
    /** %s is the ticket number the enquiry was logged as. */
    public static string $contact_sent_ticket = 'Thank you - your enquiry is logged as ticket %s and we will reply by email.';
    public static string $contact_failed = 'Your message could not be sent just now. Please try again shortly.';
    public static string $contact_unavailable = 'This site has no contact address configured yet, so the form cannot send.';

    ############################################################################
    /*================================ ERRORS ================================*/
    ############################################################################

    public static string $page_not_found = 'Page not found';
    public static string $not_found_lead = 'That address does not lead anywhere. It may have moved, or the link that brought you here may be wrong.';
    public static string $go_home = 'Go to the home page';
    public static string $or_search_kb = 'Or search the knowledgebase';

    ############################################################################
    /*============================== PAGINATION ==============================*/
    ############################################################################
    //
    // These are the keys partials/pagination.twig actually references. It is a
    // copy of the panel partial - shared partials are copied into each template,
    // not shared - so its key names come with it, and inventing prettier ones
    // here would simply throw.

    public static string $pagination = 'Pagination';
    public static string $records = 'records';
    public static string $articles = 'articles';
    public static string $announcements_lower = 'announcements';
    /** %1$s is how many are shown, %2$s what they are. */
    public static string $showing_n = 'Showing %s %s';
    public static string $of_more = ' of more';
    public static string $first = 'First';
    public static string $next = 'Next';

    ############################################################################
    /*=============================== MESSAGES ===============================*/
    ############################################################################
    //
    // Also required by the copied partials: alerts.twig wants `dismiss`,
    // status.twig wants `any_status`, form-errors.twig picks between the two
    // problem headings.

    public static string $dismiss = 'Dismiss';
    public static string $any_status = 'Any status';
    public static string $there_is_a_problem = 'There is a problem';
    public static string $there_are_problems = 'There are problems';
}
