<?php

declare(strict_types=1);

namespace Modules\Registrars\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use LBM\Module\Contracts\Configurable;
use LBM\Module\Contracts\RegistrarInterface;

/**
 * A STARTER: a domain registrar module, all six verbs.
 *
 * Copy this directory to modules/registrars/<YourRegistrar>, rename the
 * namespace in every file, put your registrar's two addresses in src/Api.php,
 * and change what each verb sends. It ships switched off and points at reserved
 * example names.
 *
 * The rule that runs through every verb: WHERE THE REGISTRY AND THIS PRODUCT
 * DISAGREE, THE REGISTRY IS RIGHT. So each one returns what the registrar says
 * it did - the expiry it reports, the nameservers it now holds - rather than
 * echoing what it was asked for, and the product stores that answer.
 *
 * `available` has three answers - true, false, and null for could not say. A
 * lookup that timed out is not a name somebody has.
 *
 * Staff reach every verb; a customer reaches nameservers() and their own
 * registrant details through the client area.
 */
class Example implements RegistrarInterface, Configurable
{
    /** @var array<string,mixed> What The Operator Saved, Opened, Plus `mode` And `api_url` */
    private array $settings;

    /**
     * @param array<string,mixed> $settings Built by the product: the fields
     *        declared in settings(), opened, `mode`, and `api_url` - which this
     *        module ignores, because its addresses are in its own code.
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
    }

    /**
     * The Fields The Operator Fills In On The Registrar's Form
     *
     * A `password` field is a secret: sealed, never shown again, and a blank
     * box keeps what is saved. `mode` and `api_url` cannot be field names.
     * @return array
     */
    public static function settings(): array
    {
        return [
            'api_key' => [
                'label'    => 'API key',
                'type'     => 'password',
                'required' => true,
                'help'     => 'From your reseller account. Use the sandbox key while this registrar is in test mode.',
            ],
            'reseller_id' => [
                'label' => 'Reseller id',
                'type'  => 'text',
                'help'  => 'If your registrar asks for one beside the key.',
            ],
        ];
    }

    /**
     * Answer The Test Connection Button
     *
     * One cheap call that spends nothing - never a lookup, which some
     * registrars charge for. The message is shown to the operator as it is.
     * @return array{success: bool, message: string}
     */
    public function test(): array
    {
        $reply = $this->api()->call('GET', 'ping', [], 5.0);

        return $reply['status'] === 200
            ? ['success' => true, 'message' => 'The API answered: ' . (string) ($reply['json']['message'] ?? 'OK')]
            : ['success' => false, 'message' => 'The API did not accept the key: ' . self::why($reply)];
    }

    /**
     * Can This Name Be Registered?
     *
     * Honour the `timeout` in the context: a public search has one budget for
     * every TLD, and a module that waits longer is a page that never loads. A
     * failed call answers success false and available NULL - never false.
     * @param string $domain The whole name, TLD included
     * @param array $context `timeout` and `tld`
     * @return array
     */
    public function available(string $domain, array $context = []): array
    {
        $timeout = min(10.0, max(0.5, (float) ($context['timeout'] ?? 5.0)));
        $reply = $this->api()->call('GET', 'domains/check', ['domain' => $domain], $timeout);
        $answer = $reply['json']['available'] ?? null;

        return $reply['status'] === 200 && is_bool($answer)
            ? ['success' => true, 'available' => $answer, 'message' => null, 'raw' => []]
            : ['success' => false, 'available' => null, 'message' => 'The registrar could not say: ' . self::why($reply), 'raw' => []];
    }

    /**
     * Register a Name, With The Contacts And Nameservers It Is Given
     *
     * `expiry_date` is the registry's, as it reports it. Never add a year here:
     * a date the registry does not agree with is how a domain expires while the
     * panel says it is fine. No date at all is allowed, and the product then
     * works from the term.
     * @param array $domain The `domains` row
     * @param array $context `client`, `contacts`, `years`, `nameservers`
     * @return array
     */
    public function register(array $domain, array $context = []): array
    {
        $reply = $this->api()->call('POST', 'domains', [
            'domain'      => self::name($domain),
            'years'       => (int) ($context['years'] ?? 1),
            'nameservers' => array_values((array) ($context['nameservers'] ?? [])),
            'contacts'    => (array) ($context['contacts'] ?? []),
            'reseller'    => (string) ($this->settings['reseller_id'] ?? ''),
        ]);

        return $this->dated($reply, [200, 201]);
    }

    /**
     * Extend The Registration By a Number Of Years
     *
     * The same rule as register(): the expiry returned is the registry's.
     * @param array $domain The `domains` row
     * @param int $years How many more
     * @param array $context See register()
     * @return array
     */
    public function renew(array $domain, int $years = 1, array $context = []): array
    {
        return $this->dated($this->api()->call('POST', 'domains/' . rawurlencode(self::name($domain)) . '/renew', ['years' => $years]), [200]);
    }

    /**
     * Bring a Name In From Another Registrar
     *
     * PENDING IS THE NORMAL ANSWER, and it is a success: a transfer waits on the
     * losing registrar or on the registrant approving it, often for days. Answer
     * `success: true, pending: true` and the product waits for staff to mark it
     * complete; answering failure would retry a transfer that is going fine.
     * The auth code is a credential - send it, never log it.
     * @param array $domain The `domains` row
     * @param string $authCode The code from the losing registrar
     * @param array $context See register()
     * @return array
     */
    public function transfer(array $domain, string $authCode, array $context = []): array
    {
        $reply = $this->api()->call('POST', 'transfers', ['domain' => self::name($domain), 'auth_code' => $authCode]);

        if (in_array($reply['status'], [200, 201, 202], true)) {
            return [
                'success'     => true,
                'pending'     => ($reply['json']['status'] ?? '') === 'pending',
                'expiry_date' => (string) ($reply['json']['expires'] ?? '') ?: null,
                'reference'   => (string) ($reply['json']['id'] ?? '') ?: null,
                'message'     => null,
                'raw'         => [],
            ];
        }

        return ['success' => false, 'pending' => false, 'expiry_date' => null, 'reference' => null, 'message' => 'The transfer was refused: ' . self::why($reply), 'raw' => []];
    }

    /**
     * Read The Nameservers, Or Replace Them
     *
     * Null reads; a list replaces, IN ORDER. Either way return what the registry
     * holds afterwards, which is not always what was asked for.
     * @param array $domain The `domains` row
     * @param ?string[] $hosts Null to read, a list to replace
     * @param array $context See register()
     * @return array
     */
    public function nameservers(array $domain, ?array $hosts = null, array $context = []): array
    {
        $path = 'domains/' . rawurlencode(self::name($domain)) . '/nameservers';
        $reply = $hosts === null
            ? $this->api()->call('GET', $path)
            : $this->api()->call('PUT', $path, ['nameservers' => array_values($hosts)]);

        return $reply['status'] === 200 && is_array($reply['json']['nameservers'] ?? null)
            ? ['success' => true, 'nameservers' => array_values(array_map('strval', $reply['json']['nameservers'])), 'message' => null, 'raw' => []]
            : ['success' => false, 'nameservers' => [], 'message' => 'The registrar refused: ' . self::why($reply), 'raw' => []];
    }

    /**
     * Read The Registry Contacts, Or Replace Them
     *
     * Keyed by role - registrant, admin, tech, billing. Many TLDs refuse a
     * registrant change outright, because that is a change of owner; return
     * what the registry holds afterwards, never the request.
     * @param array $domain The `domains` row
     * @param ?array $contacts Null to read, a set to replace
     * @param array $context See register()
     * @return array
     */
    public function contacts(array $domain, ?array $contacts = null, array $context = []): array
    {
        $path = 'domains/' . rawurlencode(self::name($domain)) . '/contacts';
        $reply = $contacts === null
            ? $this->api()->call('GET', $path)
            : $this->api()->call('PUT', $path, ['contacts' => $contacts]);

        return $reply['status'] === 200 && is_array($reply['json']['contacts'] ?? null)
            ? ['success' => true, 'contacts' => $reply['json']['contacts'], 'message' => null, 'raw' => []]
            : ['success' => false, 'contacts' => [], 'message' => 'The registrar refused: ' . self::why($reply), 'raw' => []];
    }

    /**
     * A Reply That Carries a Registry Expiry
     * @param array $reply What Api::call() returned
     * @param int[] $ok The Statuses That Mean It Worked
     * @return array
     */
    private function dated(array $reply, array $ok): array
    {
        if (in_array($reply['status'], $ok, true)) {
            return [
                'success'     => true,
                'expiry_date' => (string) ($reply['json']['expires'] ?? '') ?: null,
                'reference'   => (string) ($reply['json']['id'] ?? '') ?: null,
                'message'     => null,
                'raw'         => [],
            ];
        }

        return ['success' => false, 'expiry_date' => null, 'reference' => null, 'message' => 'The registrar refused: ' . self::why($reply), 'raw' => []];
    }

    /**
     * The API In The Saved Mode
     * @return Api
     */
    private function api(): Api
    {
        return new Api($this->settings);
    }

    /**
     * The Name On a `domains` Row
     * @param array $domain
     * @return string
     */
    private static function name(array $domain): string
    {
        return strtolower(trim((string) ($domain['domain'] ?? '')));
    }

    /**
     * Why a Call Did Not Work, In Words
     * @param array $reply What Api::call() returned
     * @return string
     */
    private static function why(array $reply): string
    {
        return (string) ($reply['json']['message'] ?? $reply['error'] ?? ('HTTP ' . $reply['status']));
    }
}
