<?php

declare(strict_types=1);

namespace Modules\Plugins\Example\Controller;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use Laika\Service\Response;
use Modules\Plugins\Example\Example;

/**
 * What the plugin's route answers.
 *
 * It lives under the plugin's own namespace, so the manifest's `namespace` and
 * `src` make it autoloadable with nothing else declared, and routes/example.php
 * names it the way the product's own route files name theirs:
 * [ExampleController::class, 'show'].
 *
 * It answers JSON, which needs no template - a module cannot add a view to the
 * operator's template directory, because that directory is the template's.
 */
final class ExampleController
{
    /**
     * GET /example-plugin - The Greeting, And The Mode It Is In
     *
     * Public, and harmless: the greeting is a string the operator typed. A route
     * that shows anything more must check who is asking.
     * @return string
     */
    public function show(): string
    {
        $settings = Example::current();

        Response::setContentType('application/json');

        return (string) json_encode([
            'plugin'   => 'Example',
            'greeting' => (new Example($settings))->greeting(),
            'mode'     => (string) ($settings['mode'] ?? 'live'),
        ]);
    }
}
