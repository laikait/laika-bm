<?php
/**
 * Laika Bill Manager - English, admin area.
 *
 * Loaded by LBM\Pipeline\GlobalPipeline::language() for every /admin request.
 *
 * The class name is fixed and un-namespaced because that is what laika-core's
 * local() reads: it resolves LANG::$$key and nothing else. That is also why every
 * area gets its own file - require_once'ing a second one in the same request is a
 * fatal, so strings shared with the panel and installer catalogues are copied
 * rather than shared. There is no mechanism to share them.
 *
 * Values are sprintf() formats. Placeholders are %s / %d, and a literal percent
 * has to be written %%. Arguments come from the call site:
 *
 *     {{ 'showing_n'|local(rows, label) }}
 *     local('deleted_invoice', $number)
 *
 * Keys are deduplicated by meaning, not by screen: one key per distinct string,
 * reused wherever that string appears.
 *
 * A key that is not here throws rather than rendering empty, so a missing string
 * surfaces the moment the screen is opened instead of shipping blank.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');

class LANG
{
    ############################################################################
    /*============================= NAVIGATION ===============================*/
    ############################################################################

    public static string $dashboard = 'Dashboard';
    public static string $clients = 'Clients';
    public static string $products = 'Products';
    public static string $orders = 'Orders';
    public static string $invoices = 'Invoices';
    public static string $transactions = 'Transactions';
    public static string $support = 'Support';
    public static string $domains = 'Domains';
    public static string $servers = 'Servers';
    public static string $reports = 'Reports';
    public static string $staff = 'Staff';
    public static string $roles = 'Roles';
    public static string $currencies = 'Currencies';
    public static string $modules = 'Modules';
    public static string $activity = 'Activity';
    public static string $settings = 'Settings';
    // The screen, not the group. `settings` names the sidebar GROUP after
    // Phase 30.2, and nav_mark() matches the first name it meets depth-first -
    // so the two cannot share one.
    public static string $general_settings = 'General settings';

    /** Sidebar section headings. */
    public static string $billing = 'Billing';
    public static string $operations = 'Operations';
    public static string $administration = 'Administration';

    public static string $toggle_navigation = 'Toggle navigation';
    public static string $account = 'Account';
    public static string $my_account = 'My account';
    public static string $sign_out = 'Sign out';
    public static string $sign_in_to_continue = 'Sign in to continue';

    ############################################################################
    /*=========================== SETTINGS TABS ==============================*/
    ############################################################################

    // The tab is `general` internally and reads App, because that is what it
    // holds: the application's name, host, address, logo and templates.
    public static string $app = 'App';
    public static string $localisation = 'Localisation';
    public static string $security = 'Security';
    // SMTP rather than Mail - the tab configures a mail SERVER, and the mail
    // it sends is on the Email Templates tab beside it.
    public static string $smtp = 'SMTP';
    public static string $statuses = 'Statuses';

    ############################################################################
    /*=========================== SHARED CHROME ==============================*/
    ############################################################################

    public static string $dismiss = 'Dismiss';
    public static string $there_is_a_problem = 'There is a problem';
    public static string $there_are_problems = 'There are problems';

    public static string $search_placeholder = 'Search…';
    public static string $apply = 'Apply';
    public static string $any_status = 'Any status';

    public static string $pagination = 'Pagination';
    public static string $records = 'records';
    /** %s is a row count, %s the noun for what is listed. */
    public static string $showing_n = 'Showing %s %s';
    /** Appended to $showing_n when more rows follow. */
    public static string $of_more = ' of more';
    public static string $first = 'First';
    public static string $next = 'Next';

    ############################################################################
    /*=========================== COUNTED NOUNS ==============================*/
    ############################################################################

    /** Passed to the toolbar count() and pagination show() macros. Lower case. */
    public static string $count_client = 'client';
    public static string $count_clients = 'clients';
    public static string $count_product = 'product';
    public static string $count_products = 'products';
    public static string $count_order = 'order';
    public static string $count_orders = 'orders';
    public static string $count_invoice = 'invoice';
    public static string $count_invoices = 'invoices';
    public static string $count_transaction = 'transaction';
    public static string $count_transactions = 'transactions';
    public static string $count_ticket = 'ticket';
    public static string $count_tickets = 'tickets';
    public static string $count_domain = 'domain';
    public static string $count_domains = 'domains';
    public static string $count_server = 'server';
    public static string $count_servers = 'servers';
    public static string $count_staff = 'staff member';
    public static string $count_staffs = 'staff';
    public static string $count_role = 'role';
    public static string $count_roles = 'roles';
    public static string $count_currency = 'currency';
    public static string $count_currencies = 'currencies';
    public static string $count_activity = 'entry';
    public static string $count_activities = 'entries';

    ############################################################################
    /*=========================== COMMON COLUMNS =============================*/
    ############################################################################

    public static string $client = 'Client';
    public static string $product = 'Product';
    public static string $order = 'Order';
    public static string $invoice = 'Invoice';
    public static string $group = 'Group';
    public static string $email = 'Email';
    public static string $country = 'Country';
    public static string $credit = 'Credit';
    public static string $status = 'Status';
    public static string $added = 'Added';
    public static string $placed = 'Placed';
    public static string $total = 'Total';
    public static string $setup_fee = 'Setup fee';
    public static string $any_country = 'Any country';
    public static string $any_group = 'Any group';

    ############################################################################
    /*============================ LIST SCREENS ==============================*/
    ############################################################################

    public static string $add_client = 'Add client';
    public static string $search_clients = 'Name, company or email…';
    public static string $no_client_matches = 'No client matches that search.';
    public static string $no_clients_yet = 'No clients yet.';
    public static string $add_first_client = 'Add the first client';

    public static string $groups = 'Groups';
    public static string $add_product = 'Add product';
    public static string $search_products = 'Product name or slug…';
    public static string $no_product_matches = 'No product matches that search.';
    public static string $nothing_for_sale = 'Nothing is for sale yet.';
    public static string $add_first_product = 'Add the first product';

    public static string $new_order = 'New order';
    public static string $search_orders = 'Order number or client…';
    public static string $no_order_matches = 'No order matches that search.';
    public static string $no_orders_yet = 'No orders yet.';
    public static string $place_first_order = 'Place the first order';
    public static string $invoiced = 'Invoiced';

    public static string $search_invoices = 'Invoice number or client…';
    public static string $no_invoice_matches = 'No invoice matches that search.';
    public static string $no_invoices_yet = 'No invoices yet.';
    public static string $raise_first_invoice = 'Raise the first invoice';
    public static string $due = 'Due';
    public static string $balance = 'Balance';

    public static string $received_this_month = 'Received this month, net of refunds';
    public static string $search_transactions = 'Reference, description or client…';
    public static string $any_type = 'Any type';
    public static string $nothing_matches = 'Nothing matches that search.';
    public static string $no_money_moved = 'No money has moved yet.';
    public static string $record_first_payment = 'Record the first payment';
    public static string $when = 'When';
    public static string $type = 'Type';
    public static string $reference = 'Reference';
    public static string $amount = 'Amount';

    public static string $departments = 'Departments';
    public static string $search_tickets = 'Ticket number, subject or client…';
    public static string $any_priority = 'Any priority';
    public static string $any_department = 'Any department';
    public static string $no_ticket_matches = 'No ticket matches that search.';
    public static string $nobody_asked_for_help = 'Nobody has asked for help yet.';
    public static string $open_a_ticket = 'Open a ticket';
    public static string $ticket = 'Ticket';
    public static string $subject = 'Subject';
    public static string $priority = 'Priority';
    public static string $last_reply = 'Last reply';

    public static string $search_domains = 'Domain or client…';
    public static string $any_registrar = 'Any registrar';
    public static string $no_domain_matches = 'No domain matches that search.';
    public static string $no_domains_registered = 'No domains are registered.';
    public static string $domain = 'Domain';
    public static string $expires = 'Expires';
    public static string $renewal = 'Renewal';
    public static string $auto = 'Auto';

    public static string $search_servers = 'Name, hostname or IP…';
    public static string $no_server_matches = 'No server matches that search.';
    public static string $no_servers_configured = 'No servers are configured.';
    public static string $add_first_server = 'Add the first server';
    public static string $server = 'Server';
    public static string $module = 'Module';
    public static string $accounts = 'Accounts';
    public static string $actions = 'Actions';

    public static string $search_staff = 'Name, email or username…';
    public static string $any_role = 'Any role';
    public static string $nobody_matches = 'Nobody matches that search.';
    public static string $name = 'Name';
    public static string $role = 'Role';
    public static string $last_sign_in = 'Last sign-in';
    public static string $never = 'Never';

    public static string $no_roles_yet = 'No roles yet.';
    public static string $held_by = 'Held by';
    public static string $granted = 'Granted';
    /** %s is the role name. */
    public static string $confirm_delete_role = 'Delete the %s role?';

    public static string $no_currencies = 'No currencies. Add one on the right.';
    public static string $code = 'Code';
    public static string $symbols = 'Symbols';
    public static string $rate = 'Rate';
    public static string $active = 'Active';
    public static string $default_label = 'Default';
    public static string $iso_code = 'ISO code';
    public static string $iso_code_hint = 'Three letters, ISO 4217.';
    public static string $prefix = 'Prefix';
    public static string $suffix = 'Suffix';
    public static string $rate_hint = 'How much of this currency one unit of the default buys.';
    /** %s is a currency code. */
    public static string $confirm_make_default = 'Make %s the default? Existing amounts are not converted.';
    /** %s is a currency code. */
    public static string $confirm_delete_currency = 'Delete %s?';

    public static string $no_modules_installed = 'No modules are installed.';
    public static string $kind = 'Kind';
    public static string $version = 'Version';
    public static string $state = 'State';
    public static string $provides = 'Provides';
    public static string $disabled = 'Disabled';
    public static string $loaded = 'Loaded';
    public static string $failed = 'Failed';
    public static string $pending = 'Pending';
    public static string $loads_next_request = 'Loads on the next request';
    public static string $disable = 'Disable';
    public static string $enable = 'Enable';

    /** %s is the maximum upload size, already formatted. Example: 20MB. */

    public static string $search_log = 'Search the log…';
    public static string $any_event = 'Any event';
    public static string $anyone = 'Anyone';
    public static string $nothing_recorded = 'Nothing has been recorded yet.';
    public static string $event = 'Event';
    public static string $who = 'Who';
    public static string $what_happened = 'What happened';
    public static string $from = 'From';

    public static string $save = 'Save';
    public static string $make_default = 'Make default';
    public static string $delete = 'Delete';
    public static string $add_a_currency = 'Add a currency';
    public static string $installed = 'Installed';
    /** %s is the modules directory, already wrapped in a <code> element. */
    public static string $drop_module_into = 'Drop one into %s under';
    /** %s is the manifest filename, already wrapped in a <code> element. */
    public static string $with_manifest = 'with a %s manifest inside it.';

    ############################################################################
    /*============================ SIGN IN ===================================*/
    ############################################################################

    public static string $sign_in_to_admin = 'Sign in to the admin panel';
    public static string $username_or_email = 'Username or email';
    public static string $username = 'Username';
    public static string $password = 'Password';
    public static string $sign_in = 'Sign in';
    public static string $require_sign_in = 'Sign in required';
    public static string $looking_for_client_area = 'Looking for the client area?';
    public static string $sign_in_there_instead = 'Sign in there instead';

    ############################################################################
    /*============================== REPORTS =================================*/
    ############################################################################

    public static string $income = 'Income';
    public static string $report_income_text = 'What came in, month by month, and what is still owed.';
    public static string $report_orders_text = 'How orders are split across their statuses.';
    public static string $report_tickets_text = 'Ticket load by status, priority and department.';
    public static string $report_annual_text = 'A calendar year against the one before it, month by month.';
    public static string $report_clients_text = 'Who joined, and when.';
    public static string $report_performance_text = 'Ticket load, response times and ratings, per staff member.';
    public static string $report_feedback_text = 'What clients thought of the support they were given.';

    public static string $annual_income = 'Annual income';
    public static string $new_clients = 'New clients';
    public static string $performance = 'Performance';
    public static string $ticket_feedback = 'Ticket feedback';

    public static string $year = 'Year';
    public static string $month_by_month = 'Month by month';
    public static string $received_in_year = 'Received in %d';
    public static string $change_on_last_year = 'Change on last year';

    public static string $joined_in_range = 'Joined in this range';
    public static string $clients_all_time = 'Clients, all time';

    public static string $staff_member = 'Staff member';
    public static string $first_response = 'First response';
    public static string $rated = 'Rated';
    public static string $average_rating = 'Average rating';
    public static string $unassigned = 'Unassigned';
    public static string $closed = 'Closed';
    public static string $no_tickets_in_range = 'No tickets were opened in this range.';

    // %s rather than %.1f - the value is rounded before it gets here, and a
    // float format would print 4.0 as "4.0 hours" where the column shows "4".
    public static string $n_hours = '%s hours';

    public static string $ratings_given = 'Ratings given';
    public static string $average_out_of = 'Average out of %d';
    public static string $rating_spread = 'Rating spread';
    public static string $what_people_said = 'What people said';
    public static string $no_comments_in_range = 'Nobody left a comment in this range.';

    // Read dynamically as ('rating_' ~ n)|local, so all five must exist or the
    // feedback report throws on whichever one is missing.
    public static string $rating_1 = 'Poor';
    public static string $rating_2 = 'Fair';
    public static string $rating_3 = 'Good';
    public static string $rating_4 = 'Very good';
    public static string $rating_5 = 'Excellent';

    ############################################################################
    /*============================= DASHBOARD ================================*/
    ############################################################################

    public static string $money = 'Money';
    public static string $received_this_month_short = 'Received this month';
    public static string $no_last_month_figure = 'No figure for last month to compare against';
    public static string $last_month = 'Last month';
    public static string $still_outstanding = 'Still outstanding';
    public static string $view_all = 'View all';
    public static string $nothing_happened_yet = 'Nothing has happened yet.';
    public static string $recent_activity = 'Recent activity';
    public static string $awaiting_payment = 'Awaiting payment';
    public static string $nothing_outstanding = 'Nothing outstanding. Everything is settled.';
    public static string $latest_tickets = 'Latest tickets';
    public static string $no_tickets_opened = 'No tickets have been opened.';

    ############################################################################
    /*============================== UTILITIES ===============================*/
    ############################################################################

    public static string $utilities = 'Utilities';
    public static string $util_update_text = 'What version this is, and applying what an update brought.';
    public static string $util_system_text = 'Whether anything about this installation is wrong.';
    public static string $util_automation_text = 'Whether scheduled work is actually running.';
    public static string $util_todos_text = 'Your own list. Nobody else sees it.';

    public static string $everything_checks_out = 'Everything checks out.';
    public static string $checks_failing = '%d check(s) need attention.';
    public static string $see_what_is_wrong = 'See what is wrong';

    /*------------------------------- Update ---------------------------------*/
    public static string $update_app = 'Update';
    public static string $installed_version = 'Installed version';
    public static string $check_for_updates = 'Check for updates';
    public static string $update_available = 'Version %s is available';
    public static string $up_to_date = 'Up to date';
    public static string $last_checked = 'Last checked %s';
    public static string $update_check_done = 'Checked the release feed.';
    public static string $update_check_failed = 'The release feed could not be read, or did not answer with a version.';
    public static string $no_update_source = 'No update source is configured.';
    public static string $no_update_source_hint = 'No release feed is configured, so there is nothing to check against. Set update_feed_url to an https address that answers with JSON containing a "version" key.';

    public static string $apply_update = 'Apply an update';
    public static string $apply_update_text = 'Runs the database migration in this process. Tables that are missing are created, lookup data is re-seeded, and any change this release makes to an existing table is applied. It is safe to run more than once.';
    public static string $run_migration = 'Run migration';
    public static string $migrate_done = 'The migration finished.';
    public static string $migrate_failed = 'The migration finished with failures: %s';
    public static string $needs_settings_update = 'Applying an update needs the settings update permission.';

    // The honest half, rewritten in Phase 21. It used to say a change to an
    // existing table could not arrive at all, which was true while migrate()
    // only called createIfNotExists. Migrations changed that, so the sentence
    // had to change with them - a caveat that is no longer true is worse than
    // no caveat, because it teaches the operator to discount the next one.
    // What is still worth saying is what migration does NOT do: undo anything.
    public static string $what_this_cannot_do = 'What this cannot do';
    public static string $migrate_limitation = 'It does not undo anything, and it has no reverse. A change that fails is reported here rather than skipped, so read the message before running it again.';

    /*-------------------------- Payment gateways ----------------------------*/
    // "Configured" and "switched on" are deliberately different words. A gateway
    // can be installed, configured and still off, and a screen that blurs those
    // is how an operator ends up sure they are taking payments when they are not.
    public static string $payment_gateways = 'Payment gateways';
    public static string $configured_gateways = 'Configured';
    public static string $installed_not_configured = 'Installed, not set up yet';
    public static string $no_gateways_installed = 'No payment gateway modules are enabled. Put one in modules/gateways, switch it on from the modules screen, then set it up here.';
    public static string $no_gateways_configured = 'No gateway is set up yet, so customers have no way to pay online.';
    public static string $gateway_not_found = 'That gateway is not configured.';
    public static string $gateway_configured = 'The gateway has been set up. Fill in its settings, then switch it on.';
    public static string $gateway_settings_saved = 'The gateway settings have been saved.';
    public static string $gateway_switched_on = 'The gateway is now offered to customers.';
    public static string $gateway_switched_off = 'The gateway is no longer offered to customers.';
    public static string $gateway_removed = 'The gateway configuration has been removed.';
    public static string $gateway_module_unknown = 'That gateway module is not installed or is switched off.';
    public static string $gateway_needs_name_and_slug = 'A gateway needs a name and a short reference.';
    public static string $gateway_problem = 'This gateway cannot be used: %s';
    public static string $gateway_slug_hint = 'A short reference used in forms and links. Lower case, no spaces.';
    public static string $confirm_delete_gateway = 'Remove this gateway configuration? Past payments keep their record; the module stays installed.';
    public static string $set_up_gateway = 'Set up';
    public static string $switch_on = 'Switch on';
    public static string $switch_off = 'Switch off';
    public static string $offered_to_customers = 'Offered to customers';
    public static string $not_offered = 'Not offered';
    public static string $gateway_settings_note = 'These are passed to the gateway exactly as entered. What each one means is the gateway\'s own business - a wrong value is reported when a payment is attempted.';

    /*--------------------------- Schema evolution ---------------------------*/
    public static string $pending_changes = 'Pending changes';
    public static string $no_pending_changes = 'The database matches this version. Nothing is pending.';
    public static string $pending_changes_count = '%d change(s) will be applied when you run the migration.';
    public static string $last_migration_run = 'Last run %s';
    public static string $migrations_applied = '%d applied';
    public static string $migrations_baselined = '%d already present';
    public static string $migrations_failed = '%d failed';
    public static string $database_version = 'Database version';
    public static string $database_behind = 'The files are version %s but the database was last migrated at %s. Run the migration.';
    public static string $migration_problem = 'The migrations on this installation cannot be read, so nothing can be applied. This is a packaging fault, not something you can fix from here: %s';

    /*------------------------------- Status ---------------------------------*/
    public static string $system_status = 'System status';
    public static string $this_installation = 'This installation';
    public static string $this_machine = 'This machine';

    /*----------------------------- Automation -------------------------------*/
    public static string $automation_status = 'Automation';
    public static string $scheduled_tasks = 'Scheduled tasks';
    public static string $cron_never_ran = 'Scheduled tasks have never run. Invoices will not be raised and queued email will not be sent until they do.';
    public static string $cron_is_stale = 'The last run was %d hour(s) ago. Anything over %d minutes suggests the schedule has stopped.';
    public static string $last_run = 'Last run';
    public static string $daily_work = 'Daily work';
    public static string $done_today = 'Done today';
    public static string $run_this_every_five_minutes = 'Run this every five minutes:';
    public static string $what_runs_daily = 'What runs once a day';

    public static string $mail_queue = 'Mail queue';
    public static string $waiting_to_send = 'Waiting to send';
    public static string $sent = 'Sent';
    public static string $gave_up = 'Gave up';
    public static string $held_for_review = 'Held for review';

    public static string $run_lock = 'Run lock';
    public static string $no_run_in_progress = 'No run is in progress.';
    public static string $run_in_progress = 'A run is in progress.';
    public static string $lock_looks_stale = 'A lock is held but looks abandoned. A run that was killed leaves this behind, and nothing else will start until it is removed.';

    /*--------------------------- Product types ------------------------------*/
    public static string $product_types = 'Product types';
    public static string $add_product_type = 'Add a product type';
    public static string $edit_product_type = 'Edit product type';
    public static string $product_type_added = 'Product type added.';
    public static string $product_type_updated = 'Product type updated.';
    public static string $product_type_deleted = 'Product type deleted.';
    public static string $product_type_needs_a_name = 'A product type needs an identifier.';
    public static string $product_type_exists = 'There is already a product type with that identifier.';
    public static string $product_type_in_use = 'That type cannot be deleted: %s product(s) use it.';
    public static string $no_product_types = 'There are no product types. A product cannot be created without one.';
    public static string $confirm_delete_product_type = 'Delete this product type?';
    public static string $identifier = 'Identifier';
    public static string $requires_domain = 'Requires a domain';
    public static string $requires_domain_hint = 'Products of this type ask the customer for a domain name, and cannot be ordered without one. Shared hosting needs one; software does not.';
    public static string $product_type_display_hint = 'What operators and customers see. Leave it blank to use the identifier.';
    public static string $product_type_name_hint = 'Lowercase, no spaces. This is what seeds and modules match on, and it cannot be two things at once.';
    public static string $product_types_hint = 'A type decides whether an order needs a domain name. It does not register one - a domain bought on its own goes through Domain pricing.';

    /*----------------------------- Error log --------------------------------*/
    public static string $error_log = 'Error log';
    public static string $util_logs_text = 'Exceptions, module failures and anything a scheduled task could not finish.';
    public static string $no_errors_logged = 'Nothing has gone wrong.';
    public static string $no_errors_match = 'No entries match that.';
    public static string $log_level = 'Level';
    public static string $log_source = 'Where';
    public static string $all_levels = 'Any level';
    public static string $all_sources = 'Anywhere';
    public static string $log_when = 'When';
    public static string $log_what = 'What happened';
    public static string $log_where = 'Where';
    public static string $log_trace = 'Trace';
    public static string $log_source_app = 'Application';
    public static string $log_source_module = 'Module';
    public static string $log_source_cron = 'Scheduled task';
    public static string $log_source_job = 'Queued job';
    public static string $log_level_error = 'Error';
    public static string $log_level_warning = 'Warning';
    public static string $log_level_critical = 'Critical';
    public static string $log_retention_note = 'Entries older than %s days are removed automatically.';
    public static string $log_retention_off = 'Entries are kept indefinitely. Set a retention period on the Billing settings tab.';
    public static string $log_signed_in_as = 'Signed in as staff #%s';
    public static string $log_signed_in_client = 'Signed in as client #%s';
    public static string $error_log_days = 'Keep error log entries for';
    public static string $error_log_days_hint = 'Days. Zero keeps everything, which on a busy installation is a table nobody can read.';

    /*------------------------------- To-do ----------------------------------*/
    public static string $todo_list = 'To-do list';
    public static string $add_an_item = 'Add an item';
    public static string $what_needs_doing = 'What needs doing';
    public static string $due_date_hint = 'Optional.';
    public static string $overdue_since = 'Overdue since %s';
    public static string $add = 'Add';
    public static string $mark_done = 'Mark as done';
    public static string $mark_not_done = 'Mark as not done';
    public static string $nothing_on_the_list = 'Nothing on the list.';
    public static string $todo_added = 'Added.';
    public static string $todo_updated = 'Updated.';
    public static string $todo_removed = 'Removed.';
    public static string $todo_needs_a_title = 'An item needs a title.';
    public static string $todo_not_found = 'That item does not exist.';

    ############################################################################
    /*============================== SETTINGS ================================*/
    ############################################################################

    public static string $save_settings = 'Save settings';
    public static string $company = 'Company';
    public static string $appearance = 'Appearance';
    public static string $company_name = 'Company name';
    public static string $company_name_hint = 'Shown in the panel, on invoices and in outgoing email.';
    public static string $application_url = 'Application URL';
    public static string $application_url_hint = 'The address clients reach this system on, including https://';
    public static string $billing_email_address = 'Billing email address';
    public static string $billing_email_hint = 'Where client replies and billing notices go.';
    public static string $logo_url = 'Logo URL';
    public static string $logo_url_hint = 'Shown in the sidebar and on invoices.';
    public static string $favicon_url = 'Favicon URL';
    public static string $front_theme = 'Public site theme';
    public static string $front_theme_hint = 'Installed in template/front/.';
    public static string $admin_theme = 'Admin theme';
    public static string $admin_theme_hint = 'Installed in template/admin/.';
    public static string $client_theme = 'Client theme';
    public static string $client_theme_hint = 'Installed in template/panel/.';

    public static string $time_and_language = 'Time and language';
    public static string $numbers_and_money = 'Numbers and money';
    public static string $timezone = 'Timezone';
    public static string $language = 'Language';
    public static string $date_format = 'Date format';
    public static string $date_and_time = 'Date and time';
    public static string $time_format = 'Time format';
    public static string $default_currency = 'Default currency';
    public static string $decimal_symbol = 'Decimal symbol';
    public static string $thousand_separator = 'Thousand separator';
    public static string $rows_per_page = 'Rows per page';

    public static string $sessions = 'Sessions';
    public static string $session_lifetime = 'Session lifetime (seconds)';
    public static string $session_lifetime_hint = 'Idle timeout — activity keeps a session alive, inactivity ends it.';
    public static string $tie_sessions_to_ip = 'Tie sessions to their IP address';
    public static string $tie_sessions_hint = 'More secure, but signs out anybody whose address changes — mobile networks do';
    public static string $min_password_length = 'Minimum password length';
    public static string $min_password_hint = 'Never below 6, whatever is entered here.';
    public static string $allow_registration = 'Let clients register themselves';
    public static string $allow_registration_hint = 'With this off, only staff can create client accounts';

    public static string $numbering = 'Numbering';
    public static string $terms = 'Terms';
    public static string $invoice_prefix = 'Invoice prefix';
    public static string $invoice_prefix_hint = 'Numbers run from the record id, so they can never collide.';
    public static string $order_prefix = 'Order prefix';
    public static string $payment_terms_days = 'Payment terms (days)';
    public static string $payment_terms_hint = 'How long a new invoice gets before it is due.';
    /** The %% is a literal percent sign - sprintf eats a single one. */
    public static string $late_fee_percent = 'Late fee (%%)';

    public static string $delivery = 'Delivery';
    public static string $from_heading = 'From';
    public static string $connection = 'Connection';
    public static string $driver = 'Driver';
    public static string $encryption = 'Encryption';
    public static string $host = 'Host';
    public static string $port = 'Port';
    public static string $from_address = 'From address';
    public static string $from_name = 'From name';
    public static string $timeout_seconds = 'Timeout (s)';
    public static string $charset = 'Charset';
    public static string $debug_level = 'Debug level';
    public static string $debug_level_hint = '0 is silent.';
    public static string $upgrade_to_tls = 'Upgrade to TLS when offered';
    public static string $verify_certificate = 'Verify the server certificate';
    public static string $verify_certificate_hint = 'Leave on unless your mail server uses a self-signed certificate';
    public static string $keep_connection_open = 'Keep the connection open between messages';
    public static string $send_a_test = 'Send a test';
    /** %s is the worker command, already wrapped in a <code> element. */
    public static string $test_mail_intro = 'The test goes onto the queue, exactly like a real notification. Run %s to send it — nothing is ever sent during a web request.';
    /** %s is a message count. */
    public static string $messages_queued_one = '%s message waiting in the queue.';
    public static string $messages_queued_many = '%s messages waiting in the queue.';
    public static string $send_to = 'Send to';
    public static string $send_to_hint = 'Blank sends to the billing address.';
    public static string $queue_test_message = 'Queue a test message';

    ############################################################################
    /*============================ CLIENT SCREEN =============================*/
    ############################################################################

    public static string $restricted = 'Restricted';
    public static string $edit = 'Edit';
    public static string $contacts = 'Contacts';
    public static string $notes = 'Notes';
    public static string $all_notes = 'All notes';
    public static string $confirm_delete_client = 'Delete this client? Their contacts and notes go too. Invoices and payments are kept.';
    public static string $outstanding = 'Outstanding';
    public static string $credit_balance = 'Credit balance';
    public static string $client_since = 'Client since';
    public static string $tickets = 'Tickets';
    public static string $payments = 'Payments';
    public static string $nothing_paid_yet = 'Nothing has been paid yet.';
    public static string $latest_notes = 'Latest notes';
    public static string $no_notes_yet = 'Nobody has left a note yet.';
    /** %s is a lower-cased panel name: invoices, orders, tickets, domains. */
    public static string $none_for_this_client = 'No %s for this client.';

    ############################################################################
    /*============================= CLIENT FORM ==============================*/
    ############################################################################

    public static string $person = 'Person';
    public static string $address = 'Address';
    public static string $sign_in_heading = 'Sign-in';
    public static string $middle_name = 'Middle name';
    public static string $dialling_code = 'Dialling code';
    public static string $phone = 'Phone';
    public static string $street = 'Street';
    public static string $city = 'City';
    public static string $state_or_region = 'State or region';
    public static string $postcode = 'Postcode';
    public static string $not_set = 'Not set';
    public static string $username_hint = 'Optional. With none, they sign in with their email address.';
    public static string $password_keep_hint = 'Leave blank to keep the current password.';
    public static string $password_later_hint = 'Leave blank to set one later.';
    public static string $confirm_password = 'Confirm password';
    public static string $currency = 'Currency';
    public static string $currency_hint = 'What this client is invoiced in.';
    public static string $tax_id = 'Tax ID';
    public static string $tax_id_hint = 'VAT, GST, EIN — whatever applies.';
    public static string $tax_exempt = 'Tax exempt';
    public static string $tax_exempt_hint = 'Do not add tax to invoices for this client';
    public static string $restricted_hint = 'Block this account from signing in';
    public static string $save_changes = 'Save changes';
    public static string $first_name = 'First name';
    public static string $last_name = 'Last name';
    public static string $email_address = 'Email address';

    ############################################################################
    /*=============================== INVOICE ================================*/
    ############################################################################

    public static string $overdue = 'Overdue';
    public static string $email_action = 'Email';
    public static string $cancel = 'Cancel';
    public static string $confirm_cancel_invoice = 'Cancel this invoice?';
    /** %s is the invoice number. */
    public static string $confirm_delete_invoice = 'Delete %s and its lines? Payments already recorded are kept.';
    public static string $lines = 'Lines';
    public static string $description = 'Description';
    public static string $qty = 'Qty';
    public static string $unit = 'Unit';
    public static string $unit_price = 'Unit price';
    public static string $discount = 'Discount';
    public static string $no_invoice_lines = 'No lines on this invoice.';
    public static string $nothing_paid_this_invoice = 'Nothing has been paid against this invoice.';
    public static string $totals = 'Totals';
    public static string $subtotal = 'Subtotal';
    public static string $paid = 'Paid';
    public static string $credit_applied = 'Credit applied';
    public static string $record_a_payment = 'Record a payment';
    public static string $amount_hint = 'Defaults to the balance still owed.';
    public static string $reference_placeholder = 'Bank reference, cheque number…';
    public static string $record_payment = 'Record payment';

    public static string $choose_a_client = 'Choose a client';
    public static string $due_date = 'Due date';
    public static string $discount_hint = 'An amount, taken off before tax.';
    /** The %% is a literal percent sign. */
    public static string $tax_percent = 'Tax (%%)';
    public static string $save_invoice = 'Save invoice';
    public static string $raise_invoice = 'Raise invoice';

    ############################################################################
    /*================================ ORDER =================================*/
    ############################################################################

    public static string $confirm_accept_order = 'Accept this order and raise an invoice for it?';
    public static string $confirm_cancel_order = 'Cancel this order?';
    public static string $confirm_delete_order = 'Delete this order?';
    public static string $accept_and_invoice = 'Accept &amp; invoice';
    public static string $order_has_no_lines = 'This order has no lines.';
    public static string $item = 'Item';
    public static string $cycle = 'Cycle';
    public static string $each = 'Each';
    public static string $line_total = 'Line total';
    public static string $billing_cycle = 'Billing cycle';
    public static string $save_order = 'Save order';
    public static string $place_order = 'Place order';

    ############################################################################
    /*=============================== PRODUCT ================================*/
    ############################################################################

    public static string $featured = 'Featured';
    public static string $no_group = 'No group';
    /** %s is the product name. */
    public static string $confirm_delete_product = 'Delete %s?';
    public static string $pricing = 'Pricing';
    public static string $pricing_blank_hint = 'Blank means not sold on that cycle';
    public static string $add_currency_before_pricing = 'Add a currency before pricing anything.';
    public static string $save_pricing = 'Save pricing';
    public static string $slug = 'Slug';
    public static string $slug_hint = 'Used in URLs. Left blank, one is made from the name; a duplicate is suffixed rather than refused.';
    public static string $choose_a_group = 'Choose a group';
    public static string $choose_a_type = 'Choose a type';
    public static string $provisioning = 'Provisioning';
    public static string $module_hint = 'The provisioning module that sets this product up. Blank for something delivered by hand.';
    public static string $limited_stock = 'Limited stock';
    public static string $limited_stock_hint = 'Stop selling once the quantity runs out';
    public static string $quantity_available = 'Quantity available';
    public static string $charging = 'Charging';
    public static string $pricing_model = 'Pricing model';
    public static string $default_setup_fee = 'Default setup fee';
    public static string $setup_fee_hint = 'A per-currency setup fee on the price grid overrides this.';
    /** The %% is a literal percent sign. */
    public static string $tax_rate_percent = 'Tax rate (%%)';
    public static string $featured_hint = 'Show this product ahead of the others';
    public static string $no_groups_yet = 'No groups yet. Add one on the right.';
    public static string $on_sale = 'On sale';
    public static string $on_sale_hint = 'Offer this group to clients';
    public static string $add_a_group = 'Add a group';
    public static string $add_group = 'Add group';
    /** %s is the group name. */
    public static string $confirm_delete_group = 'Delete %s?';

    ############################################################################
    /*================================ TICKET ================================*/
    ############################################################################

    public static string $confirm_delete_ticket = 'Delete this ticket and every reply on it?';
    /** %s is a formatted date. */
    public static string $opened_on = 'opened %s';
    public static string $internal_note_badge = 'Internal note — the client cannot see this';
    public static string $reply = 'Reply';
    public static string $message = 'Message';
    public static string $internal_note = 'Internal note';
    public static string $internal_note_hint = 'Visible to staff only — the client will never see this';
    public static string $send_reply = 'Send reply';
    public static string $handling = 'Handling';
    public static string $assigned_to = 'Assigned to';
    public static string $nobody = 'Nobody';
    public static string $update = 'Update';
    public static string $new_ticket = 'New ticket';
    public static string $department = 'Department';
    public static string $choose_a_department = 'Choose a department';
    public static string $open_ticket = 'Open ticket';
    public static string $no_departments_yet = 'No departments yet. Add one on the right.';
    public static string $inbound_email = 'Inbound email';
    public static string $visible = 'Visible';
    public static string $add_a_department = 'Add a department';
    public static string $add_department = 'Add department';
    public static string $inbound_email_hint = 'Where replies to this department arrive, if you route any.';
    public static string $auto_close_after_days = 'Auto-close after (days)';
    public static string $hidden_from_clients = 'Hidden from clients';
    public static string $hidden_from_clients_hint = 'Staff can file here, clients cannot choose it';

    ############################################################################
    /*============================= STAFF & ROLES ============================*/
    ############################################################################

    public static string $no_role = 'No role';
    /** %s is the staff member name. */
    public static string $confirm_delete_staff = 'Delete %s?';
    public static string $recent_sign_ins = 'Recent sign-ins';
    public static string $never_signed_in = 'This account has never signed in.';
    public static string $what_they_have_done = 'What they have done';
    public static string $nothing_recorded_account = 'Nothing recorded against this account.';
    /** %1$s is a browser, %2$s an operating system. */
    public static string $browser_on_os = '%1$s on %2$s';
    public static string $access = 'Access';
    public static string $choose_a_role = 'Choose a role';
    public static string $role_hint = 'What they may do is decided entirely by their role.';
    public static string $add_staff_member = 'Add staff member';
    public static string $role_name = 'Role name';
    public static string $role_name_placeholder = 'Support agent';
    public static string $permissions = 'Permissions';
    public static string $grant_everything = 'Grant everything';
    public static string $area = 'Area';
    public static string $save_role = 'Save role';
    public static string $add_role = 'Add role';
    public static string $password_keep_hint_blank = 'Leave blank to keep the current password.';

    ############################################################################
    /*=========================== ACCOUNT & NOTES ============================*/
    ############################################################################

    public static string $my_details = 'My details';
    public static string $save_details = 'Save details';
    public static string $change_password = 'Change password';
    public static string $current_password = 'Current password';
    public static string $new_password = 'New password';
    public static string $confirm_new_password = 'Confirm new password';
    public static string $no_sign_ins_yet = 'No sign-ins recorded yet.';
    public static string $confirm_sign_out_everywhere = 'Sign out of every device, including this one?';
    public static string $sign_out_everywhere = 'Sign out everywhere';
    public static string $what_i_have_done = 'What I have done';
    public static string $nothing_recorded_yet = 'Nothing recorded yet.';

    /** %s is the client name. */
    public static string $back_to_client = 'Back to %s';
    public static string $add_contact = 'Add contact';
    public static string $no_contacts = 'This client has no contacts.';
    public static string $add_first_contact = 'Add the first contact';
    public static string $panel_access = 'Panel access';
    public static string $primary = 'Primary';
    public static string $email_only = 'Email only';
    public static string $remove = 'Remove';
    /** %s is the contact name. */
    public static string $confirm_remove_contact = 'Remove %s?';

    public static string $add_a_note = 'Add a note';
    public static string $note = 'Note';
    public static string $note_placeholder = 'What happened, and anything the next person needs to know.';
    public static string $save_note = 'Save note';
    public static string $no_notes_on_client = 'Nobody has left a note on this client.';
    public static string $confirm_delete_note = 'Delete this note?';

    ############################################################################
    /*============================ CONTACT & DOMAIN ==========================*/
    ############################################################################

    public static string $contact = 'Contact';
    public static string $contact_username_hint = 'Leave blank for a contact who only receives email and never signs in.';
    public static string $primary_contact = 'Primary contact';
    public static string $primary_contact_hint = 'The main person to contact about this account';
    public static string $what_they_may_do = 'What they may do';
    public static string $save_contact = 'Save contact';

    public static string $expired = 'Expired';
    /** %s is a billing cycle. */
    public static string $renews_cycle = 'renews %s';
    public static string $registration = 'Registration';
    public static string $registered = 'Registered';
    public static string $next_due = 'Next due';
    public static string $renewal_amount = 'Renewal amount';
    public static string $auto_renew = 'Auto renew';
    public static string $yes = 'Yes';
    public static string $no = 'No';
    public static string $registrar_lock = 'Registrar lock';
    public static string $locked = 'Locked';
    public static string $unlocked = 'Unlocked';
    public static string $id_protection = 'ID protection';
    public static string $on = 'On';
    public static string $off = 'Off';
    public static string $nameservers = 'Nameservers';
    public static string $no_nameservers = 'No nameservers recorded.';
    public static string $tld = 'TLD';
    public static string $registrar = 'Registrar';
    public static string $nameservers_hint = 'One per line. Order is kept as written.';
    public static string $renewal_heading = 'Renewal';
    public static string $save_domain = 'Save domain';

    ############################################################################
    /*======================== TRANSACTION & SERVER ==========================*/
    ############################################################################

    public static string $recorded = 'Recorded';
    public static string $gateway_fee = 'Gateway fee';
    public static string $refunded_so_far = 'Refunded so far';
    public static string $refund = 'Refund';
    public static string $refund_amount_hint = 'Leave blank to refund everything still refundable on this payment.';
    public static string $reason = 'Reason';
    public static string $reason_placeholder = 'Why is this being refunded?';
    public static string $record_refund = 'Record refund';
    public static string $confirm_delete_transaction = 'Delete this ledger entry? Use a refund instead unless this was typed twice.';
    public static string $delete_entry = 'Delete entry';
    public static string $payment = 'Payment';
    public static string $against_invoice = 'Against invoice';
    public static string $not_against_an_invoice = 'Not against an invoice';
    public static string $against_invoice_hint = 'Only invoices with something still owed are listed.';

    public static string $hostname = 'Hostname';
    public static string $ip_address = 'IP address';
    public static string $control_panel = 'Control panel';
    public static string $use_ssl = 'Use SSL';
    public static string $nameserver_1 = 'Nameserver 1';
    public static string $nameserver_2 = 'Nameserver 2';
    public static string $credentials = 'Credentials';
    public static string $credentials_intro = 'Stored encrypted and never shown again.';
    public static string $credentials_keep = 'Leave blank to keep what is already saved.';
    public static string $api_key = 'API key';
    public static string $allocation = 'Allocation';
    public static string $not_in_a_group = 'Not in a group';
    public static string $maximum_accounts = 'Maximum accounts';
    public static string $maximum_accounts_hint = 'Blank for no limit.';
    public static string $save_server = 'Save server';
    public static string $add_server = 'Add server';

    ############################################################################
    /*======================== PRINT & REPORT SCREENS ========================*/
    ############################################################################

    public static string $print = 'Print';
    public static string $back = 'Back';
    /** %s is a formatted date. */
    public static string $issued_on = 'Issued %s';
    /** %s is a formatted date. */
    public static string $due_on = 'Due %s';
    public static string $billed_to = 'Billed to';
    public static string $balance_due = 'Balance due';

    public static string $to = 'To';
    public static string $received_in_range = 'Received in this range';
    public static string $payments_recorded = 'Payments recorded';
    public static string $refunds = 'Refunds';
    public static string $last_twelve_months = 'The last twelve months';
    public static string $orders_in_total = 'Orders in total';
    public static string $by_status = 'By status';
    public static string $no_orders_to_report = 'No orders to report on.';
    public static string $tickets_in_total = 'Tickets in total';
    public static string $still_open = 'Still open';
    public static string $by_priority = 'By priority';
    public static string $by_department = 'By department';
    public static string $nothing_to_report = 'Nothing to report.';
    public static string $no_departments_configured = 'No departments configured.';

    public static string $save_statuses = 'Save statuses';
    public static string $email_templates = 'Email templates';
    public static string $no_templates_installed = 'No templates are installed.';
    public static string $template = 'Template';
    public static string $save_template = 'Save template';
    public static string $email_template_active_hint = 'With this off, nothing using this template is sent';
    public static string $placeholders = 'Placeholders';
    public static string $no_placeholders = 'This template declares no placeholders.';
    public static string $placeholders_intro = 'Write these in the subject or the message and they are replaced when it is sent.';

    ############################################################################
    /*========================= CONTROLLER MESSAGES ==========================*/
    ############################################################################

    public static string $enter_username_or_email = 'Enter your username or email address.';
    public static string $enter_password = 'Enter your password.';
    public static string $signed_in = 'Signed in.';
    public static string $signed_out = 'Signed out.';
    /** %s is the kind of record that was not found. */
    public static string $record_not_found = 'That %s does not exist.';
    public static string $not_an_email_address = 'That does not look like an email address.';
    /** %s is the name of whatever was deleted. */
    public static string $deleted_named = 'Deleted %s.';
    /** %s is the name of whatever is being edited. */
    public static string $edit_named = 'Edit %s';

    public static string $first_name_required = 'A first name is required.';
    public static string $last_name_required = 'A last name is required.';
    public static string $email_required = 'An email address is required.';
    public static string $username_taken = 'That username is taken.';

    public static string $client_added = 'Client added.';
    public static string $client_updated = 'Client updated.';
    public static string $client_email_taken = 'Another client already uses that email address.';
    public static string $contact_added = 'Contact added.';
    public static string $contact_updated = 'Contact updated.';
    public static string $contact_removed = 'Contact removed.';
    public static string $edit_contact = 'Edit contact';
    public static string $note_cannot_be_empty = 'A note cannot be empty.';
    public static string $note_added = 'Note added.';
    public static string $note_deleted = 'Note deleted.';

    public static string $currency_needs_iso = 'A currency needs an ISO code.';
    public static string $active_clients = 'Active clients';
    public static string $orders_awaiting_review = 'Orders awaiting review';
    public static string $open_tickets_stat = 'Open tickets';
    public static string $overdue_invoices = 'Overdue invoices';
    public static string $domain_updated = 'Domain updated.';

    public static string $choose_a_client_msg = 'Choose a client.';
    public static string $invoice_needs_line = 'An invoice needs at least one line.';
    public static string $invoice_raised_msg = 'Invoice raised.';
    public static string $new_invoice = 'New invoice';
    public static string $invoice_updated = 'Invoice updated.';
    /** %s is an invoice number. */
    public static string $invoice_titled = 'Invoice %s';
    /** %s is an invoice number. */
    public static string $edit_invoice_titled = 'Edit invoice %s';
    public static string $no_client_email = 'That client has no email address to send to.';
    public static string $invoice_queued = 'Invoice queued for sending.';
    public static string $payment_greater_than_zero = 'A payment must be greater than zero.';
    public static string $payment_recorded = 'Payment recorded.';
    public static string $invoice_cancelled = 'Invoice cancelled.';
    /** %s is an invoice number. */
    public static string $deleted_invoice = 'Deleted invoice %s.';

    public static string $order_needs_line = 'An order needs at least one line.';
    public static string $order_placed = 'Order placed.';
    public static string $order_updated = 'Order updated.';
    /** %s is an order number. */
    public static string $order_titled = 'Order %s';
    /** %s is an order number. */
    public static string $edit_order_titled = 'Edit order %s';
    public static string $order_accepted = 'Order accepted and invoiced.';
    public static string $order_cancelled = 'Order cancelled.';
    /** %s is an order number. */
    public static string $deleted_order = 'Deleted order %s.';

    public static string $product_added = 'Product added.';
    public static string $pricing_updated = 'Pricing updated.';
    public static string $product_updated = 'Product updated.';
    public static string $product_groups = 'Product groups';
    public static string $group_needs_name = 'A group needs a name.';
    public static string $group_updated = 'Group updated.';
    public static string $group_added = 'Group added.';
    public static string $product_name_required = 'A product name is required.';
    public static string $choose_group_for_product = 'Choose a group for this product.';
    public static string $choose_product_type = 'Choose a product type.';
    public static string $usage_based = 'Usage based';

    public static string $staff_email_taken = 'Another staff member already uses that email address.';
    public static string $your_details_saved = 'Your details were saved.';
    public static string $your_password_changed = 'Your password was changed.';
    public static string $signed_out_everywhere_msg = 'Signed out of every device. Sign in again to continue.';

    public static string $server_added = 'Server added.';
    public static string $server_updated = 'Server updated.';
    public static string $name_required = 'A name is required.';
    public static string $hostname_required = 'A hostname is required.';
    public static string $ip_required = 'An IP address is required.';
    public static string $which_control_panel = 'Which control panel does this server run?';

    public static string $php_mail = 'PHP mail()';
    public static string $enter_test_address = 'Enter an address to send the test to.';
    /** %s is an email address. */
    public static string $test_queued_for = 'Test message queued for %s. Run the worker to send it.';
    public static string $subject_required = 'A subject is required.';
    public static string $message_cannot_be_empty = 'The message cannot be empty.';
    public static string $template_saved = 'Template saved.';
    public static string $settings_saved = 'Settings saved.';
    public static string $nothing_to_save = 'Nothing to save.';
    public static string $statuses_saved = 'Statuses saved.';
    public static string $ticket_priorities = 'Ticket priorities';
    public static string $email_queue = 'Email queue';

    public static string $password_required = 'A password is required.';
    public static string $staff_member_added = 'Staff member added.';
    public static string $staff_member_updated = 'Staff member updated.';
    public static string $cannot_delete_own_account = 'You cannot delete your own account.';
    public static string $role_needs_name = 'A role needs a name.';
    public static string $role_added = 'Role added.';
    public static string $role_updated = 'Role updated.';
    public static string $choose_a_role_msg = 'Choose a role.';

    public static string $choose_a_department_msg = 'Choose a department.';
    public static string $ticket_needs_message = 'A ticket needs a message.';
    public static string $ticket_opened = 'Ticket opened.';
    /** %s is a ticket number. */
    public static string $ticket_titled = 'Ticket %s';
    public static string $internal_note_added = 'Internal note added.';
    public static string $reply_sent = 'Reply sent.';

    public static string $currency_updated = 'Updated %s.';
    public static string $currency_added = 'Added %s.';
    /** %s is a registrar id, used only when the registrar has no name. */
    public static string $registrar_numbered = 'Registrar %s';
    public static string $ticket_updated = 'Ticket updated.';
    /** %s is a ticket number. */
    public static string $deleted_ticket = 'Deleted ticket %s.';
    public static string $support_departments = 'Support departments';
    public static string $department_needs_name = 'A department needs a name.';
    public static string $department_updated = 'Department updated.';
    public static string $department_added = 'Department added.';
    public static string $how_much_was_paid = 'How much was paid?';
    /** %s is a transaction id. */
    public static string $transaction_numbered = 'Transaction #%s';
    public static string $refund_recorded = 'Refund recorded.';
    public static string $transaction_deleted = 'Transaction deleted.';

    /** %s is a permission name such as invoice.read. */
    public static string $no_permission_to = 'You do not have permission to %s.';

    ############################################################################
    /*============================= SITE CONTENT =============================*/
    ############################################################################
    //
    // Announcements and the knowledgebase - written here, read on the public
    // front area. Both sit under the one `content` permission group.
    //
    // The three state labels below are worth reading together, because "active"
    // on its own does not say whether the public can see something:
    //   live      - active, and its publish date has passed
    //   scheduled - active, but dated in the future
    //   retracted - switched off entirely (draft, for an article)

    public static string $site_content = 'Site content';
    public static string $announcements = 'Announcements';
    public static string $announcements_lower = 'announcements';
    public static string $knowledgebase = 'Knowledgebase';
    public static string $articles = 'articles';
    public static string $categories = 'Categories';
    public static string $category = 'Category';
    public static string $uncategorised = 'Uncategorised';
    public static string $any_category = 'Any category';

    public static string $title = 'Title';
    public static string $body = 'Body';
    public static string $url_slug = 'URL slug';
    public static string $views = 'Views';
    public static string $published = 'Published';
    public static string $filing = 'Filing';
    public static string $visibility = 'Visibility';
    public static string $publish_from = 'Publish from';
    public static string $view = 'View';

    public static string $live = 'Live';
    public static string $scheduled = 'Scheduled';
    public static string $retracted = 'Retracted';
    public static string $draft = 'Draft';
    public static string $hidden = 'Hidden';

    public static string $add_announcement = 'Add announcement';
    public static string $add_first_announcement = 'Write the first announcement';
    public static string $search_announcements = 'Search announcements';
    public static string $count_announcement = 'announcement';
    public static string $count_announcements = 'announcements';
    public static string $no_announcements_yet = 'Nothing has been announced yet.';
    public static string $no_announcement_matches = 'No announcement matches that search.';

    public static string $add_article = 'Add article';
    public static string $add_first_article = 'Write the first article';
    public static string $search_articles = 'Search articles';
    public static string $count_article = 'article';
    public static string $count_articles = 'articles';
    public static string $no_articles_yet = 'No articles have been written yet.';
    public static string $no_article_matches = 'No article matches that search.';

    public static string $add_category = 'Add category';
    public static string $add_first_category = 'Add the first category';
    public static string $no_categories_yet = 'No categories have been created yet.';

    public static string $html_allowed = 'HTML is allowed. This is rendered as written on the public site.';
    public static string $article_slug_hint = 'Leave empty to build one from the title. A duplicate is refused, not renamed.';
    public static string $publish_from_hint = 'A future date keeps it hidden until then.';
    public static string $article_featured_hint = 'Show this near the top of the support and knowledgebase pages.';
    public static string $announcement_active_hint = 'Off retracts it from the public site.';
    public static string $article_active_hint = 'Off keeps it as a draft.';
    public static string $category_active_hint = 'Off hides the category and its articles.';

    public static string $confirm_delete = 'Delete this permanently?';
    public static string $confirm_delete_category = 'Delete this category? Its articles are kept and become uncategorised.';

    /** %s is a slug that is already taken. */
    public static string $slug_taken = 'The slug "%s" is already in use.';
    public static string $title_required = 'A title is required.';
    public static string $body_required = 'Some body text is required.';

    public static string $announcement_added = 'Announcement added.';
    public static string $announcement_updated = 'Announcement updated.';
    public static string $announcement_deleted = 'Announcement deleted.';
    public static string $article_added = 'Article added.';
    public static string $article_updated = 'Article updated.';
    public static string $article_deleted = 'Article deleted.';
    public static string $category_added = 'Category added.';
    public static string $category_updated = 'Category updated.';
    public static string $category_deleted = 'Category deleted.';

    ############################################################################
    /*=========================== SCHEDULED TASKS ============================*/
    ############################################################################

    public static string $cron_never_run = 'Scheduled tasks have never run on this installation.';
    /** %s is when cron last ran, already formatted. */
    public static string $cron_stale = 'Scheduled tasks last ran %s, which is longer ago than expected.';
    /** %s is when cron last ran, already formatted. */
    public static string $cron_ok = 'Scheduled tasks last ran %s.';
    public static string $cron_setup_hint = 'Until this runs every few minutes, renewal invoices will not be raised, reminders will not be sent, and queued email will not be delivered. Schedule this command on your server:';

    ############################################################################
    /*============================ EMAIL TEMPLATES ===========================*/
    ############################################################################

    public static string $all_templates = 'All templates';
    public static string $add_template = 'New template';
    public static string $template_slug_hint = 'The name the application looks this template up by, such as invoice-created. Lower case and hyphens; it is tidied up for you.';
    public static string $template_name_hint = 'A label for this list. Only staff ever see it.';
    public static string $template_placeholder_syntax = 'Write placeholders as {{name}} — double braces. Single braces are treated as ordinary text and reach the customer unchanged. Every template can use these:';

    public static string $slug_required = 'A slug is required.';
    /** %s is a template name that is already taken. */
    public static string $template_name_taken = 'A template called "%s" already exists.';

    public static string $template_added = 'Template added.';
    public static string $template_deleted = 'Template deleted.';
    /** %s is the template name. */
    public static string $confirm_delete_template = 'Delete the "%s" template? If the application still sends it, the next migration puts the default back.';

    ############################################################################
    /*=========================== GATEWAY CALLBACKS ==========================*/
    ############################################################################
    //
    // Phase 22.3. `callback_<outcome>` is built from the enum value the action
    // recorded, so a new outcome needs a matching key added HERE at the same
    // time - local() throws on a missing key, which takes the screen down
    // rather than showing a blank. That is the intended failure, and the reason
    // the outcomes are a short closed list.

    public static string $gateway_callbacks = 'Gateway callbacks';
    public static string $gateway_callbacks_lead = 'What your payment gateways have sent back, and what was done about each one. '
        . 'A gateway that is not reaching this installation shows nothing here at all.';
    public static string $webhook_url = 'Webhook URL - paste this into the gateway\'s dashboard';
    public static string $outcome = 'Outcome';
    public static string $any_outcome = 'Any outcome';
    public static string $filter = 'Filter';
    public static string $no_callbacks_yet = 'No gateway has called back yet. If you are expecting payments to settle automatically, check the webhook URL on the gateway itself.';
    public static string $received = 'Received';
    public static string $gateway = 'Gateway';
    public static string $attempts = 'Deliveries';
    public static string $unverified = 'Unverified';
    public static string $count_callbacks = 'callbacks';

    public static string $callback_applied = 'Payment recorded';
    public static string $callback_duplicate = 'Already seen';
    public static string $callback_unverified = 'Signature failed';
    public static string $callback_ignored = 'Nothing to do';
    public static string $callback_rejected = 'Refused';

    ############################################################################
    /*============================== PROVISIONING ============================*/
    ############################################################################
    //
    // Phase 22.4. `not_provisioned` covers three different situations on
    // purpose - the invoice is unpaid, or it is paid and cron has not run yet,
    // or the product has no provisioning module and staff set it up by hand.
    // The service column says which by showing a status when there IS one.

    public static string $service = 'Service';
    public static string $not_provisioned = 'Not set up yet';

    ############################################################################
    /*================================ DUNNING ===============================*/
    ############################################################################
    //
    // Phase 23. Two of these carry a %d, so a literal percent anywhere in them
    // would have to be %%; there is not one, deliberately - "7 days" reads
    // better than "0.5%" ever does in a sentence somebody is skim-reading while
    // a customer is on the phone.

    public static string $services = 'Services';
    public static string $details = 'Details';
    public static string $automation = 'Automation';
    public static string $billing_settings = 'Billing settings';

    public static string $count_service = 'service';
    public static string $count_services = 'services';
    public static string $search_services = 'Search domain, username or client';
    public static string $no_services_yet = 'No services yet. They appear here once a paid order is provisioned.';
    public static string $no_service_matches = 'No service matches that search.';
    public static string $no_server_set = 'None - set up by hand';

    public static string $suspend = 'Suspend';
    public static string $unsuspend = 'Unsuspend';
    public static string $suspend_service = 'Suspend this service';
    public static string $suspension_reason = 'Reason';
    public static string $suspension_reason_hint = 'The client is shown this, so write it for them.';
    public static string $confirm_suspend_service = 'Suspend this service? The client will be told.';

    public static string $suspended_automatically = 'Suspended automatically for non-payment';
    public static string $suspended_by_staff = 'Suspended by a member of staff';
    public static string $service_owes = 'There is an unpaid invoice against this service:';
    public static string $service_on_hold = 'Left alone by the automatic sweep for %d more days, because it was switched back on by hand.';

    public static string $dunning_on_note = 'Services are suspended automatically %d days after an invoice falls due, and switched back on when it is paid.';
    public static string $dunning_off_note = 'Automatic suspension is switched off, so nothing here is switched off for non-payment.';
    public static string $dunning_will_suspend = 'It will be suspended automatically once the grace period runs out.';

    public static string $module_failing = 'The provisioning module refused the last request (attempt %d).';
    public static string $module_gave_up = 'The provisioning module refused %d times and is no longer being retried. Fix it, then use the buttons above.';

    public static string $service_reason_required = 'Say why it is being suspended - the client is shown it.';
    public static string $service_suspended = 'The service has been suspended.';
    public static string $service_restored = 'The service is active again.';
    public static string $service_suspend_failed = 'Could not suspend it: %s';
    public static string $service_restore_failed = 'Could not switch it back on: %s';

    public static string $invoice_generate_days = 'Raise invoices this many days ahead';
    public static string $invoice_generate_days_hint = 'How much notice a client gets before a renewal is due.';
    public static string $invoice_reminder_days = 'Reminder days';
    public static string $invoice_reminder_days_hint = 'Days relative to the due date, comma separated. Negative is before. Example: -7,0,3';
    public static string $suspend_overdue = 'Suspend services when an invoice is overdue';
    public static string $suspend_overdue_hint = 'Off until you switch it on.';
    public static string $suspend_overdue_days = 'Grace period, in days';
    public static string $suspend_overdue_days_hint = 'Counted from the due date, not from the invoice date.';
    public static string $suspend_overdue_warning = 'Switching this on affects invoices that are ALREADY overdue, including any that were written off or forgotten about. Check the invoice list before you turn it on.';

    ############################################################################
    /*=========================== END OF A SERVICE ===========================*/
    ############################################################################
    //
    // Phase 24. Cancelling and terminating get separate words everywhere,
    // including in the flash messages: an operator who reads "cancelled" and
    // believes the account is gone will find it still running months later, and
    // one who reads "terminated" and believes it is only paused will tell a
    // customer their data is safe when it is not.

    public static string $at_end_of_term = 'At the end of the current term';
    public static string $immediately = 'Immediately';

    public static string $cancel_service = 'Cancel this service';
    public static string $cancel_reason_hint = 'Kept on the record and shown to the client.';
    public static string $confirm_cancel_service_staff = 'Cancel this service? Billing stops; nothing is deleted.';
    public static string $call_off_cancellation = 'Call it off';

    public static string $service_ends_on = 'Due to end on %s';
    public static string $service_ends_note = 'It is still running and still billed until then. Nothing has been deleted.';

    public static string $terminate = 'Terminate';
    public static string $terminate_service = 'Terminate this service';
    public static string $terminate_note = 'Removes the account and its data from the server. This cannot be undone.';
    public static string $terminate_auto_note = 'Cancelled services are terminated automatically after %d days.';
    public static string $confirm_terminate_service = 'Destroy this account and its data? This cannot be undone.';
    public static string $type_to_confirm = 'Confirm';
    public static string $type_to_confirm_hint = 'Type %s to confirm.';

    public static string $service_cancel_scheduled = 'The service is scheduled to end.';
    public static string $service_cancelled = 'The service has been cancelled.';
    public static string $service_uncancelled = 'The cancellation has been called off.';
    public static string $service_terminated = 'The service has been terminated.';
    public static string $service_cancel_failed = 'Could not cancel it: %s';
    public static string $service_terminate_failed = 'Could not terminate it: %s';
    public static string $service_terminate_confirm = 'Type %s in the confirmation box to terminate it.';

    public static string $terminate_cancelled_days = 'Terminate cancelled services after (days)';
    public static string $terminate_cancelled_days_hint = 'Zero means never. Nothing is destroyed automatically until you set a number.';
    public static string $terminate_cancelled_warning = 'A number here DESTROYS accounts and their data, on a schedule, without asking again. It applies to services cancelled in the past as well as future ones.';

    ############################################################################
    /*================================== TAX =================================*/
    ############################################################################
    //
    // Phase 25. A literal percent sign has to be written %% - these are sprintf
    // formats, and a stray single % is an unterminated conversion that throws
    // on a screen that was working the day before.

    public static string $tax = 'Tax';
    public static string $tax_rules = 'Tax rules';
    public static string $tax_rules_hint = 'Copied onto invoices as they are raised';
    public static string $no_tax_rules = 'No tax rules yet. Nothing is being charged.';
    public static string $rule_name = 'Rule';
    public static string $applies_to = 'Applies to';
    public static string $rate_percent = 'Rate (%%)';
    public static string $compound = 'Compound';
    public static string $compound_hint = 'Charge this on the price plus the tax already on it, not on the price alone.';
    public static string $all_countries = 'Everywhere else';
    public static string $all_states = 'All states';
    public static string $add_a_tax_rule = 'Add a tax rule';
    public static string $tax_country_hint = 'A rule with no country is the fallback for countries that have no rule of their own.';
    public static string $tax_state_hint = 'Leave blank for the whole country. A rule naming a state beats one that does not.';
    public static string $tax_rule_added = 'Added the tax rule %s.';
    public static string $tax_rule_updated = 'Updated the tax rule %s.';
    public static string $confirm_delete_tax_rule = 'Delete the tax rule %s? Invoices already raised keep the rate they were charged at.';
    public static string $tax_precedence_note = 'The most specific rule wins. If any rule names the country a client is in, only those rules apply to them, and within those a rule naming their state beats one that does not. Rules that survive that are added together. Changing anything here affects invoices raised from now on - the rate is copied onto each line when the invoice is created, so nothing you do on this screen alters a document that already exists.';

    public static string $how_prices_are_quoted = 'How prices are quoted';
    public static string $tax_rate_hint = 'A rate here is used for this product instead of the tax rules. Leave at zero to use them.';
    public static string $invoice_tax_hint = 'Used for lines that carry no rate of their own.';

    public static string $prices_include_tax = 'Catalogue prices include tax';
    public static string $prices_include_tax_hint = 'Tick if the price on a product page is what the customer pays, tax and all.';
    public static string $prices_include_tax_note = 'This changes what an existing price MEANS, not what it says. Turning it on makes every published price tax inclusive from that moment, so the amount you take for the same product goes down by the tax. Invoices already raised are untouched.';

    ############################################################################
    /*================================= ADDONS ===============================*/
    ############################################################################
    //
    // Phase 26. The extras sold alongside a product.

    public static string $addon = 'Addon';
    public static string $addons = 'Addons';
    public static string $addons_hint = 'Extras sold alongside a plan';
    public static string $no_addons = 'No addons yet. Nothing extra is on offer.';
    public static string $add_an_addon = 'Add an addon';
    public static string $addon_added = 'The addon has been added. Price it before it can be ordered.';
    public static string $addon_updated = 'The addon has been updated.';
    public static string $addon_name = 'Name';
    public static string $addon_description_hint = 'Shown to the customer beside the checkbox on the product page.';
    public static string $addon_pricing_model_hint = 'Recurring is billed with the plan every cycle. One time is charged once, like a setup fee.';
    public static string $addon_active_hint = 'Only active addons are offered to customers.';
    public static string $how_addons_work = 'How addons work';
    public static string $addon_help = 'An addon is its own line on the invoice and its own row against the service, so a customer can drop one and keep the plan. It is billed with the plan it hangs off, on the plan\'s cycle and due date, and it stops when the service does. Price it per currency and cycle on its own screen, then tick it on the products that should offer it.';
    public static string $offered_on = 'Offered on';
    public static string $on_n_products = 'On %d product(s)';
    public static string $on_no_products = 'On no products';
    public static string $addon_on_no_products = 'No product offers this yet. Tick it on a product to sell it.';
    public static string $addon_mapping_hint = 'Set on each product, not here';
    public static string $product_addons_hint = 'Extras a customer may add to this plan';
    public static string $confirm_delete_addon = 'Delete the addon %s? Services already paying for it keep it.';
    public static string $renews_at = 'Renews at';
    public static string $inactive = 'Inactive';
    public static string $one_time = 'One time';

    ############################################################################
    /*=============================== TLD PRICING ============================*/
    ############################################################################
    //
    // Phase 27.1. The `tlds` table has existed since Phase 0 with no screen.

    public static string $domain_pricing = 'Domain pricing';
    public static string $tlds_hint = 'The endings this shop sells, and what each one costs.';
    public static string $add_an_ending = 'Add an ending';
    public static string $tld_added = 'The ending has been added.';
    public static string $tld_updated = 'The ending has been updated.';
    public static string $no_tlds = 'No domain endings are priced yet, so no domain can be ordered.';
    public static string $no_registrars = 'There are no registrars set up.';
    public static string $no_registrars_hint = 'An ending has to point at a registrar. Add one before pricing a domain ending.';
    public static string $ending = 'Ending';
    public static string $register_price = 'Register';
    public static string $renew_price = 'Renew';
    public static string $transfer_price = 'Transfer';
    public static string $restore_price = 'Restore';
    public static string $min_years = 'Shortest term';
    public static string $max_years = 'Longest term';
    /** %s is a count of years, or a list of them. */
    public static string $n_years = '%s year(s)';
    public static string $registrar_manual = 'No module - registered by hand';
    public static string $no_orderable_term = 'No orderable term';
    /** %s is the ending. */
    public static string $confirm_delete_tld = 'Delete the ending %s? It is refused while domains are registered on it.';
    /** %s is the default currency code. */
    public static string $tld_currency_note = 'Each ending is priced in one currency only. A customer checking out in another one cannot order it. Your default is %s.';
    public static string $tld_hint = 'With or without the leading dot. Stored as .com either way.';
    public static string $tld_registrar_hint = 'Who registers names on this ending.';
    public static string $tld_currency_hint = 'The one currency these prices are in. There is no conversion.';
    /** %s is the longest recordable term in years. */
    public static string $tld_terms_hint = 'A domain renews annually, biennially or triennially, so %s years is the longest term that can be recorded.';
    public static string $tld_price_per_year_hint = 'Per year. A two-year registration is charged at twice this, once.';
    public static string $epp_required = 'Needs an auth code to transfer';
    public static string $epp_required_hint = 'Most endings do. It is the code the losing registrar gives the owner.';
    public static string $tld_id_protection_hint = 'Whether new registrations on this ending get privacy by default.';
    public static string $tld_active_hint = 'Turn this off to stop selling the ending without losing its prices.';
    public static string $how_tlds_work = 'How domain pricing works';
    public static string $tld_help = 'An ending has one price list and one registrar. A customer searching for a name is quoted from the row matching the longest ending - so .co.uk beats .uk when both are sold.';
    public static string $tld_help_currency = 'Prices are not converted between currencies. An ending priced in one currency is sold only to customers checking out in it.';

    ############################################################################
    /*============================ DOMAIN RENEWALS ===========================*/
    ############################################################################
    //
    // Phase 27.2. Until this phase a registered domain was never billed again.

    public static string $domain_renewals = 'Domain renewals';
    public static string $domain_renew_days = 'Raise renewal invoices';
    public static string $domain_renew_days_hint = 'Days before a domain expires. Longer than a service, because a lapsed domain can be taken by somebody else.';
    public static string $domain_grace_days = 'Grace period';
    public static string $domain_grace_days_hint = 'Days after expiry before a domain needs a restore fee rather than a renewal.';
    public static string $domain_renewals_note = 'A customer who switches off automatic renewal on a domain is not invoiced for it. Nothing is ever deleted automatically - the registry decides when a name is released.';
    public static string $registry_reference = 'Registry reference';
    public static string $renewed_through = 'Renewed through';
    public static string $registrar_last_error = 'The registrar refused the last attempt';
    /** %s is a count of attempts. */
    public static string $attempts_made = '%s attempt(s) made.';
    public static string $expiry_unknown_note = 'The registrar did not report an expiry date. The renewal date here is the term that was paid for, not something the registry has confirmed.';

    // Phase 26.2. Five config tables from Phase 0 with no reader anywhere.

    public static string $config_options = 'Configurable';
    public static string $config_option = 'Configurable option';
    public static string $config_options_hint = 'The sizes and choices a plan is sold in. The price of what a customer picks is added to the plan\'s own price.';
    public static string $add_a_config_option = 'Add a configurable option';
    public static string $no_config_options = 'No configurable options yet.';
    public static string $config_option_added = 'Configurable option added.';
    public static string $config_option_updated = 'Configurable option updated.';
    public static string $config_option_name = 'Name';
    public static string $config_option_name_hint = 'What the customer sees above the field on the order form.';
    public static string $config_option_description_hint = 'Shown under the field. Leave it blank if the name says enough.';
    public static string $config_type = 'Field type';
    public static string $config_type_hint = 'Dropdown and radio take one choice; checkbox takes any number; quantity multiplies one choice by a number the customer types; text takes free text and cannot be priced.';
    public static string $config_required_hint = 'A required field has to be answered before the plan can be added to the cart.';
    public static string $required = 'Required';
    public static string $optional = 'Optional';
    public static string $config_choices = 'Choices';
    public static string $config_choice_name = 'Choice';
    public static string $add_config_choice = 'Add choice';
    public static string $config_choices_hint = 'Listed in the order they are added. There is no way to reorder them.';
    public static string $config_choice_added = 'Choice added.';
    public static string $config_choice_updated = 'Choice updated.';
    public static string $config_choice_deleted = 'Choice deleted.';
    public static string $config_no_choices = 'No choices';
    public static string $config_no_choices_hint = 'This field has no choices, so it cannot be shown on an order form. Add at least one.';
    public static string $config_free_text = 'Free text';
    public static string $config_text_no_pricing = 'A text field has no choices and no prices. Pricing is per choice, and free text has none.';
    public static string $config_mapping_hint = 'Tick this option on a product to offer it there.';
    public static string $config_on_no_products = 'No product offers this option yet, so nobody can choose it.';
    public static string $product_config_hint = 'The sizes and choices this plan is sold in.';
    public static string $how_config_options_work = 'How configurable options work';
    public static string $config_option_help = 'A configurable option is one field on the order form: a name, a type, and the choices under it. Each choice is priced per currency and per billing cycle, and what the customer picks is added to the plan\'s own price rather than billed as a separate line.';
    public static string $config_option_help_two = 'That is why there is no way to cancel one on its own: it is part of the plan. Something a customer can drop and keep the plan is an addon.';
    public static string $configuration = 'Configuration';
    public static string $price = 'Price';
    public static string $n_choices = '%s choice(s)';
    public static string $confirm_delete_config_option = 'Delete the configurable option "%s"? Its choices and their prices go with it.';
    public static string $confirm_delete_config_choice = 'Delete the choice "%s"? Its prices go with it.';

    // Phase 27.3. RegistrarInterface::transfer() had no caller anywhere.

    public static string $transfer_submitted = 'Transfer sent to the registrar';
    public static string $transfer_not_sent = 'This transfer has not reached the registrar yet. It is waiting for an auth code from the customer, for a registrar module, or for the next cron run.';
    public static string $complete_transfer = 'Mark complete';
    public static string $expiry_date = 'Expiry date';
    public static string $domain_not_a_transfer = 'That domain is not a transfer.';
    public static string $domain_transfer_completed = 'Transfer marked complete.';
    public static string $confirm_complete_transfer = 'Mark the transfer of %s complete? The domain becomes active and starts renewing.';

    // Phase 27.4. promo_codes had no reader anywhere since Phase 0.

    public static string $promo_codes = 'Promo codes';
    public static string $promo_codes_hint = 'Money off, at your invitation. A code is created switched off - turn it on when the campaign starts.';
    public static string $add_a_promo = 'Add a code';
    public static string $no_promos = 'No promotional codes yet.';
    public static string $promo_added = 'Code added.';
    public static string $promo_updated = 'Code updated.';
    public static string $promo_code = 'Code';
    public static string $promo_code_hint = 'What the customer types. Case does not matter.';
    public static string $promo_type = 'Kind';
    public static string $promo_type_hint = 'A percentage works in every currency. A fixed amount is money, so it only works in the one it is priced in.';
    public static string $promo_value = 'Value';
    public static string $promo_currency_hint = 'Required for a fixed amount, ignored for a percentage.';
    public static string $promo_no_currency = 'None (percentage)';
    public static string $promo_applies_to = 'Applies to';
    public static string $promo_scope_all = 'Everything';
    public static string $promo_scope_products = 'Products and their extras';
    public static string $promo_scope_domains = 'Domains';
    public static string $promo_max_uses = 'Maximum uses';
    public static string $promo_max_uses_hint = 'Leave blank for unlimited. Counted when an order is placed, not when it is paid.';
    public static string $promo_starts = 'Starts';
    public static string $promo_ends = 'Ends';
    public static string $promo_ends_hint = 'Leave blank to run until you switch it off.';
    public static string $promo_active_hint = 'A code does nothing until this is ticked.';
    public static string $promo_used = 'Used';
    public static string $promo_runs = 'Runs';
    public static string $promo_unlimited = 'unlimited';
    public static string $promo_used_up = 'Used up';
    public static string $promo_not_started = 'Not started yet';
    public static string $promo_finished = 'Finished';
    public static string $promo_products = 'Restrict to these products';
    public static string $promo_products_hint = 'Only used when the code applies to products. Tick none to mean every product.';
    public static string $how_promos_work = 'How codes work';
    public static string $promo_help = 'A code takes money off the lines it applies to, before tax, and the invoice shows what was taken off each one. A fixed amount is shared across the lines it covers rather than taken off each of them.';
    public static string $promo_help_two = 'It is counted once per order. There is no recurring discount: a renewal is billed from the price on the service, and nothing carries a code forward to it.';
    public static string $promo_used_hint = 'Counted when an order is placed. It cannot be edited - a campaign limit that can be reset is not a limit.';
    public static string $promo_used_n = 'Used %s time(s)';
    public static string $promo_of_n = 'of %s';
    public static string $confirm_delete_promo = 'Delete the code "%s"?';

    ############################################################################
    /*=================== CREDIT NOTES & REFUNDS (PHASE 28) ==================*/
    ############################################################################

    public static string $credit_notes = 'Credit notes';
    public static string $credit_note = 'Credit note';
    public static string $credit_note_numbered = 'Credit note %s';
    public static string $issue_a_credit_note = 'Issue a credit note';
    public static string $issue_credit_note = 'Issue credit note';
    public static string $credit_note_issued = 'Credit note issued.';
    public static string $credit_note_voided = 'Credit note voided.';
    public static string $no_credit_notes = 'No credit notes have been issued yet.';
    public static string $credit_note_help = 'A credit note says a customer does not owe something. It moves no money: it puts credit on their account, which settles against the next invoice they are sent. To send money back instead, refund the payment.';
    public static string $credit_note_amount_hint = 'Gross - what the customer is not being asked for, tax included.';
    public static string $creditable_left = '%s left to credit on this invoice';
    public static string $credited_so_far = 'Credited';
    public static string $used_amount = 'Used';
    public static string $unspent = 'Unspent';
    public static string $void_credit_note = 'Void credit note';
    public static string $confirm_void_credit_note = 'Void this credit note? The credit goes back off the account.';
    public static string $credit_note_tax_note = 'Tax inside this credit note, at the rate on the invoice it credits.';
    public static string $credit_note_no_invoice = 'Not against an invoice, so no tax is stated.';
    public static string $for_invoice = 'For invoice';
    public static string $goodwill_credit = 'Goodwill credit';

    public static string $refundable_left = '%s can still go back';
    public static string $refund_through_gateway = 'Refund through %s';
    public static string $record_refund_by_hand = 'I have refunded this myself - record it';
    public static string $refund_to_credit = 'Give it back as account credit instead';
    public static string $confirm_refund_by_hand = 'Record a refund you have already made outside this system? Nothing will be sent to the payment processor.';
    public static string $refund_refusal_not_a_payment = 'Only a payment can be refunded.';
    public static string $refund_refusal_no_gateway = 'This payment did not come through a gateway, so there is nothing to send it back through. Refund it the way it was taken, then record that here.';
    public static string $refund_refusal_no_driver = 'The gateway this came through is no longer installed or switched on, so it cannot be asked for a refund.';
    public static string $refund_refusal_no_reference = 'This payment has no reference at the gateway, so the processor cannot be told which charge to reverse.';
    public static string $refunded_amount = 'Refunded';

    ############################################################################
    /*==================== DOMAIN CONTACTS (PHASE 29) =======================*/
    ############################################################################

    public static string $domain_contacts = 'Registry contacts';
    public static string $domain_contacts_saved = 'Contact saved.';
    public static string $domain_contact_cleared = 'Contact cleared. The registrant is used for that role again.';
    public static string $clear_contact = 'Clear';
    public static string $domain_contact_role = 'Role';
    public static string $no_registrant = 'Nobody is registered to this domain. A registrar will refuse it until somebody is.';
    public static string $no_registrant_short = 'No registrant';
    public static string $contact_registrant = 'Registrant';
    public static string $contact_admin = 'Administrative';
    public static string $contact_tech = 'Technical';
    public static string $contact_billing = 'Billing';
    public static string $contact_abuse = 'Abuse';
    public static string $contact_mirrored = 'Not set separately - the registrant is used for this role.';
    public static string $address_one = 'Address';
    public static string $address_two = 'Address line 2';
    public static string $phone_cc = 'Dialling code';
    public static string $domain_contacts_help = 'These are sent to the registry when the domain is registered, transferred or renewed. Changing them here updates this record only - it does not tell the registry, because many endings treat a registrant change as a transfer of ownership.';
}
