/*
 * Laika Bill Manager — bootstrap theme
 * Author: Showket Ahmed
 *
 * Progressive enhancement only. Every screen works with this file absent:
 * filters submit with their button, destructive actions still POST, the sidebar
 * is only hidden below the lg breakpoint. Nothing here is load-bearing.
 */
(function () {
    'use strict';

    /* --------------------------------------------------------------------
     * Sidebar, below the lg breakpoint
     * ------------------------------------------------------------------ */
    function sidebar() {
        var aside = document.querySelector('[data-lbm-sidebar]');
        var toggle = document.querySelector('[data-lbm-sidebar-toggle]');
        if (!aside || !toggle) return;

        var backdrop = null;

        function close() {
            aside.classList.remove('is-open');
            if (backdrop) { backdrop.remove(); backdrop = null; }
        }

        toggle.addEventListener('click', function (e) {
            e.preventDefault();
            if (aside.classList.contains('is-open')) { close(); return; }

            aside.classList.add('is-open');
            backdrop = document.createElement('div');
            backdrop.className = 'lbm-backdrop';
            backdrop.addEventListener('click', close);
            document.body.appendChild(backdrop);
        });

        // A resize back to desktop leaves the backdrop stranded over the page.
        window.addEventListener('resize', function () {
            if (window.innerWidth > 991.98) close();
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') close();
        });
    }

    /* --------------------------------------------------------------------
     * Confirm before a destructive POST
     *
     * The form still submits without JS - this only adds the prompt, it is
     * never what enforces anything. Authorisation is decided server-side by
     * LBM\Pipeline\Permission.
     * ------------------------------------------------------------------ */
    function confirmations() {
        document.addEventListener('submit', function (e) {
            var form = e.target;
            if (!(form instanceof HTMLFormElement)) return;

            var message = form.getAttribute('data-lbm-confirm');
            if (message && !window.confirm(message)) e.preventDefault();
        });
    }

    /* --------------------------------------------------------------------
     * Filter selects submit their own form
     *
     * Search and filtering are GET, so this only ever changes the query
     * string - it never mutates anything.
     * ------------------------------------------------------------------ */
    function autoSubmit() {
        document.querySelectorAll('[data-lbm-autosubmit]').forEach(function (el) {
            el.addEventListener('change', function () {
                var form = el.closest('form');
                if (form) form.submit();
            });
        });
    }

    /* --------------------------------------------------------------------
     * Dismissible alerts fade themselves out
     * ------------------------------------------------------------------ */
    function alerts() {
        document.querySelectorAll('[data-lbm-autohide]').forEach(function (el) {
            window.setTimeout(function () {
                el.classList.add('fade');
                window.setTimeout(function () { el.remove(); }, 300);
            }, 6000);
        });
    }

    /* --------------------------------------------------------------------
     * Repeating form rows
     *
     * The order and invoice line tables post parallel arrays - items[0][...],
     * items[1][...] - so a new row has to be renumbered, not just cloned. The
     * index comes from how many rows are already there, and every name and id
     * on the clone is rewritten to match.
     *
     * Progressive enhancement: without JavaScript the form still works, it just
     * submits however many rows were rendered.
     * ------------------------------------------------------------------ */
    function repeatableRows() {
        document.querySelectorAll('[data-lbm-add-row]').forEach(function (button) {
            button.addEventListener('click', function () {
                var table = document.querySelector(button.getAttribute('data-lbm-add-row'));
                if (!table) return;

                var body = table.querySelector('tbody');
                if (!body || !body.rows.length) return;

                var last = body.rows[body.rows.length - 1];
                var clone = last.cloneNode(true);
                var index = body.rows.length;

                clone.querySelectorAll('input, select, textarea').forEach(function (field) {
                    if (field.name) {
                        // items[3][amount] -> items[4][amount]
                        field.name = field.name.replace(/\[(\d+)\]/, '[' + index + ']');
                    }

                    if (field.type === 'checkbox' || field.type === 'radio') {
                        field.checked = field.defaultChecked;
                    } else if (field.tagName === 'SELECT') {
                        field.selectedIndex = 0;
                    } else if (field.type !== 'hidden') {
                        field.value = '';
                    }
                });

                body.appendChild(clone);

                var first = clone.querySelector('input:not([type=hidden]), select, textarea');
                if (first) first.focus();
            });
        });
    }

    /* --------------------------------------------------------------------
     * Check-all for the permission matrix
     *
     * A convenience only. Nothing is inferred from it on the server - every box
     * is still submitted and written individually, so this cannot grant
     * something the operator did not actually tick.
     * ------------------------------------------------------------------ */
    function checkAll() {
        document.querySelectorAll('[data-lbm-check-all]').forEach(function (master) {
            master.addEventListener('change', function () {
                var scope = document.querySelector(master.getAttribute('data-lbm-check-all'));
                if (!scope) return;

                scope.querySelectorAll('input[type=checkbox]').forEach(function (box) {
                    box.checked = master.checked;
                });
            });
        });
    }

    /* --------------------------------------------------------------------
     * Show a hidden credential
     *
     * Used for the provisioning password on a client's service. The value is
     * already in the page - this only decides whether it is on screen, so
     * nothing here is a security control. The point is that somebody sharing
     * their screen or taking a screenshot does not hand out a password they
     * were not thinking about.
     *
     * Without JS the masked dots stay and the real value stays hidden, which
     * is a worse experience but not a broken one.
     * ------------------------------------------------------------------ */
    function reveal() {
        document.querySelectorAll('[data-lbm-reveal]').forEach(function (button) {
            button.addEventListener('click', function () {
                var wrap = button.parentElement;
                if (!wrap) return;

                var value = wrap.querySelector('[data-lbm-reveal-target]');
                var mask = wrap.querySelector('[data-lbm-reveal-mask]');
                if (!value) return;

                var hidden = value.classList.contains('d-none');

                value.classList.toggle('d-none', !hidden);
                if (mask) mask.classList.toggle('d-none', hidden);

                button.setAttribute('aria-label', hidden ? 'Hide password' : 'Show password');
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        sidebar();
        confirmations();
        autoSubmit();
        alerts();
        repeatableRows();
        checkAll();
        reveal();
    }
}());
