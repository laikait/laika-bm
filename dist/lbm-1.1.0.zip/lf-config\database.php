<?php
/**
 * Laika PHP MVC Framework
 * Author: Showket Ahmed
 * Email: riyadhtayf@gmail.com
 * License: MIT
 * This file is part of the Laika PHP MVC Framework.
 * For the full copyright and license information, please view the LICENSE file that was distributed with this source code.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * Leave this file alone. The install wizard writes it.
 *
 * It must exist and be writable before installation begins - the wizard
 * rewrites it in place at the database step rather than creating it, and will
 * stop with "Config File [database] Does Not Exist." if it has been removed.
 *
 * Supported drivers: mysql, mariadb (as mysql), pgsql.
 */

return [
    'default' => [
        'driver' => 'mysql',
        'host' => 'localhost',
        'port' => 3306,
        'database' => '',
        'username' => '',
        'password' => '',
    ],
];
