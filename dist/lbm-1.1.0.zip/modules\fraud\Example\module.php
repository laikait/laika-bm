<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * A STARTER - copy it, do not switch it on.
 *
 * Copy this directory to modules/fraud/<YourService>, rename the namespace
 * below and in every file under src/, and put your screening service's two
 * addresses in src/Api.php. Then switch it on under Modules and choose it on
 * the fraud check card there - until it is chosen, no order is screened.
 *
 * A declaration and nothing else: the loader reads this during autoload and the
 * modules screen reads it again.
 */

return [
    'name'        => 'Example Fraud Check',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'A starter to copy: screens an order at checkout through a scoring API and answers pass, '
        . 'review or fail. Not a real service.',

    'class'       => \Modules\Fraud\Example\Example::class,

    'namespace'   => 'Modules\Fraud\Example',
    'src'         => 'src',
];
