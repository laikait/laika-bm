# Modules

Drop-in extensions for Laika Bill Manager. This directory lives in the
application root, **not** inside `vendor/`, so modules survive `composer
update` and are never wiped when the package is reinstalled.

| Directory     | Purpose                                              |
|---------------|------------------------------------------------------|
| `fraud/`      | Fraud screening                                      |
| `plugins/`    | Features and general extensions                      |
| `gateways/`   | Payment gateways   -> `payment_gateways` table       |
| `servers/`    | Provisioning       -> `servers` / `server_groups`    |
| `registrars/` | Domain registrars  -> `domain_registrars` table      |
| `lookup/`     | Domain availability, without registering anything    |

These six are the whole list, and it is declared once, in
`LBM\Module\ModuleManager::TYPES`. `LBM\Action\Module` aliases that constant
rather than repeating it.

`plugins/` was called `addons/` until Phase 39. The update moves an older
install's `modules/addons` into `modules/plugins` and renames each module's uid
(`addons-backup` becomes `plugins-backup`), so a module that was switched on
stays on. Run the update straight after deploying, as always: until it runs, the
loader no longer looks in `modules/addons`.

If a directory exists in **both** — `modules/addons/X` beside `modules/plugins/X`
— the update moves everything else, touches neither copy, and names the clash on
**Admin → Settings → Utilities → Update**. Keep one of the two and run the update
again. Until then `modules/addons/X` does not load. A module's namespace is
whatever its manifest declares, so a module written as `Modules\Addons\X` keeps
working from its new place without a line of it changing.

The catalogue feature called addons — extras sold beside a product, under
**Admin → Addons** — is a different thing and kept its name.

`widgets/` is gone — it was only ever an empty directory the loader did not
know about.

## Layout

A module is a directory two levels down holding a `module.php` manifest:

```
modules/gateways/Stripe/module.php
```

The directory it sits in decides its kind — the manifest is not asked, so a
module cannot claim to be something it is not by editing a string.

## The manifest

`module.php` returns an array. Everything except `name` is optional.

```php
return [
    'name'        => 'Stripe',
    'version'     => '1.0.0',
    'author'      => 'Someone',
    'description' => 'Takes card payments through Stripe.',

    // The class implementing the contract for this kind of module -
    // LBM\Module\Contracts\{Gateway,Server,Registrar,Lookup}Interface.
    'class'       => \Modules\Gateways\Stripe\Stripe::class,

    // PSR-4. The short form: one prefix, mapped to a subdirectory of the
    // module (omit `src` to map it to the module directory itself).
    'namespace'   => 'Modules\Gateways\Stripe',
    'src'         => 'src',

    // The long form, for a module shipping more than one prefix.
    // 'autoload' => ['Modules\Gateways\Stripe\' => 'src'],

    // Anything the module ships. Paths are relative to the module directory
    // and cannot escape it.
    'resources'   => [
        'models'      => ['path' => 'src/Model',      'namespace' => 'Modules\Gateways\Stripe\Model'],
        'schemas'     => ['path' => 'src/Schema',     'namespace' => 'Modules\Gateways\Stripe\Schema'],
        'controllers' => ['path' => 'src/Controller', 'namespace' => 'Modules\Gateways\Stripe\Controller'],
        'jobs'        => ['path' => 'src/Job',        'namespace' => 'Modules\Gateways\Stripe\Job'],
        'commands'    => ['path' => 'src/Command',    'namespace' => 'Modules\Gateways\Stripe\Command'],
        'routes'      => ['path' => 'routes'],
        'hooks'       => ['path' => 'hooks'],
        'functions'   => ['path' => 'functions'],
    ],
];
```

Recognised resource kinds are `models`, `schemas`, `migrations`, `controllers`,
`pipelines`, `filters`, `jobs`, `commands`, `functions`, `hooks` and `routes`.
Anything else in `resources` is ignored rather than half-registered.

`migrations` arrived in Phase 21 and is the one kind that changes a table which
already exists — see `LBM\Contract\MigrationAbstract`. A module's migrations are
found only while it is enabled, so disable → upgrade → re-enable applies them on
the next migration run, which is the correct order.

**The manifest must be a declaration and nothing else.** It is read more than
once in a request — the loader reads it during autoload, and the Modules screen
reads it again to list what is installed — so a manifest that registers a hook,
opens a connection or writes a file does all of that twice. Put that work in the
module's own `hooks/` or `functions/` files, which are loaded once.

Every PHP file in a module should open with the same guard the rest of the
application uses, the manifest included:

```php
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');
```

Each kind is held to the same contract as the application's own: a `schemas`
directory whose classes do not extend `Laika\Model\Contract\SchemaAbstract` is
refused at registration, rather than failing in the middle of a migration.

## Enabling

A module does nothing until it is switched on in **Admin → Modules**. Enabled
state is a row in the `modules` table, keyed on a uid that comes from where the
module sits — `gateways/Stripe` is `gateways-stripe` on every install.

That row is a record **about** a directory, never a substitute for one. A module
you delete by hand stops appearing the moment it is gone, whatever the table
says; the row is left behind so that putting the directory back brings its
history with it. Before Phase 31 the switch was an option row,
`module_enabled_<uid>`; a migration carries those across on update.

**Modules are installed by putting them on disk** — over SFTP, in a deployment,
or shipped inside the release. There is no upload form. There was one, from
Phase 20.2 to Phase 31, and it was removed rather than hardened: a form on the
admin panel that writes executable PHP into the application's own directory is
one validator away from remote code execution, for a convenience that only
matters to somebody who already has a shell.

Switching one on takes effect on the **next** request. Discovery runs during
composer's autoload, because the dispatcher requires every route file before it
matches a route — so by the time a page can toggle a switch, discovery is long
past. The Modules screen says `Pending` until then.

A disabled module costs a `glob()`: its manifest is never read, its classes are
not autoloadable, and `php laika app:migrate` cannot see its schemas.

**One module ships switched on: `lookup/LaikaWhois`**, and only on a fresh
install. The installer switches it on as it finishes, and only if the `modules`
table has never heard of it — so re-running the installer never switches back on
something an operator switched off, and an install upgraded from before it
existed finds it on disk and switched off. The Offline gateway ships too, and
switched off: taking payments is a decision.

## What a module is given

Every driver is constructed with **one array**, whatever its kind:

- the settings it **declares**, opened, under the names it declared them;
- `mode` — `live` or `test`.

| Kind | Where the operator fills them in | Where they are stored | Mode |
|---|---|---|---|
| Gateways | **Settings → Payment gateways** | `payment_gateways.settings` | the gateway's Live/Test switch |
| Registrars | the registrar's edit form | `domain_registrars.credentials` | the registrar's Live/Test switch |
| Lookup, fraud, plugins | **Settings → Modules → Configure** | `module_settings` | the Live/Test switch on that page |
| Servers | each product's edit form | `products.module_config` | always `live` |

A server module's fields are **per product** — a package name, a plan id. Its
connection details are the server row the operator typed in, which is already
in every call's context, and there is no sandbox of somebody's server.

The constructor is not declared on any interface, because an interface cannot
usefully fix one, but it is the contract. There is one builder per kind —
`Action\Gateway::driverFor()`, `Support\RegistersDomains`,
`Support\LooksUpDomains`, `Support\ServesServices` — and a constructor that
throws is treated as no driver at all.

### Declaring your fields

Implement `LBM\Module\Contracts\Configurable` beside your kind's own contract:

```php
use LBM\Module\Contracts\Configurable;
use LBM\Module\Contracts\RegistrarInterface;

class Namesilo implements RegistrarInterface, Configurable
{
    public static function settings(): array
    {
        return [
            'api_key'  => ['label' => 'API key', 'type' => 'password', 'required' => true],
            'reseller' => ['label' => 'Reseller account', 'type' => 'text'],
        ];
    }

    public function test(): array
    {
        $reply = (new Api($this->settings))->request('GET', 'account');

        return ['success' => $reply['status'] === 200, 'message' => $reply['error'] ?? 'Signed in.'];
    }
}
```

Types are `text`, `password`, `textarea`, `select` (with `options`), `yesno`
and `number`. The screen draws the form from `settings()`, so it must be a
declaration and nothing else — it is read every time the form is drawn, before
there is a driver to ask. A `password` field is a secret: sealed before it is
stored, never shown again, and a blank box on the form means *keep what is
saved*. Only what you declare is stored. `mode` cannot be a field name — it is
the switch.

`test()` answers the **Test connection** button, on a driver built with what is
saved, in the saved mode. Make one cheap, harmless call and say what happened
in words an operator can act on: the message is shown to them as it is.

### Your live and test API, in your own code

Extend `LBM\Module\Api` and give it both addresses. The operator never types
one — they choose Live or Test:

```php
final class Api extends \LBM\Module\Api
{
    protected function endpoints(): array
    {
        return ['live' => 'https://api.namesilo.com/v1', 'test' => 'https://sandbox.namesilo.com/v1'];
    }
}

$reply = (new Api($settings))->request('POST', 'domains', ['name' => $domain], ['X-Api-Key' => $settings['api_key']]);
// ['status' => 201, 'body' => '...', 'json' => [...], 'error' => null]
```

`request()` never throws: a refused connection or a timeout comes back as
`status` 0 with an `error` in words. It never follows a redirect, caps its time
and the size of a reply, and logs nothing. Only the word `test` selects the
sandbox; anything else is live. And a module in test mode with no `test`
address **refuses** — it never falls back to live.

### A module that declares nothing

It is still given `mode`. A **gateway** also gets whatever is stored for it, as
it always has. A **registrar** keeps the name/value credential pairs on its
form — so document the names your module expects, `api_key`, `username`,
`reseller_id`, because that is what the operator will type — and every
registrar module, declared or not, also gets `api_url` from its own field. No
credential may be called `api_url` or `mode`.

## What a lookup module is given

A lookup module answers one question - can this name be registered? - with
`available(string $domain, array $context): array`, the **same verb, shape and
three answers** as `RegistrarInterface::available()`: `true` free, `false`
taken, `null` could not say. `success` is about the call; a failed call's
`available` is never read.

It is constructed like every other module, above. Each call's `$context`
carries:

- `timeout` - the seconds this call may take. A public search has one budget
  for every TLD it asks about, and this is what is left of it, so it shrinks as
  the search goes on. Honour it.
- `tld` - the TLD being asked about, with its leading dot.

Which one is asked is chosen on **Admin → Settings → Registrars**, and the order
is fixed: the chosen lookup module, then the TLD's registrar, then "could not
say". Anything but a boolean from a successful call hands the question on to the
registrar - a WHOIS query costs nothing, a registrar call spends an API
credential. A module that throws is treated as "could not say", and is not
written to the error log: a public search is driven by visitors ten names at a
time, and a broken provider would fill it by the minute.

`LBM\Support\LooksUpDomains` is the only place a lookup driver is built.

## Starter modules

Six modules ship named `Example`, one per kind, **switched off**:
`gateways/Example`, `servers/Example`, `registrars/Example`, `lookup/Example`,
`fraud/Example` and `plugins/Example`. They are for copying, not for running:

1. Copy the directory - `modules/registrars/Example` to
   `modules/registrars/Namesilo`, say.
2. Rename the namespace in every file - `Modules\Registrars\Example` becomes
   `Modules\Registrars\Namesilo` - and the `name` in `module.php`.
3. Put your provider's two addresses in `src/Api.php`. The Examples point at
   `https://api.example.com` and `https://sandbox.example.com`, reserved names
   that never answer, so an Example switched on by mistake can do nothing.
4. Change what each verb sends and reads. Every one is documented where it is
   written, including the rules that are easy to get wrong: a redirect gateway
   answers `pending` with `success` **false** (the product reads `pending: true`
   as unpaid whatever `success` says, but never report money you have not
   taken); a registrar returns the registry's
   expiry, never a year added locally; a pending transfer is a success; and
   `terminate()` refuses a service with no account name.

`servers/Example` has no addresses to change: a server module talks to the
server the operator typed in on the servers screen. `plugins/Example` shows the
rest of what a module can ship - a route (`routes/example.php`, answering
`/example-plugin`), a hook (`hooks/example.php`, which uses `nav_extend()` to put
its settings page in the admin sidebar when its own setting says so), and
settings on its Configure page. A hook adds to a menu with `Nav::add()` and a
literal title, not `nav_item()`: that takes a language key, and a module cannot
add keys to the product's catalogue.

## What a fraud module is given

A fraud module implements `LBM\Module\Contracts\FraudInterface`:
`check(array $order, array $context): array`, answering `success`, `verdict`
(`pass`, `review`, `fail`, or `null`), `score` (0 to 100) and `message`.
Checkout asks it after the order is written and before it is invoiced - but only
once it is switched on **and** chosen on the **Fraud check** card at the top of
**Settings → Modules**. Until then no order is screened.

- `pass` - invoiced as normal.
- `review` or `fail` - **held**: the order gets the `Fraud` status and no
  invoice, and the customer is told it is being reviewed. Staff release it with
  **Accept** on the order, or end it with **Cancel**. Never refused outright: a
  false positive held is an order staff can still take.
- `null`, a failed call, an exception - **could not say**: the order goes
  through as if nothing were chosen, and the failure is written to the error log
  against the module. A screening service that is down must not stop every sale.

The score is written to `orders.fraud_score` and shown on the order. The context
carries `client`, `email`, `ip`, `amount`, `currency`, `country` and `timeout` -
a customer is waiting on the checkout, so honour it.

## Migrations

A module that declares `schemas` is picked up by `php laika app:migrate` with no
extra wiring — but only while it is enabled. Disabling a module does **not**
drop its tables; that is deliberate, because a module switched off for an
afternoon should not take a client's data with it.

## Assets

This directory is **not** web-servable, so a module shipping CSS, JS or images
must publish them into `assets/modules/<name>/` on activation.

What makes it unservable changed, and the difference matters. It used to be the
framework: `Dispatcher` held an allowlist of servable roots and `modules` was
not on it. As of laika-route v2.0.2 that allowlist is gone - the dispatcher now
denies only `lf-*`, `vendor` and `docs` and serves everything else, gated by the
extension list in `lf-config/assets.php`. So the framework would hand out a
module's files today.

What stops it is the web server:

- **Apache** - `modules/.htaccess`, `Require all denied`. That file used to be
  defence in depth. It is now the only thing standing between third-party module
  code and the web, so do not remove it.
- **nginx** - the shipped `nginx.conf` denies `modules/` for the same reason. If
  you wrote your own server block, add it:

  ```
  location ~ ^/modules(/|$) { deny all; }
  ```

This is why the publish-on-activation convention stays: a module is code an
operator dropped in, and it routinely carries gateway API keys and registrar
credentials in a file beside the manifest. `php` and `json` are refused
everywhere by extension, but `txt` and `csv` are not - a module shipping
`credentials.txt` would be readable without the deny above.

Templates work the other way round - `template/` *is* servable, so a template
keeps its assets inside itself at `template/<area>/<name>/assets/` and links
them from its own `partials/header.twig`. The two conventions differ because a
template is installed by copying one directory and is expected to be swapped at
runtime, while a module is third-party code that happens to ship a few files.
