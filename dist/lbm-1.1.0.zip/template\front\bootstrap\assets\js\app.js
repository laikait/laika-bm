/*
 * Laika Bill Manager - front / bootstrap
 *
 * The public site needs almost no JavaScript, and that is deliberate: these
 * pages are read once by a stranger, often on a phone on a bad connection, and
 * every kilobyte here is one they wait for before seeing anything.
 *
 * Bootstrap's own bundle is loaded ahead of this and handles anything it owns.
 * This file covers the one thing Bootstrap has no opinion about: the mobile nav
 * toggle, written against a plain class rather than Bootstrap's collapse so the
 * markup stays legible.
 */
(function () {
    'use strict';

    var toggle = document.querySelector('[data-lbm-nav]');
    var links = document.getElementById('lbm-nav-links');

    if (!toggle || !links) {
        return;
    }

    toggle.addEventListener('click', function () {
        links.classList.toggle('is-open');
    });

    // A tap on any link closes the menu. Without this the panel stays open over
    // the page it just navigated to, which reads as a broken link on a phone.
    links.addEventListener('click', function (e) {
        if (e.target.closest('a')) {
            links.classList.remove('is-open');
        }
    });
}());
