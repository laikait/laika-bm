<?php
/**
 * Laika Bill Manager — root template loader
 * Author: Showket Ahmed
 * Email: riyadhtayf@gmail.com
 * License: MIT
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');

####################################################################################
/*---------------------------------- EVERY AREA ----------------------------------*/
####################################################################################
//
// Laika\Core\App\Template requires this file once per instance, before it knows
// which template a view belongs to - so it runs for the admin panel, the client
// area and the installer alike, whatever template each is set to.
//
// That makes it the wrong place for anything visual. A stylesheet enqueued here
// would be forced on every template ever installed, including ones written to
// look nothing like these. Each template enqueues its own assets from its own
// loader.php:
//
//     template/admin/<name>/loader.php
//     template/panel/<name>/loader.php
//     template/install/loader.php
//
// Deliberately empty. Put something here only when it must hold for every
// template in every area - and expect a template author to be surprised by it.
