<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * A STARTER - copy it, do not switch it on.
 *
 * Copy this directory to modules/plugins/<YourPlugin>, rename the namespace
 * below and in every file under src/, routes/ and hooks/, and change the route's
 * path and name so two copies cannot collide.
 *
 * It shows the three things a plugin can ship beside its settings: a ROUTE
 * (routes/), a HOOK (hooks/), and a controller its route points at. Both
 * directories are declared under `resources`, and each is registered only while
 * the plugin is switched on.
 *
 * A declaration and nothing else: the loader reads this during autoload and the
 * modules screen reads it again. Hooks go in hooks/, never here.
 */

return [
    'name'        => 'Example Plugin',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'A starter to copy: a plugin with a route of its own, a hook that puts its settings '
        . 'page in the admin sidebar, and settings on its Configure page. Not a real feature.',

    'class'       => \Modules\Plugins\Example\Example::class,

    'namespace'   => 'Modules\Plugins\Example',
    'src'         => 'src',

    'resources'   => [
        'routes' => ['path' => 'routes'],
        'hooks'  => ['path' => 'hooks'],
    ],
];
