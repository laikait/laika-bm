<?php
/**
 * Laika Framework
 * Author: Showket Ahmed
 * Email: riyadhtayf@gmail.com
 * License: MIT
 * This file is part of the Laika Framework.
 * For the full copyright and license information, please view the LICENSE file that was distributed with this source code.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use LBM\Model\ClientModel;
use LBM\Model\StaffModel;
use LBM\Model\ClientContactModel;

/**
 * Authentication Guards.
 *
 * Read by Laika\Auth\AuthManager via config('auth'). This stays a config file
 * rather than moving into `options` because it maps guard names to PHP class
 * names - it is wiring, not a user-editable setting.
 *
 * Every guard uses the token driver: Laika\Auth\Guards\TokenGuard issues a
 * token into `auth_tokens` and validates it on each request. The `provider`
 * must be a model class exposing find($id) - the guard instantiates it and
 * loads the authenticated row through it.
 */
return [
    /** Admin Panel - staffs */
    'staff'     =>  ['driver' => 'token', 'provider' => StaffModel::class],

    /** Client Area - clients */
    'client'    =>  ['driver' => 'token', 'provider' => ClientModel::class],

    /** Client Area - client sub-logins */
    'contact'   =>  ['driver' => 'token', 'provider' => ClientContactModel::class],
];
