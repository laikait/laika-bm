<?php

declare(strict_types=1);

namespace Modules\Lookup\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use LBM\Module\Contracts\Configurable;
use LBM\Module\Contracts\LookupInterface;

/**
 * A STARTER: a domain availability lookup over a paid API.
 *
 * Copy this directory to modules/lookup/<YourProvider>, rename the namespace in
 * every file, put your provider's two addresses in src/Api.php, and change the
 * request available() makes. It ships switched off and points at reserved
 * example names. For one that needs no account, read modules/lookup/LaikaWhois.
 *
 * One verb, three answers: true free, false taken, and null COULD NOT SAY - a
 * timeout, a rate limit, an answer nobody recognises. Null is never a name
 * somebody has, and the product asks the TLD's registrar when it gets one. A
 * public search asks about every TLD on the price list inside one time budget,
 * so honour the `timeout` each call is given.
 */
class Example implements LookupInterface, Configurable
{
    /** @var array<string,mixed> What The Operator Saved, Opened, Plus `mode` */
    private array $settings;

    /**
     * @param array<string,mixed> $settings Built by the product: the fields
     *        declared in settings(), opened, and `mode` - live or test.
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
    }

    /**
     * The Fields The Operator Fills In On The Module's Configure Page
     *
     * A `password` field is a secret: sealed, never shown again, and a blank
     * box keeps what is saved. Only what is declared here is stored.
     * @return array
     */
    public static function settings(): array
    {
        return [
            'api_key' => [
                'label'    => 'API key',
                'type'     => 'password',
                'required' => true,
                'help'     => 'From your account with the lookup provider.',
            ],
        ];
    }

    /**
     * Answer The Test Connection Button
     *
     * One cheap call that is not a lookup - some providers charge per lookup.
     * The message is shown to the operator as it is.
     * @return array{success: bool, message: string}
     */
    public function test(): array
    {
        $reply = (new Api($this->settings))->call('GET', 'ping');

        return $reply['status'] === 200
            ? ['success' => true, 'message' => 'The API answered: ' . (string) ($reply['json']['message'] ?? 'OK')]
            : ['success' => false, 'message' => 'The API did not accept the key: ' . self::why($reply)];
    }

    /**
     * Can This Name Be Registered?
     *
     * `success` is about the call, `available` about the name, and a failed
     * call's `available` is never read. Anything but a boolean from the provider
     * is could-not-say.
     * @param string $domain The whole name, TLD included
     * @param array $context `timeout` - seconds left of the search - and `tld`
     * @return array
     */
    public function available(string $domain, array $context = []): array
    {
        $timeout = min(10.0, max(0.5, (float) ($context['timeout'] ?? 5.0)));
        $reply = (new Api($this->settings))->call('GET', 'domains/check', ['domain' => $domain], $timeout);
        $answer = $reply['json']['available'] ?? null;

        return $reply['status'] === 200 && is_bool($answer)
            ? ['success' => true, 'available' => $answer, 'message' => null, 'raw' => []]
            : ['success' => false, 'available' => null, 'message' => 'The provider could not say: ' . self::why($reply), 'raw' => []];
    }

    /**
     * Why a Call Did Not Work, In Words
     * @param array $reply What Api::call() returned
     * @return string
     */
    private static function why(array $reply): string
    {
        return (string) ($reply['json']['message'] ?? $reply['error'] ?? ('HTTP ' . $reply['status']));
    }
}
