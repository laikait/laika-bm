<?php

declare(strict_types=1);

namespace Modules\Plugins\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/**
 * The service this plugin talks to - both of its addresses, in code.
 *
 * Not every plugin calls anything. One that does keeps its addresses here, and
 * the operator chooses Live or Test on the plugin's configure page; the product
 * hands that choice to the plugin as `mode`. Leave `test` out if the service has
 * no sandbox, and test mode then refuses every call rather than touching live.
 *
 * request() never throws, never follows a redirect, caps its time and the size
 * of a reply, and logs nothing - see LBM\Module\Api.
 */
final class Api extends \LBM\Module\Api
{
    /**
     * Where The Service Is, For Each Mode
     * @return array{live: string, test: string}
     */
    protected function endpoints(): array
    {
        return [
            'live' => 'https://api.example.com/v1',
            'test' => 'https://sandbox.example.com/v1',
        ];
    }

    /**
     * One Call, With The Saved Key In The Header The Service Expects
     * @param string $method HTTP Method
     * @param string $path Relative To The Mode's Address
     * @param array $data A Query For GET, a JSON Body Otherwise
     * @param float $timeout Seconds
     * @return array{status: int, body: string, json: ?array, error: ?string}
     */
    public function call(string $method, string $path, array $data = [], float $timeout = 5.0): array
    {
        return $this->request($method, $path, $data, ['X-Api-Key' => (string) $this->setting('api_key', '')], $timeout);
    }
}
