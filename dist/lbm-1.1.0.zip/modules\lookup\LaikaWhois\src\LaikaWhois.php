<?php

declare(strict_types=1);

namespace Modules\Lookup\LaikaWhois;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use Throwable;
use LBM\Module\Contracts\LookupInterface;

/**
 * Asks a domain's registry, over WHOIS, whether a name is free.
 *
 * Plain WHOIS: a TCP connection to port 43, the name and a line break, and
 * whatever text comes back. It needs no account and no key, which is why it can
 * ship switched on - and why it is only ever asked, never trusted to register.
 *
 * ---------------------------------------------------------------------------
 * THREE ANSWERS, AND THE THIRD IS MOST OF THE WORK
 * ---------------------------------------------------------------------------
 * WHOIS has no standard format. Every registry writes its own prose, many rate
 * limit, and some answer in a sentence nobody could parse. So:
 *
 *   free    a status line that says free, or a "no match" phrase with no sign
 *           of a registration beside it
 *   taken   a registration record - a registrar, a creation date, a registry
 *           id - with no "no match" phrase beside it
 *   null    everything else: silence, a timeout, a rate-limit sentence, an
 *           answer carrying BOTH signs, an answer carrying neither
 *
 * A contradiction is null rather than a guess because a guess either way costs
 * somebody: "free" takes money for a name somebody owns, and "taken" offers to
 * transfer in a name that may not exist. Null costs nothing - the product asks
 * the registrar next, and failing that tells the visitor it will be checked.
 *
 * ---------------------------------------------------------------------------
 * BOUNDED IN TIME AND SIZE
 * ---------------------------------------------------------------------------
 * A public search asks about every TLD on the price list inside one budget,
 * and hands each call what is left of it as `timeout`. The smaller of that and
 * this module's own timeout is a hard deadline across connecting, the IANA
 * referral and reading. A reply is read to MAX_BYTES and no further: a WHOIS
 * record is a few kilobytes, and a server streaming a megabyte is not one.
 *
 * ---------------------------------------------------------------------------
 * WHICH SERVER
 * ---------------------------------------------------------------------------
 * A handful of common TLDs are known. Anything else is asked of IANA, whose
 * record for a TLD names its WHOIS server - once per TLD per process, because
 * a search asks about the same TLD for every label somebody types. Only a real
 * answer is remembered; an IANA that timed out is asked again next time.
 *
 * The name is checked BEFORE anything is sent. WHOIS is one line of text, so a
 * name carrying a line break is a second query smuggled onto somebody else's
 * server under this install's address.
 *
 * Constructed with no arguments by the product. The optional settings -
 * `servers` (tld => host[:port]), `iana` and `timeout` - exist for a module
 * that wraps this one, and for the walk that proves it against a scripted
 * server rather than the internet.
 */
class LaikaWhois implements LookupInterface
{
    /** @var array<string,string> Registries Known Without Asking IANA */
    public const SERVERS = [
        'com' => 'whois.verisign-grs.com',
        'net' => 'whois.verisign-grs.com',
        'org' => 'whois.publicinterestregistry.org',
        'uk'  => 'whois.nic.uk',
        'de'  => 'whois.denic.de',
    ];

    /** @var string Where An Unknown TLD's Server Is Looked Up */
    public const IANA = 'whois.iana.org';

    /** @var int The WHOIS Port */
    public const PORT = 43;

    /** @var float Seconds, When The Caller Gives No Shorter Time */
    public const TIMEOUT = 4.0;

    /** @var int The Most Of One Reply That Is Read */
    public const MAX_BYTES = 65536;

    /** DENIC and others: a status line that says it outright. */
    private const FREE_STATUS = '/^\s*status:\s*(free|available)\s*$/im';

    /** Signs of a registration. Line-anchored, so a disclaimer's prose does not count. */
    private const REGISTERED = '/^\s*(registry domain id|registrar|creation date|created|registered on|registration time|name servers?|nserver|domain status)\s*:'
        . '|^\s*domain name\s*:\s*\S'
        . '|^\s*status:\s*(connect|active|ok|registered)\b/im';

    /** @var string[] What Registries Say When Nobody Has The Name */
    private const NO_MATCH = [
        'no match for', 'not found', 'no data found', 'no entries found', 'no object found',
        'no matching record', 'the queried object does not exist', 'is available for registration',
        'nothing found', 'has not been registered',
    ];

    /** @var array<string,?string> IANA's Answer Per TLD, For This Process */
    private static array $referrals = [];

    /** @var array<string,string> */
    private array $servers;

    private string $iana;

    private float $timeout;

    public function __construct(array $settings = [])
    {
        $servers = [];

        foreach ((array) ($settings['servers'] ?? []) as $tld => $host) {
            $servers[ltrim(strtolower((string) $tld), '.')] = (string) $host;
        }

        $this->servers = $servers + self::SERVERS;
        $this->iana = (string) ($settings['iana'] ?? self::IANA);
        $this->timeout = (float) ($settings['timeout'] ?? self::TIMEOUT);
    }

    public function available(string $domain, array $context = []): array
    {
        $name = strtolower(trim($domain));

        if (!$this->askable($name)) {
            return $this->answer(false, null, 'That is not a name WHOIS can be asked about.');
        }

        $timeout = $this->timeout;
        $given = (float) ($context['timeout'] ?? 0);

        if ($given > 0) {
            $timeout = min($timeout, $given);
        }

        $deadline = microtime(true) + $timeout;
        $server = $this->serverFor($name, $deadline);

        if ($server === null) {
            return $this->answer(false, null, 'No WHOIS server is known for this TLD.');
        }

        $reply = $this->query($server, $name, $deadline);

        if ($reply === null) {
            return $this->answer(false, null, 'The WHOIS server did not answer in time.', ['server' => $server]);
        }

        $available = $this->interpret($reply);

        return $this->answer(
            true,
            $available,
            $available === null ? 'The WHOIS answer did not say either way.' : null,
            ['server' => $server, 'bytes' => strlen($reply)]
        );
    }

    /**
     * Read One Reply
     * @param string $reply What The Server Sent
     * @return ?bool
     */
    private function interpret(string $reply): ?bool
    {
        if (preg_match(self::FREE_STATUS, $reply)) {
            return true;
        }

        $lower = strtolower($reply);
        $noMatch = false;

        foreach (self::NO_MATCH as $phrase) {
            if (str_contains($lower, $phrase)) {
                $noMatch = true;
                break;
            }
        }

        if (preg_match(self::REGISTERED, $reply)) {
            return $noMatch ? null : false;
        }

        return $noMatch ? true : null;
    }

    /**
     * Whether a Name Is Safe To Send
     *
     * ASCII labels only - an internationalised name reaches a registry as
     * punycode, and anything else is either that mistake or a line break.
     * @param string $name Lowercased Name
     * @return bool
     */
    private function askable(string $name): bool
    {
        return (bool) preg_match(
            '/^(?=.{3,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/D',
            $name
        );
    }

    /**
     * The WHOIS Server For a Name
     *
     * Longest suffix first, so `co.uk` could be given its own server ahead of
     * `uk`'s; then IANA, asked about the last label.
     * @param string $name Lowercased Name
     * @param float $deadline microtime() Deadline
     * @return ?string host[:port]
     */
    private function serverFor(string $name, float $deadline): ?string
    {
        $labels = array_slice(explode('.', $name), 1);

        for ($i = 0; $i < count($labels); $i++) {
            $suffix = implode('.', array_slice($labels, $i));

            if (isset($this->servers[$suffix])) {
                return $this->servers[$suffix];
            }
        }

        $tld = (string) end($labels);

        if (array_key_exists($tld, self::$referrals)) {
            return self::$referrals[$tld];
        }

        $reply = $this->query($this->iana, $tld, $deadline);

        if ($reply === null) {
            return null;
        }

        $server = null;

        if (preg_match('/^\s*(?:whois|refer):\s*([a-z0-9.\-]+(?::\d{1,5})?)\s*$/im', $reply, $m)) {
            $server = $m[1];
        }

        return self::$referrals[$tld] = $server;
    }

    /**
     * One WHOIS Query, Inside The Deadline
     *
     * Null for every way of not getting a whole answer: no connection, a
     * timeout, a read that failed. A reply cut off by the deadline is not a
     * reply - half a record can look like no record.
     * @param string $server host[:port]
     * @param string $query What To Ask
     * @param float $deadline microtime() Deadline
     * @return ?string
     */
    private function query(string $server, string $query, float $deadline): ?string
    {
        [$host, $port] = $this->hostPort($server);

        $left = $deadline - microtime(true);

        if ($left <= 0) {
            return null;
        }

        // try/catch, never `@`: inside the application every warning is
        // promoted to an exception, and a refused connection is a warning.
        try {
            $socket = stream_socket_client("tcp://{$host}:{$port}", $errno, $errstr, $left);
        } catch (Throwable) {
            return null;
        }

        if (!is_resource($socket)) {
            return null;
        }

        try {
            $this->wait($socket, $deadline);
            fwrite($socket, $query . "\r\n");

            $reply = '';

            while (!feof($socket)) {
                if (microtime(true) >= $deadline) {
                    return null;
                }

                $this->wait($socket, $deadline);
                $chunk = fread($socket, 8192);

                if ($chunk === false) {
                    return null;
                }

                if ($chunk === '') {
                    if (stream_get_meta_data($socket)['timed_out']) {
                        return null;
                    }

                    continue;
                }

                $reply .= $chunk;

                if (strlen($reply) >= self::MAX_BYTES) {
                    return substr($reply, 0, self::MAX_BYTES);
                }
            }

            return $reply;
        } catch (Throwable) {
            return null;
        } finally {
            fclose($socket);
        }
    }

    /**
     * Let The Next Read Wait No Longer Than The Deadline
     * @param resource $socket
     * @param float $deadline microtime() Deadline
     * @return void
     */
    private function wait($socket, float $deadline): void
    {
        $left = max(0.001, $deadline - microtime(true));
        $seconds = (int) floor($left);

        stream_set_timeout($socket, $seconds, (int) (($left - $seconds) * 1000000));
    }

    /**
     * @param string $server host Or host:port
     * @return array{0:string,1:int}
     */
    private function hostPort(string $server): array
    {
        $parts = explode(':', $server);

        if (count($parts) === 2 && ctype_digit($parts[1])) {
            return [$parts[0], (int) $parts[1]];
        }

        return [$server, self::PORT];
    }

    private function answer(bool $success, ?bool $available, ?string $message, array $raw = []): array
    {
        return ['success' => $success, 'available' => $available, 'message' => $message, 'raw' => $raw];
    }
}
