<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use Laika\Service\Nav;
use Modules\Plugins\Example\Example;

/*
 * The plugin's hooks. Loaded once per request, and only while it is switched on.
 *
 * nav_extend('admin', ...) is how a module adds to a menu. Not Nav::extend():
 * the menu builder is flushed before each menu is built, which would drop an
 * entry added earlier; nav_extend() runs the callback at the moment the admin
 * sidebar is being built, so the entry lands in it.
 *
 * Nav::add() with a literal title rather than nav_item(): nav_item() takes a
 * LANGUAGE KEY, and a module cannot add keys to the product's catalogue - a
 * missing key throws. The route here is the plugin's own Configure page.
 */
if (function_exists('nav_extend')) {
    nav_extend('admin', static function (): void {
        // A query on every admin page. Fine for a starter; a plugin with more
        // than one hook should read its settings once and keep them.
        $settings = Example::current();

        if (($settings['show_in_menu'] ?? 'no') !== 'yes') {
            return;
        }

        Nav::add('Example plugin', 'staff.module.configure', ['module' => Example::uid()], staff_has_access('module.read'))
            ->name('example_plugin');
    });
}
