<?php
/**
 * Laika Framework
 * Author: Showket Ahmed
 * Email: riyadhtayf@gmail.com
 * License: MIT
 * This file is part of the Laika Framework.
 * For the full copyright and license information, please view the LICENSE file that was distributed with this source code.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/**
 * Mail Defaults — SEED SOURCE ONLY.
 *
 * The running application never reads this file. Mail settings live in the
 * `options` table and are read on demand with option() / option_int() /
 * option_bool() under the `mail_` prefix.
 *
 * The installer reads these values once and writes them into `options`, so a
 * deployer can pre-fill SMTP credentials here before running the wizard.
 * After that, change settings in Admin -> Settings -> Mail.
 *
 * Every key below maps 1:1 onto Laika\Mailman\Mailer::__construct().
 */
return [
    /** Transport: smtp | sendmail | mail | qmail */
    'driver'        =>  'smtp',

    /** SMTP Host */
    'host'          =>  'localhost',

    /** SMTP Port. 587 = STARTTLS, 465 = implicit TLS */
    'port'          =>  587,

    /** SMTP Username. Leave empty to disable SMTP auth */
    'username'      =>  '',

    /** SMTP Password */
    'password'      =>  '',

    /** Encryption: tls | ssl | '' (none). Use 'ssl' with port 465 */
    'encryption'    =>  'tls',

    /** From Address */
    'from'          =>  '',

    /** From Name */
    'from_name'     =>  '',

    /** Character Set */
    'charset'       =>  'UTF-8',

    /** SMTP Timeout in Seconds */
    'timeout'       =>  30,

    /** SMTP Debug Level: 0 (off) to 4 (verbose) */
    'debug'         =>  0,

    /** Keep the SMTP Connection Open Across Messages */
    'keepalive'     =>  false,

    /** Opportunistic STARTTLS When the Server Advertises It */
    'auto_tls'      =>  true,

    /** Verify the Server's TLS Certificate. Never disable in production */
    'validate_cert' =>  true,
];
