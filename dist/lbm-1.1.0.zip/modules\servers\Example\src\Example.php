<?php

declare(strict_types=1);

namespace Modules\Servers\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use LBM\Module\Contracts\Configurable;
use LBM\Module\Contracts\ServerInterface;

/**
 * A STARTER: a provisioning module for a control panel with an HTTP API.
 *
 * Copy this directory to modules/servers/<YourControlPanel>, rename the namespace
 * in every file, and change the paths and fields each verb sends. It ships
 * switched off.
 *
 * Its settings are PER PRODUCT - here, the package an account is created on -
 * and the operator fills them in on each product's form. The connection is the
 * server row in every call's context: its address and access key. Four verbs,
 * the lifecycle of a service:
 *
 *   create     makes the account and returns its username and password, which
 *              the product stores encrypted. Never write or log them yourself.
 *   suspend    switches it off WITHOUT destroying it - it must come back.
 *   unsuspend  switches it back on.
 *   terminate  destroys it, and refuses anything that looks like a mistake.
 *
 * These run from cron, not from a web request: nothing may assume a session,
 * and any of them may be retried.
 */
class Example implements ServerInterface, Configurable
{
    /** @var array<string,mixed> The Product's Fields, Opened, Plus `mode` - Always Live */
    private array $settings;

    /**
     * @param array<string,mixed> $settings Built by the product from the
     *        product's module fields, opened, plus `mode`.
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
    }

    /**
     * The Fields The Operator Fills In On Each Product's Form
     *
     * Per product, because a package or a plan belongs to what was sold. The
     * server's own address and credentials are on the servers screen, not here.
     * @return array
     */
    public static function settings(): array
    {
        return [
            'package' => [
                'label'    => 'Package',
                'type'     => 'text',
                'required' => true,
                'help'     => 'The package on the control panel that accounts for this product are created on.',
            ],
        ];
    }

    /**
     * Answer The Test Connection Button
     *
     * A server module has nothing to test from a product: its connection is a
     * server, and the servers screen checks that the server answers. Say so,
     * rather than reporting a success nothing was asked about.
     * @return array{success: bool, message: string}
     */
    public function test(): array
    {
        return [
            'success' => false,
            'message' => 'A server module is tested against a server: use Check on the servers screen.',
        ];
    }

    /**
     * Create The Account
     *
     * Retried jobs call this again, so an account that already exists is a
     * success rather than a duplicate. The password comes back in the clear for
     * the product to encrypt - never keep it anywhere else.
     * @param array $service The `client_services` row
     * @param array $context See ServerInterface::create()
     * @return array
     */
    public function create(array $service, array $context = []): array
    {
        $existing = trim((string) ($service['username'] ?? ''));

        if ($existing !== '') {
            return ['success' => true, 'username' => $existing, 'password' => null, 'message' => 'The account already exists.', 'raw' => []];
        }

        $reply = $this->api($context)->call('POST', 'accounts', [
            'domain'  => (string) ($service['domain'] ?? ''),
            'package' => (string) ($this->settings['package'] ?? ''),
        ]);

        $username = (string) ($reply['json']['username'] ?? '');

        if (in_array($reply['status'], [200, 201], true) && $username !== '') {
            return [
                'success'  => true,
                'username' => $username,
                'password' => (string) ($reply['json']['password'] ?? '') ?: null,
                'message'  => 'Account created.',
                'raw'      => ['username' => $username],
            ];
        }

        return ['success' => false, 'username' => null, 'password' => null, 'message' => 'The panel did not create it: ' . self::why($reply), 'raw' => []];
    }

    /**
     * Switch The Account Off, Keeping Everything On It
     *
     * The reason is shown to the customer, so it is written for them.
     * @param array $service The `client_services` row
     * @param string $reason Why
     * @param array $context See create()
     * @return array
     */
    public function suspend(array $service, string $reason = '', array $context = []): array
    {
        return $this->act($service, $context, 'POST', 'suspend', ['reason' => $reason]);
    }

    /**
     * Switch The Account Back On, Exactly As It Was
     *
     * Called when the invoice behind a suspension is paid, or by staff.
     * @param array $service The `client_services` row
     * @param array $context See create()
     * @return array
     */
    public function unsuspend(array $service, array $context = []): array
    {
        return $this->act($service, $context, 'POST', 'unsuspend');
    }

    /**
     * Destroy The Account - The One Verb That Cannot Be Undone
     *
     * The product has its own guard in front of this. Keep one here too: with
     * no account name there is nothing to aim at, and a call to the collection
     * is the kind of mistake that deletes the wrong thing.
     * @param array $service The `client_services` row
     * @param array $context See create()
     * @return array
     */
    public function terminate(array $service, array $context = []): array
    {
        return $this->act($service, $context, 'DELETE', '');
    }

    /**
     * One Verb On One Account
     * @param array $service
     * @param array $context
     * @param string $method
     * @param string $verb Path Below The Account, Or '' For The Account Itself
     * @param array $data
     * @return array{success: bool, message: ?string, raw: array}
     */
    private function act(array $service, array $context, string $method, string $verb, array $data = []): array
    {
        $username = trim((string) ($service['username'] ?? ''));

        if ($username === '') {
            return ['success' => false, 'message' => 'This service has no account name, so there is nothing to act on.', 'raw' => []];
        }

        $path = 'accounts/' . rawurlencode($username) . ($verb === '' ? '' : '/' . $verb);
        $reply = $this->api($context)->call($method, $path, $data);

        return $reply['status'] === 200
            ? ['success' => true, 'message' => null, 'raw' => []]
            : ['success' => false, 'message' => 'The panel refused: ' . self::why($reply), 'raw' => []];
    }

    /**
     * The API For The Server In This Call's Context
     * @param array $context
     * @return Api
     */
    private function api(array $context): Api
    {
        return new Api($this->settings, is_array($context['server'] ?? null) ? $context['server'] : []);
    }

    /**
     * Why a Call Did Not Work, In Words
     * @param array $reply What Api::call() returned
     * @return string
     */
    private static function why(array $reply): string
    {
        return (string) ($reply['json']['message'] ?? $reply['error'] ?? ('HTTP ' . $reply['status']));
    }
}
