<?php
/**
 * Laika Framework
 * Author: Showket Ahmed
 * Email: riyadhtayf@gmail.com
 * License: MIT
 * This file is part of the Laika Framework.
 * For the full copyright and license information, please view the LICENSE file that was distributed with this source code.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

// // Start Register API Http From Here
// // ###### Sample: #######
// // Url::get('/sample', 'SampleController@index');
// // ##### With Middleware #####
// // Url::get('/sample', 'SampleController@index', [CBM\App\Middleware\SampleMiddleware::class]);
// // ##### Post Request #####
// // Url::post('/sample', 'SampleController@index');

// The framework skeleton shipped a live `GET /status` here, answering
// {"status":"API is Working With Put Method"} to anybody who asked. Sample text
// on a public route, on a billing application, reachable without a session.
//
// Removed rather than merely excluded from the release build, so that a dev
// checkout and a shipped zip answer identically - a route that exists in one and
// not the other is a difference a bug can hide in.
//
// The REST API is a phase of its own and will reuse TokenGuard with a Bearer
// header. Nothing belongs in this file until then.