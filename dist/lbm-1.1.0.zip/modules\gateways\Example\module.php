<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * A STARTER - copy it, do not switch it on.
 *
 * Copy this directory to modules/gateways/<YourProvider>, rename the namespace
 * below and in every file under src/, and put your provider's two addresses in
 * src/Api.php. It points at api.example.com and sandbox.example.com, which never
 * answer, so switched on as it is it can take no payment.
 *
 * A declaration and nothing else: the loader reads this during autoload and the
 * modules screen reads it again.
 */

return [
    'name'        => 'Example Gateway',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'A starter to copy: a gateway that takes payment on the provider\'s hosted page, '
        . 'confirms it by a signed webhook, and refunds through the API. Not a real provider.',

    'class'       => \Modules\Gateways\Example\Example::class,

    'namespace'   => 'Modules\Gateways\Example',
    'src'         => 'src',
];
