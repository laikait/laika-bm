<?php

declare(strict_types=1);

namespace Modules\Gateways\Offline;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use LBM\Module\Contracts\Configurable;
use LBM\Module\Contracts\GatewayInterface;

/**
 * Payment that happens somewhere else - a bank transfer, a cheque, cash.
 *
 * ------------------------------------------------------------------------
 * This gateway never marks an invoice paid, and that is the whole point
 * ------------------------------------------------------------------------
 * charge() returns `pending`, never `success`. The money has not arrived; all
 * that has happened is that a customer said they intend to send it. An invoice
 * settled on a customer's say-so is the one mistake a billing system is not
 * allowed to make, and no amount of convenience is worth it.
 *
 * What actually settles the invoice is a member of staff recording the payment
 * once it lands, through the normal admin flow - which writes the same
 * `transactions` row any other payment would.
 *
 * So there is no API here, no keys, and nothing to mock. That is deliberate: it
 * makes this the driver that proves the gateway seam works end to end, without
 * a network call or a sandbox account anywhere in the test.
 *
 * ------------------------------------------------------------------------
 * The settings are instructions, not credentials
 * ------------------------------------------------------------------------
 * `instructions` is shown to the customer verbatim on the invoice. It is
 * operator-authored text - bank name, account number, what reference to quote -
 * and it is the only configuration this gateway has.
 *
 * Since Phase 40 it DECLARES that field, so the gateways screen draws it from
 * here rather than drawing an instructions box for every gateway on the
 * install whether it wanted one or not.
 */
class Offline implements GatewayInterface, Configurable
{
    /**
     * What The Operator Fills In
     * @return array
     */
    public static function settings(): array
    {
        return [
            'instructions' => [
                'label' => 'Payment instructions',
                'type'  => 'textarea',
                'help'  => 'Shown to the customer on the invoice, as written: the bank, the account, and the reference to quote.',
            ],
        ];
    }

    /**
     * There Is Nothing To Connect To
     * @return array{success: bool, message: string}
     */
    public function test(): array
    {
        return [
            'success' =>  true,
            'message' =>  'The offline gateway has nothing to connect to: it shows your instructions and waits for you to record the payment.',
        ];
    }

    /** @var array<string,mixed> Whatever the operator saved on the gateways screen */
    private array $settings;

    /**
     * @param array<string,mixed> $settings
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
    }

    /**
     * Tell The Customer How To Pay
     *
     * Always pending, never successful. See the class docblock.
     *
     * @param array $payment
     * @return array
     */
    public function charge(array $payment): array
    {
        $instructions = trim((string) ($this->settings['instructions'] ?? ''));

        return [
            'success'   =>  false,
            'reference' =>  null,
            'amount'    =>  (string) ($payment['amount'] ?? '0'),
            'fee'       =>  null,
            'redirect'  =>  null,

            // Pending, not failed. The caller records the customer's intent and
            // leaves the invoice unpaid; a failure would suggest something went
            // wrong, and nothing has.
            'pending'   =>  true,
            'message'   =>  $instructions !== ''
                ? $instructions
                : 'Contact us for payment details.',
            'raw'       =>  [],
        ];
    }

    /**
     * There Is Nothing To Refund Through This Gateway
     *
     * The money never came through here, so it cannot go back through here. An
     * operator refunds a bank transfer at their bank, and records it in the
     * admin afterwards. Saying so plainly beats returning success and doing
     * nothing.
     *
     * @param string $reference
     * @param string $amount
     * @param string $reason
     * @return array
     */
    public function refund(string $reference, string $amount, string $reason = ''): array
    {
        return [
            'success'   =>  false,
            'reference' =>  null,
            'amount'    =>  null,
            'message'   =>  'An offline payment has to be refunded the same way it was taken, '
                . 'then recorded here by hand.',
            'raw'       =>  [],
        ];
    }

    /**
     * Nothing Calls Back
     *
     * There is no remote system, so anything arriving on this route came from
     * somebody who should not be sending it. `verified => false` is the honest
     * and the safe answer: the contract says an unverified callback must never
     * be treated as an instruction to mark an invoice paid.
     *
     * @param array $payload
     * @param array $headers
     * @return array
     */
    public function webhook(array $payload, array $headers = []): array
    {
        return [
            'verified'   =>  false,
            'event'      =>  null,
            'reference'  =>  null,
            'invoice_id' =>  null,
            'amount'     =>  null,
            'success'    =>  false,
            'message'    =>  'The offline gateway has no callback.',
            'raw'        =>  [],
        ];
    }
}
