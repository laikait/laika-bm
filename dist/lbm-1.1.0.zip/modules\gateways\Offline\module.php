<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * Bank transfer, and anything else settled away from this application.
 *
 * A declaration and nothing else. The loader reads this during autoload and the
 * modules screen reads it again to list what is installed, so anything that
 * registers a hook or opens a connection here happens twice.
 */

return [
    'name'        => 'Offline Payment',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'Bank transfer and other payments settled outside the application. '
        . 'Shows the customer how to pay; the invoice stays unpaid until a member of staff records the money arriving.',

    'class'       => \Modules\Gateways\Offline\Offline::class,

    'namespace'   => 'Modules\Gateways\Offline',
    'src'         => 'src',
];
