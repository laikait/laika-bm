<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * A STARTER - copy it, do not switch it on.
 *
 * Copy this directory to modules/lookup/<YourProvider>, rename the namespace
 * below and in every file under src/, and put your provider's two addresses in
 * src/Api.php. For a lookup that needs no account at all, read
 * modules/lookup/LaikaWhois instead.
 *
 * A declaration and nothing else: the loader reads this during autoload and the
 * modules screen reads it again.
 */

return [
    'name'        => 'Example Lookup',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'A starter to copy: a domain availability lookup over a paid JSON API, with a key '
        . 'and a sandbox. Not a real provider.',

    'class'       => \Modules\Lookup\Example\Example::class,

    'namespace'   => 'Modules\Lookup\Example',
    'src'         => 'src',
];
