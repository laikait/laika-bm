<?php

declare(strict_types=1);

namespace Modules\Gateways\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use LBM\Module\Contracts\Configurable;
use LBM\Module\Contracts\GatewayInterface;

/**
 * A STARTER: a payment gateway that takes payment on its own hosted page.
 *
 * Copy this directory to modules/gateways/<YourProvider>, rename the namespace
 * in every file, put your provider's two addresses in src/Api.php, and change
 * what each method sends. It ships switched off and points at reserved example
 * names, so it can do nothing until you have done that.
 *
 * It shows the REDIRECT shape, the one that uses all three verbs:
 *
 *   charge()  asks the provider for a hosted payment page and sends the
 *             customer there. Nothing is paid yet, so it answers `pending`.
 *   webhook() is the provider saying the payment went through. It is believed
 *             only when its signature checks out against the saved secret.
 *   refund()  gives money back through the provider, and says what it did.
 *
 * Nothing here writes to the database. The product records what a gateway
 * reports, through LBM\Action\Transaction, and nowhere else. Amounts are decimal
 * strings from start to finish - never floats.
 */
class Example implements GatewayInterface, Configurable
{
    /** @var string The Header The Provider Signs Its Callbacks In */
    private const SIGNATURE = 'x-example-signature';

    /** @var array<string,mixed> What The Operator Saved, Opened, Plus `mode` */
    private array $settings;

    /**
     * @param array<string,mixed> $settings Built by the product: the fields
     *        declared in settings(), opened, and `mode` - live or test.
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
    }

    /**
     * The Fields The Operator Fills In On The Gateways Screen
     *
     * The screen is drawn from this. A `password` field is a secret: sealed
     * before it is stored, never shown again, and a blank box keeps what is
     * saved. Only what is declared here is stored.
     * @return array
     */
    public static function settings(): array
    {
        return [
            'api_key' => [
                'label'    => 'API key',
                'type'     => 'password',
                'required' => true,
                'help'     => 'From your account with the provider. Use its sandbox key while this gateway is in test mode.',
            ],
            'webhook_secret' => [
                'label'    => 'Webhook signing secret',
                'type'     => 'password',
                'required' => true,
                'help'     => 'The provider signs every callback with this. A callback that does not verify is refused.',
            ],
        ];
    }

    /**
     * Answer The Test Connection Button
     *
     * One cheap, harmless call, in the saved mode with the saved key. The
     * message is shown to the operator as it is, so it says what happened in
     * words they can act on.
     * @return array{success: bool, message: string}
     */
    public function test(): array
    {
        $reply = (new Api($this->settings))->call('GET', 'ping', [], 5.0);

        return $reply['status'] === 200
            ? ['success' => true, 'message' => 'The API answered: ' . (string) ($reply['json']['message'] ?? 'OK')]
            : ['success' => false, 'message' => 'The API did not accept the key: ' . self::why($reply)];
    }

    /**
     * Start a Payment On The Provider's Hosted Page
     *
     * RETURN `success` FALSE WITH `pending` TRUE. Nothing has been paid yet; the
     * webhook says when something is. The product reads `pending: true` as "no
     * money has moved" whatever `success` says - GatewayInterface states the
     * rule - but `success: false` is the answer nobody reading your code can
     * misread. Never report money you have not taken.
     *
     * The amount is the invoice's balance, handed over by the product. Never
     * take one from the request.
     * @param array $payment See GatewayInterface::charge()
     * @return array
     */
    public function charge(array $payment): array
    {
        $reply = (new Api($this->settings))->call('POST', 'payments', [
            'amount'      => (string) ($payment['amount'] ?? '0'),
            'currency'    => (string) ($payment['currency'] ?? ''),
            'reference'   => (string) ($payment['invoice_id'] ?? ''),
            'description' => (string) ($payment['description'] ?? ''),
            'return_url'  => (string) ($payment['return_url'] ?? ''),
        ]);

        $page = (string) ($reply['json']['checkout_url'] ?? '');

        if (in_array($reply['status'], [200, 201], true) && $page !== '') {
            return [
                'success'   => false,
                'reference' => (string) ($reply['json']['id'] ?? '') ?: null,
                'amount'    => (string) ($payment['amount'] ?? '0'),
                'fee'       => null,
                'redirect'  => $page,
                'pending'   => true,
                'message'   => null,
                'raw'       => ['payment' => $reply['json']['id'] ?? null],
            ];
        }

        return [
            'success'   => false,
            'reference' => null,
            'amount'    => null,
            'fee'       => null,
            'redirect'  => null,
            'pending'   => false,
            'message'   => 'The payment could not be started: ' . self::why($reply),
            'raw'       => [],
        ];
    }

    /**
     * Give Money Back Through The Provider
     *
     * Report what the PROVIDER says it refunded, not what was asked for - a
     * provider that refunds part of a request is real, and the ledger has to
     * agree with the statement.
     * @param string $reference The provider's id for the original payment
     * @param string $amount Decimal string
     * @param string $reason Why, for the provider's records
     * @return array
     */
    public function refund(string $reference, string $amount, string $reason = ''): array
    {
        $reply = (new Api($this->settings))->call('POST', 'refunds', [
            'payment' => $reference,
            'amount'  => $amount,
            'reason'  => $reason,
        ]);

        if (in_array($reply['status'], [200, 201], true) && (string) ($reply['json']['id'] ?? '') !== '') {
            return [
                'success'   => true,
                'reference' => (string) $reply['json']['id'],
                'amount'    => (string) ($reply['json']['amount'] ?? $amount),
                'message'   => null,
                'raw'       => ['refund' => $reply['json']['id']],
            ];
        }

        return [
            'success'   => false,
            'reference' => null,
            'amount'    => null,
            'message'   => 'The provider did not refund it: ' . self::why($reply),
            'raw'       => [],
        ];
    }

    /**
     * Read a Callback From The Provider - Only When Its Signature Verifies
     *
     * The signature is an HMAC over the RAW body, which the product passes as
     * `__raw`: re-encoding the decoded payload changes its bytes and the
     * signature never matches. hash_equals(), never ==, so the comparison takes
     * the same time however much of a forgery is right.
     *
     * Anything unverified answers `verified: false` and nothing else. An
     * unverified callback is a stranger asking for an invoice to be marked paid.
     *
     * The reference is the PAYMENT, so the same payment reported twice - by a
     * retry, or by two events - is applied once.
     * @param array $payload Decoded body, plus `__raw`
     * @param array $headers Request headers
     * @return array
     */
    public function webhook(array $payload, array $headers = []): array
    {
        $refused = [
            'verified'   => false,
            'event'      => null,
            'reference'  => null,
            'invoice_id' => null,
            'amount'     => null,
            'success'    => false,
            'message'    => 'The callback signature did not verify.',
            'raw'        => [],
        ];

        $secret = (string) ($this->settings['webhook_secret'] ?? '');
        $raw = (string) ($payload['__raw'] ?? '');
        $sent = self::header($headers, self::SIGNATURE);

        if ($secret === '' || $raw === '' || $sent === '' || !hash_equals('sha256=' . hash_hmac('sha256', $raw, $secret), $sent)) {
            return $refused;
        }

        $data = is_array($payload['data'] ?? null) ? $payload['data'] : [];
        $type = (string) ($payload['type'] ?? '');

        return [
            'verified'   => true,
            'event'      => $type,
            'reference'  => (string) ($data['payment'] ?? '') ?: null,
            'invoice_id' => (int) ($data['invoice'] ?? 0) ?: null,
            'amount'     => isset($data['amount']) ? (string) $data['amount'] : null,
            'success'    => $type === 'payment.succeeded',
            'message'    => $type === 'payment.succeeded' ? null : 'The provider reported ' . $type . '.',
            'raw'        => ['event' => $payload['id'] ?? null],
        ];
    }

    /**
     * One Request Header, Whatever Case Or Form It Arrived In
     * @param array $headers
     * @param string $name Lower Case, With Dashes
     * @return string
     */
    private static function header(array $headers, string $name): string
    {
        foreach ($headers as $key => $value) {
            $key = strtolower(str_replace('_', '-', (string) preg_replace('/^HTTP_/i', '', (string) $key)));

            if ($key === $name) {
                return trim((string) (is_array($value) ? reset($value) : $value));
            }
        }

        return '';
    }

    /**
     * Why a Call Did Not Work, In Words
     * @param array $reply What Api::call() returned
     * @return string
     */
    private static function why(array $reply): string
    {
        return (string) ($reply['json']['message'] ?? $reply['error'] ?? ('HTTP ' . $reply['status']));
    }
}
