<?php

declare(strict_types=1);

namespace Modules\Servers\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/**
 * The control panel's API, on the server the operator typed in.
 *
 * A server module is the one kind whose address is NOT in its code: every call
 * is made to a particular server, and the servers screen holds its hostname,
 * port, whether it uses SSL, and its credentials. So endpoints() builds the one
 * address from that row, and there is no test address - a server module is
 * always live, because there is no sandbox of somebody's server.
 *
 * The credential is read through LBM\Action\Server::credential(), the only way
 * out of the encrypted columns. Never log it.
 */
final class Api extends \LBM\Module\Api
{
    /**
     * @param array $settings What the driver was given
     * @param array $server The `servers` row this call is for
     */
    public function __construct(array $settings, private array $server)
    {
        parent::__construct($settings);
    }

    /**
     * The Server's Address - Live Only
     * @return array{live?: string}
     */
    protected function endpoints(): array
    {
        $host = trim((string) ($this->server['hostname'] ?? '')) ?: trim((string) ($this->server['ip_address'] ?? ''));

        if ($host === '') {
            return [];
        }

        $scheme = (string) ($this->server['use_ssl'] ?? 'yes') === 'no' ? 'http' : 'https';
        $port = (int) ($this->server['port'] ?? 0);

        return ['live' => $scheme . '://' . $host . ($port > 0 ? ':' . $port : '') . '/api/v1'];
    }

    /**
     * One Call, Authenticated With The Server's Access Key
     * @param string $method HTTP Method
     * @param string $path Relative To The Server's Address
     * @param array $data A Query For GET, a JSON Body Otherwise
     * @return array{status: int, body: string, json: ?array, error: ?string}
     */
    public function call(string $method, string $path, array $data = []): array
    {
        $key = (string) ((new \LBM\Action\Server())->credential($this->server, 'access_key') ?? '');

        return $this->request($method, $path, $data, ['X-Api-Key' => $key], 20.0);
    }
}
