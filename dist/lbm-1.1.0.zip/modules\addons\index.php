<?php
// Deny Direct Access
http_response_code(403);
die('403 Direct Access Denied!');
