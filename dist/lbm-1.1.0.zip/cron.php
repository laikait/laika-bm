<?php
// Run it from cron, once every five minutes. On Linux:
//
//     */5 * * * * /usr/bin/php /path/to/cloud/cron.php >/dev/null
//
// On Windows, as a Scheduled Task running:
//
//     php.exe C:\path\to\cloud\cron.php
//
// (Those examples are line comments rather than part of the block below on
// purpose: a crontab schedule contains */5, which would close it.)

/**
 * Laika Bill Manager - scheduled tasks.
 *
 * Nothing in this application raises an invoice, sends a reminder or delivers a
 * queued email without it. An install with no cron task looks like it is
 * working right up until the first renewal is due.
 *
 * ------------------------------------------------------------------------
 * It will not run over HTTP, and that is deliberate
 * ------------------------------------------------------------------------
 * Three independent layers keep it off the web, and the third exists precisely
 * because the first two are configuration:
 *
 *   1. .htaccess rewrites every request to index.php - the !-f condition is
 *      commented out, so a real file is never executed directly.
 *   2. The dispatcher then sees a .php extension, which lf-config/assets.php
 *      lists as blocked, and answers 404.
 *   3. This file refuses to run outside the CLI at all.
 *
 * An operator who fixes an unrelated rewrite problem, or a host that ignores
 * .htaccess entirely, must not thereby publish an unauthenticated endpoint that
 * sends mail and raises invoices. The guard is the first statement in the file
 * so that it holds even if something later in the boot sequence fails.
 *
 * The work itself lives in LBM\Support\Cron, inside the package, so it is
 * versioned with the product. This file is a shim and should stay one.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit(1);
}

require_once __DIR__ . '/lf-boot/app.php';

use Laika\Service\Init;
use LBM\Pipeline\Install;
use LBM\Support\Clock;
use LBM\Support\Cron;

// Before the wizard has been through, there is no database to connect to and
// no options to read. Saying so beats a connection error in a cron mail.
if (!Install::isInstalled()) {
    fwrite(STDERR, "This installation has not been completed yet. Open it in a browser and finish the installer first.\n");
    exit(1);
}

Init::db();

// No pipeline runs here, so nothing has put this process on the operator's
// timezone - and "once a day" has to mean their day, not the server's.
Clock::apply(true);

exit((new Cron())->run());
