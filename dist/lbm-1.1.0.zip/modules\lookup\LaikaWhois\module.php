<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * Laika Whois - asks a domain's registry whether a name is free.
 *
 * A declaration and nothing else. The loader reads this during autoload and the
 * modules screen reads it again to list what is installed, so anything that
 * opens a connection here would query a registry twice on every page.
 */

return [
    'name'        => 'Laika Whois',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'Answers "is this domain free?" with a WHOIS query to the registry, so a domain search '
        . 'works without a registrar module. It only reads: it registers nothing and holds no credential.',

    'class'       => \Modules\Lookup\LaikaWhois\LaikaWhois::class,

    'namespace'   => 'Modules\Lookup\LaikaWhois',
    'src'         => 'src',
];
