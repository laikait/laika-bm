<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use Laika\Route\Url;
use Modules\Plugins\Example\Controller\ExampleController;

/*
 * The plugin's routes. Registered only while the plugin is switched on: off,
 * this file is never read and the path answers 404.
 *
 * Change the path AND the name when you copy it. Route matching is first match
 * wins in registration order, so two plugins claiming one path means the second
 * never answers - and says nothing about it.
 */
Url::get('/example-plugin', [ExampleController::class, 'show'])->name('plugin.example');
