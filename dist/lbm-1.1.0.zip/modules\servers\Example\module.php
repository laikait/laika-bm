<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * A STARTER - copy it, do not switch it on.
 *
 * Copy this directory to modules/servers/<YourControlPanel>, rename the
 * namespace below and in every file under src/, and change what each verb sends.
 * A server module talks to the SERVER the operator typed in on the servers
 * screen, so there are no addresses to change - only the paths.
 *
 * A declaration and nothing else: the loader reads this during autoload and the
 * modules screen reads it again.
 */

return [
    'name'        => 'Example Server',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'A starter to copy: a provisioning module that creates, suspends, unsuspends and '
        . 'terminates accounts on a control panel\'s API, with a package chosen per product. Not a real panel.',

    'class'       => \Modules\Servers\Example\Example::class,

    'namespace'   => 'Modules\Servers\Example',
    'src'         => 'src',
];
