<?php

declare(strict_types=1);

namespace Modules\Fraud\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use LBM\Module\Contracts\Configurable;
use LBM\Module\Contracts\FraudInterface;

/**
 * A STARTER: screening an order at checkout through a scoring service.
 *
 * Copy this directory to modules/fraud/<YourService>, rename the namespace in
 * every file, put your service's two addresses in src/Api.php, and map its
 * answer onto the three verdicts in check(). It ships switched off, and does
 * nothing until an operator switches it on AND chooses it on the Modules
 * screen's fraud check card.
 *
 * What each verdict does to the order is the product's decision, not this
 * module's - see LBM\Module\Contracts\FraudInterface:
 *
 *   pass    invoiced as normal;
 *   review  held for staff: status `fraud`, no invoice;
 *   fail    held the same way, never refused outright;
 *   null    could not say - the order goes through, and the product writes the
 *           failure to its error log against this module.
 *
 * So when the service is down, or answers something you did not expect, answer
 * null. A screen that stops every sale while it is down costs more than the
 * fraud it would have caught.
 */
class Example implements FraudInterface, Configurable
{
    /** @var array<string,string> The Service's Recommendations, As Our Verdicts */
    private const VERDICTS = [
        'approve' => 'pass',
        'review'  => 'review',
        'decline' => 'fail',
    ];

    /** @var array<string,mixed> What The Operator Saved, Opened, Plus `mode` */
    private array $settings;

    /**
     * @param array<string,mixed> $settings Built by the product: the fields
     *        declared in settings(), opened, and `mode` - live or test.
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
    }

    /**
     * The Fields The Operator Fills In On The Module's Configure Page
     *
     * A `password` field is a secret: sealed, never shown again, and a blank
     * box keeps what is saved. Only what is declared here is stored.
     * @return array
     */
    public static function settings(): array
    {
        return [
            'api_key' => [
                'label'    => 'API key',
                'type'     => 'password',
                'required' => true,
                'help'     => 'From your account with the screening service.',
            ],
        ];
    }

    /**
     * Answer The Test Connection Button
     *
     * One cheap call that screens nothing - a screen may be charged for, and
     * it would be charged against no order. The message is shown as it is.
     * @return array{success: bool, message: string}
     */
    public function test(): array
    {
        $reply = (new Api($this->settings))->call('GET', 'ping', [], 5.0);

        return $reply['status'] === 200
            ? ['success' => true, 'message' => 'The API answered: ' . (string) ($reply['json']['message'] ?? 'OK')]
            : ['success' => false, 'message' => 'The API did not accept the key: ' . self::why($reply)];
    }

    /**
     * Screen One Order
     *
     * Send the service what it scores on, and map its answer onto pass, review
     * or fail. Anything else - a failed call, a recommendation not in the map -
     * is `verdict: null`, which lets the order through. Honour the `timeout`:
     * a customer is looking at a spinner while this runs.
     * @param array $order The `orders` row
     * @param array $context `client`, `email`, `ip`, `amount`, `currency`, `country`, `timeout`
     * @return array
     */
    public function check(array $order, array $context = []): array
    {
        $timeout = min(10.0, max(1.0, (float) ($context['timeout'] ?? 8.0)));

        $reply = (new Api($this->settings))->call('POST', 'screen', [
            'reference' => (string) ($order['order_number'] ?? ''),
            'email'     => (string) ($context['email'] ?? ''),
            'ip'        => (string) ($context['ip'] ?? ''),
            'amount'    => (string) ($context['amount'] ?? ''),
            'currency'  => (string) ($context['currency'] ?? ''),
            'country'   => (string) ($context['country'] ?? ''),
        ], $timeout);

        if ($reply['status'] !== 200) {
            return ['success' => false, 'verdict' => null, 'score' => null, 'message' => 'The screen could not say: ' . self::why($reply), 'raw' => []];
        }

        $recommendation = (string) ($reply['json']['recommendation'] ?? '');
        $score = $reply['json']['score'] ?? null;

        return [
            'success' => true,
            'verdict' => self::VERDICTS[$recommendation] ?? null,
            'score'   => is_numeric($score) ? (string) $score : null,
            'message' => (string) ($reply['json']['reason'] ?? '') ?: ('The service recommended ' . ($recommendation ?: 'nothing') . '.'),
            'raw'     => [],
        ];
    }

    /**
     * Why a Call Did Not Work, In Words
     * @param array $reply What Api::call() returned
     * @return string
     */
    private static function why(array $reply): string
    {
        return (string) ($reply['json']['message'] ?? $reply['error'] ?? ('HTTP ' . $reply['status']));
    }
}
