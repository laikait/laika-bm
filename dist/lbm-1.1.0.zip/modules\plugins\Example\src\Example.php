<?php

declare(strict_types=1);

namespace Modules\Plugins\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

use Throwable;
use LBM\Action\Module;
use LBM\Module\ModuleManager;
use LBM\Module\Contracts\Configurable;

/**
 * A STARTER: a plugin - a feature of its own, with settings of its own.
 *
 * Copy this directory to modules/plugins/<YourPlugin> and rename the namespace
 * in every file. A plugin has no contract to implement beyond Configurable: it
 * is whatever it registers. This one registers:
 *
 *   a route      routes/example.php - GET /example-plugin, answered by
 *                src/Controller/ExampleController.php with its greeting.
 *   a hook       hooks/example.php - nav_extend(), putting its Configure page
 *                in the admin sidebar when its `show_in_menu` setting is on.
 *   settings     declared below, filled in on Settings -> Modules -> Configure,
 *                and read back with current() wherever the plugin needs them.
 *
 * Nothing it registers exists while it is switched off: its route answers 404
 * and its hook is never loaded.
 */
class Example implements Configurable
{
    /** @var string What It Says Until The Operator Says Otherwise */
    public const GREETING = 'Hello from the Example plugin.';

    /** @var array<string,mixed> What The Operator Saved, Opened, Plus `mode` */
    private array $settings;

    /**
     * @param array<string,mixed> $settings Its declared fields, opened, and `mode`
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
    }

    /**
     * The Plugin's Uid - From Where It Sits, So a Copy Gets Its Own
     *
     * `plugins-<directory>`, the same key the modules table and the Configure
     * page use. Worked out from the directory rather than written down, so the
     * copy you make answers to its own name without an edit.
     * @return string
     */
    public static function uid(): string
    {
        return ModuleManager::uid('plugins', basename(dirname(__DIR__)));
    }

    /**
     * What Is Saved On Its Configure Page, Opened, With `mode`
     *
     * The same array the product builds every module with. Read it where the
     * plugin needs it - in a controller, in a hook. It is a query, so a hook that
     * runs on every page should read it once.
     * @return array<string,mixed>
     */
    public static function current(): array
    {
        try {
            return (new Module())->settingsFor(self::uid(), self::class);
        } catch (Throwable) {
            return ['mode' => 'live'];
        }
    }

    /**
     * The Fields The Operator Fills In On The Plugin's Configure Page
     *
     * The page is drawn from this. A `yesno` is a switch, a `password` is a
     * secret - sealed, never shown again, and a blank box keeps what is saved.
     * @return array
     */
    public static function settings(): array
    {
        return [
            'greeting' => [
                'label'   => 'Greeting',
                'type'    => 'text',
                'default' => self::GREETING,
                'help'    => 'What GET /example-plugin answers with.',
            ],
            'show_in_menu' => [
                'label'   => 'Show in the sidebar',
                'type'    => 'yesno',
                'default' => 'no',
                'help'    => 'Adds a link to this page to the admin sidebar, through nav_extend().',
            ],
            'api_key' => [
                'label' => 'API key',
                'type'  => 'password',
                'help'  => 'Only if the plugin calls a service. Test connection uses it.',
            ],
        ];
    }

    /**
     * Answer The Test Connection Button
     *
     * With no key there is nothing to test, and it says so rather than calling
     * a service with no credentials. The message is shown as it is.
     * @return array{success: bool, message: string}
     */
    public function test(): array
    {
        if ((string) ($this->settings['api_key'] ?? '') === '') {
            return ['success' => false, 'message' => 'Add an API key first - there is nothing to connect with.'];
        }

        $reply = (new Api($this->settings))->call('GET', 'ping');

        return $reply['status'] === 200
            ? ['success' => true, 'message' => 'The API answered: ' . (string) ($reply['json']['message'] ?? 'OK')]
            : ['success' => false, 'message' => 'The API did not accept the key: '
                . (string) ($reply['json']['message'] ?? $reply['error'] ?? ('HTTP ' . $reply['status']))];
    }

    /**
     * The Greeting, As Configured - Or The Default
     * @return string
     */
    public function greeting(): string
    {
        return trim((string) ($this->settings['greeting'] ?? '')) ?: self::GREETING;
    }
}
