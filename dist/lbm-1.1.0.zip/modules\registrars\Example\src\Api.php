<?php

declare(strict_types=1);

namespace Modules\Registrars\Example;

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/**
 * The registrar's API - both of its addresses, in code.
 *
 * The operator never types an address. They choose Live or Test on the
 * registrar's form, and the product hands that choice to the driver as `mode`.
 * Put your registrar's real addresses in endpoints(); leave `test` out if it has
 * no sandbox, and test mode then refuses every call rather than touching live.
 *
 * request() never throws, never follows a redirect, caps its time and the size
 * of a reply, and logs nothing - see LBM\Module\Api.
 */
final class Api extends \LBM\Module\Api
{
    /**
     * Where The Registrar Is, For Each Mode
     * @return array{live: string, test: string}
     */
    protected function endpoints(): array
    {
        return [
            'live' => 'https://api.example.com/v1',
            'test' => 'https://sandbox.example.com/v1',
        ];
    }

    /**
     * One Call, With The Saved Key In The Header The Registrar Expects
     *
     * The key is the operator's: never log it and never put it in a URL.
     * @param string $method HTTP Method
     * @param string $path Relative To The Mode's Address
     * @param array $data A Query For GET, a JSON Body Otherwise
     * @param float $timeout Seconds
     * @return array{status: int, body: string, json: ?array, error: ?string}
     */
    public function call(string $method, string $path, array $data = [], float $timeout = 15.0): array
    {
        return $this->request($method, $path, $data, ['X-Api-Key' => (string) $this->setting('api_key', '')], $timeout);
    }
}
