<?php
/**
 * Laika Bill Manager - English, installer.
 *
 * Loaded by LBM\Pipeline\GlobalPipeline::language() while the app is uninstalled.
 *
 * The class name is fixed and un-namespaced because that is what laika-core's
 * local() reads: it resolves LANG::$$key and nothing else. That is also why every
 * area gets its own file - require_once'ing a second one in the same request is a
 * fatal, so strings shared with the admin and panel catalogues are copied rather
 * than shared. There is no mechanism to share them.
 *
 * Values are sprintf() formats. Placeholders are %s / %d, and a literal percent
 * has to be written %%. Arguments come from the call site:
 *
 *     {{ 'checking_server'|local(app_name) }}
 *     local('tables_processed', count($rows))
 *
 * A key that is not here throws rather than rendering empty, so a missing string
 * surfaces the moment the screen is opened instead of shipping blank.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');

class LANG
{
    ################################################################################
    /*=================================== SHARED ===================================*/
    ################################################################################

    public static string $back = 'Back';
    public static string $continue = 'Continue';
    public static string $dismiss = 'Dismiss';
    public static string $optional = 'optional';
    public static string $failed = 'failed';
    public static string $there_is_a_problem = 'There is a problem';
    public static string $there_are_problems = 'There are problems';

    public static string $first_name = 'First name';
    public static string $last_name = 'Last name';
    public static string $email_address = 'Email address';
    public static string $username = 'Username';
    public static string $password = 'Password';
    public static string $confirm_password = 'Confirm password';

    public static string $timezone = 'Timezone';
    public static string $date_format = 'Date format';
    public static string $datetime_format = 'Date and time format';
    public static string $default_currency = 'Default currency';

    ################################################################################
    /*================================ THE STEP RAIL ===============================*/
    ################################################################################

    public static string $install = 'Install';
    public static string $installation_progress = 'Installation progress';
    public static string $set_up_your_billing_system = 'Set up your billing system';

    public static string $requirements = 'Requirements';
    public static string $database = 'Database';
    public static string $tables = 'Tables';
    public static string $settings = 'Settings';
    public static string $administrator = 'Administrator';
    public static string $finish = 'Finish';

    public static string $caption_requirements = 'Check this server can run the app';
    public static string $caption_database = 'Connect to your database';
    public static string $caption_migrate = 'Create the database tables';
    public static string $caption_settings = 'Tell us about your business';
    public static string $caption_admin = 'Create your administrator account';
    public static string $caption_finish = 'Finish the installation';
    public static string $caption_done = 'All done';

    ################################################################################
    /*=========================== STEP 1 - REQUIREMENTS ============================*/
    ################################################################################

    /** %s is the application name. */
    public static string $checking_server = 'Checking that this server can run %s. Everything marked required must pass before the installation can continue.';
    public static string $php_version = 'PHP Version';
    public static string $extensions = 'Extensions';
    public static string $writable_directories = 'Writable Directories';
    public static string $some_requirements_not_met = 'Some requirements are not met';
    public static string $fix_items_then_reload = 'Fix the items marked above, then reload this page. Nothing has been changed on your server yet.';
    public static string $recheck = 'Re-check';

    ################################################################################
    /*============================= STEP 2 - DATABASE ==============================*/
    ################################################################################

    /** %s is the application name. */
    public static string $database_intro = '%s needs an empty database and an account that can create tables in it. Nothing is written until these details connect successfully.';
    public static string $could_not_connect = 'Could not connect';
    public static string $driver = 'Driver';
    public static string $driver_hint = 'Only drivers with a loaded PDO extension are listed.';
    public static string $host = 'Host';
    public static string $port = 'Port';
    public static string $database_name = 'Database name';
    public static string $test_and_continue = 'Test and continue';
    public static string $database_name_required = 'A database name is required.';
    public static string $database_connected = 'Database connected.';

    ################################################################################
    /*============================== STEP 3 - TABLES ===============================*/
    ################################################################################

    /** %s is the number of schemas that will run. */
    public static string $migrate_intro = 'This creates %s tables and fills the lookup tables - currencies, countries, billing cycles, statuses and their colours. It is safe to run more than once.';
    public static string $create_tables = 'Create tables';
    public static string $all_tables_created = 'All tables created';
    public static string $finished_with_errors = 'Finished with errors';
    /** %s is a table count. */
    public static string $tables_processed = '%s tables processed';
    /** %s is a table count. Appended to $tables_processed, so it opens with a comma. */
    public static string $tables_failed = ', %s failed';
    public static string $table = 'Table';
    public static string $result = 'Result';
    public static string $run_again = 'Run again';

    ################################################################################
    /*============================= STEP 4 - SETTINGS ==============================*/
    ################################################################################

    public static string $settings_intro = 'How invoices and emails will identify your business. All of it can be changed later under Settings.';
    public static string $company = 'Company';
    public static string $company_name = 'Company name';
    public static string $company_name_hint = 'Shown in the panel, on invoices and in outgoing email.';
    public static string $application_url = 'Application URL';
    public static string $application_url_hint = 'The address clients reach this system on, including https://';
    public static string $billing_email_address = 'Billing email address';
    public static string $billing_email_hint = 'Where client replies and system notices are sent.';
    public static string $locale = 'Locale';
    public static string $timezone_hint = 'Stored and displayed times use this. UTC is recommended.';
    public static string $default_currency_hint = 'Exchange rates are quoted against this one.';
    public static string $save_and_continue = 'Save and continue';
    public static string $company_name_required = 'A company name is required.';
    public static string $application_url_required = 'An application URL is required.';
    public static string $billing_email_required = 'A billing email address is required.';
    public static string $not_an_email_address = 'That does not look like an email address.';
    public static string $settings_saved = 'Settings saved.';

    ################################################################################
    /*=========================== STEP 5 - ADMINISTRATOR ===========================*/
    ################################################################################

    public static string $admin_intro = 'This account gets a role with every permission. You can add more staff and narrower roles once you are signed in.';
    public static string $email_signin_hint = 'Used to sign in and to receive password resets.';
    public static string $password_requirements = 'Password requirements';
    /** %s is the minimum length. */
    public static string $password_rules = 'At least %s characters, with an uppercase letter, a lowercase letter and a number.';
    public static string $create_account = 'Create account';
    public static string $first_name_required = 'A first name is required.';
    public static string $last_name_required = 'A last name is required.';
    public static string $username_required = 'A username is required.';
    public static string $email_required = 'An email address is required.';
    public static string $administrator_created = 'Administrator created.';

    ################################################################################
    /*============================== STEP 6 - FINISH ===============================*/
    ################################################################################

    public static string $finish_intro = 'Everything is set up. Finishing clears the template cache and closes the installer so it cannot be re-run from the browser.';
    public static string $finish_installation = 'Finish installation';
    /** %s is the application name. */
    public static string $app_is_ready = '%s is ready';
    /** %s is the lock file path, already wrapped in a <code> element. */
    public static string $installer_closed = 'The installer is now closed. To run it again you would have to delete %s by hand.';
    public static string $go_to_admin_panel = 'Go to the admin panel';
    public static string $view_client_area = 'View the client area';
    public static string $two_things_next = 'Two things worth doing next';
    /** %s is the Settings menu path, %s the worker command - both already marked up. */
    public static string $next_steps = 'Configure SMTP under %s so invoices and password resets can be delivered, and start the queue worker (%s) - outgoing email is queued, never sent during a web request.';
    public static string $create_admin_first = 'Create an administrator account first.';
    public static string $installation_complete = 'Installation complete.';
}
