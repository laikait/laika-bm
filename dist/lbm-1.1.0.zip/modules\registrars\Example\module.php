<?php

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403).die('403 Direct Access Denied!');

/*
 * A STARTER - copy it, do not switch it on.
 *
 * Copy this directory to modules/registrars/<YourRegistrar>, rename the
 * namespace below and in every file under src/, and put your registrar's two
 * addresses in src/Api.php. It points at api.example.com and
 * sandbox.example.com, which never answer.
 *
 * A declaration and nothing else: the loader reads this during autoload and the
 * modules screen reads it again.
 */

return [
    'name'        => 'Example Registrar',
    'version'     => '1.0.0',
    'author'      => 'Laika IT',
    'description' => 'A starter to copy: a registrar module implementing all six verbs - availability, '
        . 'register, renew, transfer, nameservers and contacts - over a JSON API. Not a real registrar.',

    'class'       => \Modules\Registrars\Example\Example::class,

    'namespace'   => 'Modules\Registrars\Example',
    'src'         => 'src',
];
