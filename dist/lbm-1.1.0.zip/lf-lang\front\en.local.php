<?php
/**
 * Laika Bill Manager - English, public website.
 *
 * Loaded by LBM\Pipeline\GlobalPipeline::language() for every request that is
 * not /admin and not /panel - the bare root included. The front area owns no URL
 * prefix, so it is defined by exclusion; see area() in helpers/functions/app.php.
 *
 * The class name is fixed and un-namespaced because that is what laika-core's
 * local() reads: it resolves LANG::$$key and nothing else. That is also why every
 * area gets its own file - require_once'ing a second one in the same request is a
 * fatal, so strings shared with the admin, panel and installer catalogues are
 * copied rather than shared. There is no mechanism to share them.
 *
 * Values are sprintf() formats. Placeholders are %s / %d, and a literal percent
 * has to be written %%.
 *
 * Keys are deduplicated by meaning, not by screen. A key that is not here throws
 * rather than rendering empty, so a missing string surfaces the moment the screen
 * is opened instead of shipping blank.
 *
 * This is the one catalogue whose strings are read by strangers rather than by
 * people who already bought something, so the register is different: no jargon,
 * no abbreviations, and nothing that assumes the reader knows what the product
 * is yet.
 */

declare(strict_types=1);

// Deny Direct Access
defined('APP_PATH') || http_response_code(403) . die('403 Direct Access Denied!');

class LANG
{
    ############################################################################
    /*============================ SHARED CHROME =============================*/
    ############################################################################

    public static string $menu = 'Menu';
    public static string $sign_in = 'Sign in';
    public static string $get_started = 'Get started';
    public static string $my_account = 'My account';
    public static string $admin_area = 'Admin area';
    public static string $client_area = 'Client area';
    public static string $home = 'Home';
    public static string $company = 'Company';
    public static string $legal = 'Legal';
    public static string $search = 'Search';
    public static string $learn_more = 'Learn more';
    public static string $view_all = 'View all';
    public static string $from = 'From';
    public static string $subject = 'Subject';

    /** %1$s is the current year, %2$s the company name. */
    public static string $copyright = '&copy; %1$s %2$s. All rights reserved.';
    public static string $footer_tagline = 'Hosting, domains and support, billed simply.';

    ############################################################################
    /*=============================== HOME PAGE ==============================*/
    ############################################################################

    /** %s is the company name. */
    public static string $home_meta = '%s - hosting, domains and support.';
    /** %s is the company name. */
    public static string $hero_title = 'Everything you need, in one account.';
    public static string $hero_lead = 'Order a service, pay an invoice and get help without hunting for the right page. Your billing, domains and support all live in one place.';
    public static string $browse_services = 'Browse services';
    public static string $our_services = 'Our services';
    public static string $our_services_lead = 'Pick the plan that fits. Change it whenever it stops fitting.';
    public static string $latest_news = 'Latest news';
    public static string $latest_news_lead = 'Maintenance windows, new features and anything else worth knowing.';
    public static string $no_services_yet = 'Nothing is listed for sale yet.';
    public static string $need_a_hand = 'Need a hand?';
    public static string $need_a_hand_lead = 'Search the knowledgebase, or write to us and a person will answer.';

    ############################################################################
    /*============================ STATIC PAGES ==============================*/
    ############################################################################

    public static string $about_us = 'About us';
    public static string $about_lead = 'Who we are and what we run.';
    public static string $about_body_1 = 'We host and support the services our customers depend on, and we bill for them without surprises. Every plan is listed with its full price, every invoice says what it covers, and every question reaches somebody who can answer it.';
    public static string $about_body_2 = 'This page is part of the template. Edit it to say something true about your own company - it ships with placeholder copy so the site is complete on the day it is installed, not so you leave it as it is.';

    public static string $terms_of_service = 'Terms of service';
    public static string $terms_lead = 'The agreement between us.';
    public static string $terms_placeholder = 'This page ships as a placeholder. Replace it with your own terms before taking a customer - the text here is not legal advice and is not a substitute for it.';

    public static string $privacy_policy = 'Privacy policy';
    public static string $privacy_lead = 'What we collect, and why.';
    public static string $privacy_placeholder = 'This page ships as a placeholder. Replace it with your own policy before taking a customer - what you must say depends on where you and they are.';

    public static string $placeholder_notice = 'Placeholder text';
    public static string $edit_this_page = 'Edit this page in %s';

    ############################################################################
    /*=============================== SERVICES ===============================*/
    ############################################################################

    public static string $services = 'Services';
    /** %s is the company name. */
    public static string $services_meta = 'Plans and pricing from %s.';
    public static string $services_lead = 'Everything we offer, grouped so you can find the right one.';
    /** %s is the group name. */
    public static string $service_group_meta = 'Plans and pricing in %s.';
    public static string $nothing_for_sale = 'Nothing is listed for sale yet.';
    public static string $no_products_in_group = 'Nothing is listed in this group yet.';
    public static string $setup_fee = 'Setup fee';
    public static string $one_time = 'One time';
    public static string $price_on_request = 'Price on request';
    public static string $order_now = 'Order now';
    public static string $view_plans = 'View plans';
    public static string $whats_included = 'What is included';
    public static string $pricing = 'Pricing';
    public static string $billing_cycle = 'Billing cycle';
    public static string $price = 'Price';
    public static string $no_pricing_yet = 'Pricing for this service has not been published yet. Ask us and we will quote you.';
    public static string $ask_about_this = 'Ask about this service';
    public static string $order_note = 'Nothing is charged yet. You sign in or open an account when you check out.';

    ############################################################################
    /*============================ KNOWLEDGEBASE =============================*/
    ############################################################################

    public static string $knowledgebase = 'Knowledgebase';
    /** %s is the company name. */
    public static string $knowledgebase_meta = 'Guides and answers from %s.';
    public static string $knowledgebase_lead = 'Guides, answers and how-tos. Search, or browse by category.';
    public static string $search_the_kb = 'Search the knowledgebase';
    public static string $search_results = 'Search results';
    /** %1$d is the number of results, %2$s the search term. */
    public static string $found_n_for = '%1$d result(s) for "%2$s"';
    /** %s is the search term. */
    public static string $nothing_found_for = 'Nothing matched "%s". Try a shorter phrase, or write to us.';
    public static string $browse_categories = 'Browse by category';
    public static string $popular_articles = 'Popular articles';
    public static string $no_articles_yet = 'No articles have been published yet.';
    public static string $no_categories_yet = 'No categories have been created yet.';
    /** %s is the category name. */
    public static string $kb_category_meta = 'Articles in %s.';
    /** %d is a count of articles. */
    public static string $n_articles = '%d article(s)';
    /** %d is a view count. */
    public static string $n_views = '%d view(s)';
    public static string $was_this_helpful = 'Was this helpful?';
    public static string $yes = 'Yes';
    public static string $no = 'No';
    public static string $vote_thanks = 'Thank you - that helps us write better answers.';
    public static string $still_stuck = 'Still stuck? Write to us and a person will answer.';
    public static string $all_articles = 'All articles';

    ############################################################################
    /*============================ ANNOUNCEMENTS =============================*/
    ############################################################################

    public static string $announcements = 'Announcements';
    /** %s is the company name. */
    public static string $announcements_meta = 'News and service notices from %s.';
    public static string $announcements_lead = 'Maintenance windows, new features and anything else worth knowing.';
    public static string $no_announcements = 'Nothing has been announced yet.';
    public static string $published_on = 'Published %s';
    public static string $back_to_announcements = 'Back to announcements';

    ############################################################################
    /*=============================== SUPPORT ================================*/
    ############################################################################

    public static string $support = 'Support';
    public static string $support_centre = 'Support centre';
    /** %s is the company name. */
    public static string $support_meta = 'Get help from %s.';
    public static string $support_lead = 'Start with the knowledgebase. If the answer is not there, write to us.';
    public static string $help_yourself = 'Help yourself';
    public static string $help_yourself_lead = 'Most questions are answered here, immediately.';
    public static string $talk_to_us = 'Talk to us';
    public static string $talk_to_us_lead = 'Already a customer? Open a ticket from your account and we can see your services. Otherwise use the contact form.';
    public static string $open_a_ticket = 'Open a ticket';
    public static string $contact_form = 'Contact form';

    ############################################################################
    /*============================= CONTACT FORM =============================*/
    ############################################################################

    public static string $contact = 'Contact';
    public static string $contact_us = 'Contact us';
    /** %s is the company name. */
    public static string $contact_meta = 'Get in touch with %s.';
    public static string $contact_lead = 'Tell us what you need and we will reply by email.';
    public static string $your_name = 'Your name';
    public static string $your_email = 'Your email address';
    public static string $department = 'Department';
    public static string $choose_department = 'Choose a department';
    public static string $message = 'Message';
    public static string $send_message = 'Send message';
    public static string $contact_note = 'We reply to the address you give us. Please check it before sending.';
    public static string $ticket = 'Ticket';

    public static string $name_required = 'Please tell us your name.';
    public static string $email_required = 'We need an email address to reply to.';
    public static string $subject_required = 'Please give your message a subject.';
    public static string $message_required = 'Please write your message.';
    public static string $department_required = 'Please choose the department to write to.';
    public static string $not_an_email_address = 'That does not look like an email address.';

    /** The first line of the ticket a contact form submission opens. */
    public static string $sent_from_contact_form = 'Sent from the website contact form.';

    /** %s is the subject the sender typed. */
    public static string $contact_subject = 'Website enquiry: %s';
    /** %1$s is the ticket number, %2$s the subject the sender typed. */
    public static string $contact_subject_ticket = '[%1$s] Website enquiry: %2$s';
    public static string $contact_sent = 'Thank you - your message is on its way and we will reply by email.';
    /** %s is the ticket number the enquiry was logged as. */
    public static string $contact_sent_ticket = 'Thank you - your enquiry is logged as ticket %s and we will reply by email.';
    public static string $contact_failed = 'Your message could not be sent just now. Please try again shortly.';
    public static string $contact_unavailable = 'This site has no contact address configured yet, so the form cannot send.';

    ############################################################################
    /*================================ ERRORS ================================*/
    ############################################################################

    public static string $page_not_found = 'Page not found';
    public static string $not_found_lead = 'That address does not lead anywhere. It may have moved, or the link that brought you here may be wrong.';
    public static string $go_home = 'Go to the home page';
    public static string $or_search_kb = 'Or search the knowledgebase';

    ############################################################################
    /*============================== PAGINATION ==============================*/
    ############################################################################
    //
    // These are the keys partials/pagination.twig actually references. It is a
    // copy of the panel partial - shared partials are copied into each template,
    // not shared - so its key names come with it, and inventing prettier ones
    // here would simply throw.

    public static string $pagination = 'Pagination';
    public static string $records = 'records';
    public static string $articles = 'articles';
    public static string $announcements_lower = 'announcements';
    /** %1$s is how many are shown, %2$s what they are. */
    public static string $showing_n = 'Showing %s %s';
    public static string $of_more = ' of more';
    public static string $first = 'First';
    public static string $next = 'Next';

    ############################################################################
    /*=============================== MESSAGES ===============================*/
    ############################################################################
    //
    // Also required by the copied partials: alerts.twig wants `dismiss`,
    // status.twig wants `any_status`, form-errors.twig picks between the two
    // problem headings.

    public static string $dismiss = 'Dismiss';
    public static string $any_status = 'Any status';
    public static string $there_is_a_problem = 'There is a problem';
    public static string $there_are_problems = 'There are problems';

    ############################################################################
    /*========================== CART AND CHECKOUT ===========================*/
    ############################################################################
    //
    // Phase 22.2. The problem strings are keyed `cart_problem_<reason>` and the
    // template builds the key from the reason Cart::lines() gave it - so a new
    // reason needs a matching key added HERE at the same time. local() throws
    // on a missing key, which means the omission takes the cart screen down
    // rather than showing a blank; that is the intended failure and the reason
    // the reasons are a short closed list.

    public static string $cart = 'Cart';
    public static string $cart_lead = 'What you have chosen so far. Nothing is charged until you check out.';
    public static string $cart_empty = 'Your cart is empty.';
    public static string $item = 'Item';
    public static string $quantity = 'Quantity';
    public static string $subtotal = 'Subtotal';
    public static string $update = 'Update';
    public static string $remove = 'Remove';
    public static string $empty_cart = 'Empty cart';
    public static string $add_to_cart = 'Add to cart';
    public static string $order_summary = 'Order summary';
    public static string $order_domain = 'Domain name';
    public static string $order_domain_hint = 'The domain this will be set up for. You can use one you already own.';
    public static string $cart_needs_domain = 'That product needs a domain name. Type the one it should be set up for.';
    public static string $cart_line_needs_domain = 'This line needs a domain name.';
    public static string $recurring_total = 'Recurring';
    public static string $setup_fees = 'Setup fees';
    public static string $due_today = 'Due today';
    public static string $checkout = 'Check out';
    public static string $sign_in_and_checkout = 'Sign in and check out';
    public static string $checkout_note = 'This raises an invoice you can pay straight away.';
    public static string $checkout_account_note = 'You will be asked to sign in. Your cart is kept.';
    public static string $no_gateways_note = 'No online payment method is set up yet, so your invoice will need to be settled with us directly.';
    public static string $cart_fix_problems = 'Sort out the highlighted lines before checking out.';
    public static string $cart_line_unknown = 'Item no longer listed';
    public static string $cart_problem_unavailable = 'This is no longer for sale.';
    public static string $cart_problem_no_price = 'This is no longer priced in your currency.';
    public static string $cart_problem_needs_domain = 'This needs a domain name. Remove it and add it again with one.';

    /*------------------------------ Messages -------------------------------*/

    public static string $cart_added = 'Added to your cart.';
    public static string $cart_updated = 'Cart updated.';
    public static string $cart_removed = 'Removed from your cart.';
    public static string $cart_emptied = 'Your cart is now empty.';
    public static string $cart_line_gone = 'That line is not in your cart.';
    public static string $cart_product_gone = 'That service is not available to order.';
    public static string $cart_no_price = 'That billing cycle is not offered for this service.';
    public static string $cart_has_problems = 'Some lines in your cart cannot be ordered. Sort those out first.';
    public static string $cart_sign_in_first = 'Sign in to finish your order. Your cart is kept.';
    public static string $cart_no_currency = 'No billing currency is set up, so an order cannot be priced.';
    public static string $order_placed = 'Your order is placed. Here is the invoice for it.';
    public static string $order_no_invoice = 'The order was placed but its invoice could not be read. Please contact us.';

    ############################################################################
    /*================================== TAX =================================*/
    ############################################################################
    //
    // Phase 25. The cart cannot know a rate until it knows a country, and it
    // knows a country only once somebody has signed in.

    public static string $tax = 'Tax';
    public static string $tax_at_checkout = 'Worked out at checkout';
    public static string $tax_included = 'Includes tax of';

    ############################################################################
    /*================================= ADDONS ===============================*/
    ############################################################################
    //
    // Phase 26.

    public static string $optional_extras = 'Optional extras';
    public static string $cart_addon_gone = 'One of the extras you picked is no longer available.';
    public static string $cart_problem_addon_unavailable = 'An extra on this line is no longer available.';

    ############################################################################
    /*================================= DOMAINS ==============================*/
    ############################################################################
    //
    // Phase 27.1. The three availability sentences are deliberately different
    // from each other: taken, not sold here, and not checked are three
    // situations with three different things for the visitor to do next.

    public static string $domains = 'Domains';
    /** %s is the site name. */
    public static string $domains_meta = 'Search for and register a domain name with %s.';
    public static string $find_a_domain = 'Find a domain';
    public static string $find_a_domain_hint = 'Type the name you want. We will show you what is free and what it costs.';
    public static string $domain_name = 'Domain name';
    public static string $domain_registration = 'Domain registration';
    public static string $domain_pricing = 'Domain pricing';
    public static string $tld = 'TLD';
    public static string $register_price = 'Register';
    public static string $renew_price = 'Renews at';
    public static string $term = 'Term';
    /** %s is a count of years, or a list of them. */
    public static string $n_years = '%s year(s)';
    public static string $domain_is_available = 'Available';
    public static string $domain_is_taken = 'Already taken';
    public static string $domain_not_sold_here = 'Not sold in this currency';
    public static string $domain_availability_unknown = 'We will check this one for you before it is registered.';
    public static string $domain_search_invalid = 'That does not look like a domain name. Try something like example.com.';
    public static string $no_tlds_on_sale = 'No TLDs are on sale at the moment.';
    public static string $cart_tld_gone = 'That TLD is not on sale here.';
    public static string $cart_domain_taken = 'That domain has already gone. Try another one.';
    public static string $cart_domain_term = 'That TLD is not sold for that length of time.';
    public static string $cart_domain_currency = 'That TLD is not priced in your currency, so it cannot be ordered here.';
    public static string $cart_problem_domain_taken = 'This domain has been registered by somebody else.';

    // Phase 26.2.

    public static string $configure_it = 'Configure it';
    public static string $no_thanks = 'No thanks';
    public static string $cart_config_gone = 'One of the options you chose is no longer offered, or a required one was left blank. Check the form and try again.';
    public static string $cart_problem_config_unavailable = 'One of the options chosen with this is no longer sold on this billing cycle.';

    // Phase 27.3.

    public static string $transfer_it = 'Transfer it';
    public static string $domain_can_transfer = 'Registered elsewhere - you can move it here';
    public static string $cart_transfer_here = 'That name is already on this account, so there is nothing to transfer.';

    // Phase 27.4.

    public static string $promo_have_a_code = 'Have a code?';
    public static string $promo_apply = 'Apply';
    public static string $promo_remove = 'Remove';
    public static string $promo_on_cart = 'Code applied:';
    public static string $promo_discount = 'Discount';
    public static string $promo_applied = 'Code applied.';
    public static string $promo_removed = 'Code removed.';
    public static string $promo_unknown = 'That code is not one we recognise.';
    public static string $promo_not_started = 'That code is not live yet.';
    public static string $promo_expired = 'That code has expired.';
    public static string $promo_used_up = 'That code has been used as many times as it can be.';
    public static string $promo_currency = 'That code is in a different currency from your account, so it cannot be used here.';
}
